# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from ast import literal_eval

from odoo import api, fields, models

class res_company(models.Model):
    _inherit = 'res.company'

    purchase = fields.Boolean()
    enhance = fields.Boolean()
    revalue = fields.Boolean()
    sale = fields.Boolean()
    abandon = fields.Boolean()


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    purchase = fields.Boolean(string='purchase', related="company_id.purchase", config_parameter='account_asset.purchase')
    enhance = fields.Boolean(string='Enhance', related="company_id.enhance", config_parameter='account_asset.enhance')
    revalue = fields.Boolean(string='Revalue', related="company_id.revalue", config_parameter='account_asset.revalue')
    sale = fields.Boolean(string='Sale', related="company_id.sale", config_parameter='account_asset.sale')
    abandon = fields.Boolean(string='Abandon', related="company_id.abandon", config_parameter='account_asset.abandon')
