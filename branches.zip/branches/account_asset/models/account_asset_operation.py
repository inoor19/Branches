# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import float_compare
import json


class AccountAssetOperation(models.Model):
    """Object to record all operation (revalue, abandon and sale, ...) to asset.
    """
    _name = 'account.asset.operation'
    _description = "Operation"
    _inherit = ['mail.thread']

    @api.depends('asset_id', 'type', 'date')
    def _get_name(self):
        for line in self:
            line.name = line.asset_id and line.asset_id.name or "" + "/" + line.type + "/" + str(line.date) + "/"

    name = fields.Char('name', compute='_get_name', copy=False, default='/')
    asset_id = fields.Many2one(
        'account.asset.asset', string='Asset',
        states={'draft': [('readonly', False)]},
        copy=False)
    type = fields.Selection(
        [('enhance', 'Enhance'),
         ('revalue', 'Revalue'),
         ('sale', 'Sale'),
         ('abandon', 'Abandon')],
        string='Type', required=True)
    date = fields.Date(
        string='Date', required=True, readonly=True,
        states={'draft': [('readonly', False)]},
        default=fields.Date.context_today)
    state = fields.Selection(
        [('draft', 'Draft'),
         ('done', 'Done')],
        'Status', required=True, copy=False, default='draft')
    move_id = fields.Many2one(
        'account.move', string='Depreciation Entry')
    move_check = fields.Boolean(
        compute='_get_move_check', string='Linked',
        track_visibility='always', store=True)
    move_posted_check = fields.Boolean(
        compute='_get_move_posted_check', string='Posted',
        track_visibility='always', store=True)
    currency_id = fields.Many2one(
        'res.currency', string='Currency', required=True,
        readonly=True, states={'draft': [('readonly', False)]},
        default=lambda self: self.env.user.company_id.currency_id.id)
    company_id = fields.Many2one(
        'res.company', string='Company', required=True, readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: self.env['res.company']._company_default_get(
            'account.asset.operation'))
    category_id = fields.Many2one(
        'account.asset.category', string='Category')
    partner_id = fields.Many2one(
        'res.partner', string='Partner', readonly=True,
        states={'draft': [('readonly', False)]})
    depreciable = fields.Boolean(
        related='category_id.depreciable', string='Depreciable',
        copy=False)
    amount = fields.Float(
        string='amount')
    sale_invoice_id = fields.Many2one(
        'account.move', string='Invoice',
        states={'draft': [('readonly', False)]},
        copy=False)
    asset_name = fields.Char(string='Asset Name')
    asset_method_number = fields.Integer(
        compute='_get_asset_dep_info',
        string='Asset Number of Depreciations')
    asset_method_period = fields.Integer(
        compute='_get_asset_dep_info', string='Asset Period Length')
    asset_method_end = fields.Date(
        compute='_get_asset_dep_info', string='Asset Ending date')

    method_number = fields.Integer(string='Number of Depreciations')
    method_period = fields.Integer(string='Period Length')
    method_end = fields.Date(string='Ending date')
    asset_method_time = fields.Char(string='Asset Method Time')

    def _get_asset_dep_info(self):
        if self.asset_id:
            method_number = self.asset_id.method_number
            method_period = self.asset_id.method_period
            method_end = self.asset_id.method_end

            if self.id:
                last_revalution_enhance = self.search(
                    [('type', 'in', ['revalue', 'enhance']),
                     ('asset_id', '=', self.asset_id.id),
                     ('state', '=', 'done'),
                     ('id', '!=', self.id)])
            if not self.id:
                last_revalution_enhance = self.search(
                    [('type', 'in', ['revalue', 'enhance']),
                     ('asset_id', '=', self.asset_id.id),
                     ('state', '=', 'done')])

            if last_revalution_enhance:
                last_revalution_enhance = last_revalution_enhance[0]
                method_number = last_revalution_enhance.method_number
                method_period = last_revalution_enhance.method_period
                method_end = last_revalution_enhance.method_end

            self.asset_method_number = method_number
            self.asset_method_period = method_period
            self.asset_method_end = method_end

    @api.onchange('category_id')
    def onchange_category(self):
        if self.category_id:
            self.depreciable = self.category_id.depreciable
        if not self.category_id and not self.asset_id:
            self.depreciable = False

    @api.onchange('asset_id')
    def onchange_asset(self):
        if self.asset_id:
            self.depreciable = self.asset_id.depreciable
            self.category_id = self.asset_id.category_id.id

            method_number = self.asset_id.method_number
            method_period = self.asset_id.method_period
            method_end = self.asset_id.method_end

            if self.id:
                last_revalution_enhance = self.search(
                    [('type', 'in', ['revalue', 'enhance']),
                     ('asset_id', '=', self.asset_id.id),
                     ('state', '=', 'done'),
                     ('id', '!=', self.id)])
            if not self.id:
                last_revalution_enhance = self.search(
                    [('type', 'in', ['revalue', 'enhance']),
                     ('asset_id', '=', self.asset_id.id),
                     ('state', '=', 'done')])

            if last_revalution_enhance:
                last_revalution_enhance = last_revalution_enhance[0]
                method_number = last_revalution_enhance.method_number
                method_period = last_revalution_enhance.method_period
                method_end = last_revalution_enhance.method_end

            self.asset_method_time = self.asset_id.method_time
            self.asset_method_number = method_number
            self.asset_method_period = method_period
            self.asset_method_end = method_end

            self.method_number = method_number
            self.method_period = method_period
            self.method_end = method_end
        if not self.asset_id and not self.category_id:
            self.depreciable = False

    @api.depends('move_id')
    def _get_move_check(self):
        for line in self:
            line.move_check = bool(line.move_id)

    @api.depends('move_id.state')
    def _get_move_posted_check(self):
        for line in self:
            line.move_posted_check = True if line.move_id and line.move_id.state == 'posted' else False

    def create_move(self):
        for line in self:
            created_moves = self.env['account.move']
            prec = line.env['decimal.precision'].precision_get('Account')
            asset_name = line.name
            asset_id = line.asset_id
            type = line.type
            category_id = line.asset_id.category_id
            date = line.date
            amount = line.amount
            account_asset_id = line.asset_id.category_id.account_asset_id
            company_currency = line.asset_id.company_id.currency_id
            current_currency = line.asset_id.currency_id

            if type == "enhance":
                if line.env.user.company_id.enhance == False:
                    return
                account_id = category_id.account_rehabilitation_id
                if not account_id:
                    raise UserError(_('the partner %s must have rehabilitation account.') % (category_id.name,))

                move_line_1 = {
                    'name': asset_name,
                    'account_id': account_id.id,
                    'debit': 0.0 if float_compare(amount, 0.0, precision_digits=prec) > 0 else -amount,
                    'credit': amount if float_compare(amount, 0.0, precision_digits=prec) > 0 else 0.0,
                    'journal_id': category_id.journal_id.id,
                    'analytic_account_id': category_id.account_analytic_id.id
                    if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                    # 'currency_id': company_currency != current_currency and current_currency.id or False,
                    'amount_currency': company_currency !=
                                       current_currency and self.amount or 0.0,
                }
                move_line_2 = {
                    'name': asset_name,
                    'account_id': account_asset_id.id,
                    'credit': 0.0 if float_compare(amount, 0.0, precision_digits=prec) > 0 else -amount,
                    'debit': amount if float_compare(amount, 0.0, precision_digits=prec) > 0 else 0.0,
                    'journal_id': category_id.journal_id.id,
                    'analytic_account_id': category_id.account_analytic_id.id
                    if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                    # 'currency_id': company_currency != current_currency and current_currency.id or False,
                    'amount_currency': company_currency !=
                                       current_currency and self.amount or 0.0,
                }

            elif type == "revalue":
                if line.env.user.company_id.revalue == False:
                    return
                account_id = category_id.account_reval_id
                if not account_id:
                    raise UserError(_('the partner %s must have rehabilitation account.') % (category_id.name,))
                move_line_1 = {
                    'name': asset_name,
                    'account_id': account_id.id,
                    'debit': 0.0 if float_compare(amount, 0.0, precision_digits=prec) > 0 else -amount,
                    'credit': amount if float_compare(amount, 0.0, precision_digits=prec) > 0 else 0.0,
                    'journal_id': category_id.journal_id.id,
                    'analytic_account_id': category_id.account_analytic_id.id
                    if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                    # 'currency_id': company_currency != current_currency and current_currency.id or False,
                    'amount_currency': company_currency !=
                                       current_currency and self.amount or 0.0,
                }
                move_line_2 = {
                    'name': asset_name,
                    'account_id': account_asset_id.id,
                    'credit': 0.0 if float_compare(amount, 0.0, precision_digits=prec) > 0 else -amount,
                    'debit': amount if float_compare(amount, 0.0, precision_digits=prec) > 0 else 0.0,
                    'journal_id': category_id.journal_id.id,
                    'analytic_account_id': category_id.account_analytic_id.id
                    if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                    # 'currency_id': company_currency != current_currency and current_currency.id or False,
                    'amount_currency': company_currency !=
                                       current_currency and self.amount or 0.0,
                }
            elif type == "abandon":
                if line.env.user.company_id.abandon == False:
                    return
                account_id = category_id.account_pl_id
                if not account_id:
                    raise UserError(_('the partner %s must have abandon account.') % (category_id.name,))

            move_vals = {
                'ref': line.asset_id.code,
                'date': date or False,
                'journal_id': category_id.journal_id.id,
                'line_ids': [(0, 0, move_line_1), (0, 0, move_line_2)],
            }

            move = self.env['account.move'].create(move_vals)
            line.write({'move_id': move.id, 'move_check': True, 'amount': amount})

            if move:
                move._post()

    def create_voucher(self):

        invoice_obj = self.env['account.move']
        prec = self.env['decimal.precision'].precision_get('Account')
        asset_name = self.name
        asset_id = self.asset_id
        type = self.type
        category_id = self.asset_id.category_id
        date = self.date
        amount = self.amount
        partner_id = self.partner_id
        currency_id = self.currency_id

        if type == 'sale':
            if amount >= asset_id.value_residual:
                account_id = category_id.account_sale_revenue
            if amount < asset_id.value_residual:
                account_id = category_id.account_sale_lost
        voucher_line = {
            'name': asset_name,
            'partner_id': partner_id.id,
            'account_id': account_id.id,
            'price_unit': amount if float_compare(amount, 0.0, precision_digits=prec) > 0 else 0.0,
            'company_id': self.company_id.id,
            'currency_id': currency_id.id,
        }
        invoice_vals = {
            'move_type': 'entry',
            'name': asset_name,
            'ref': self.asset_id.code,
            'date': date or False,
            'invoice_date_due': date or False,
            'currency_id': currency_id.id,
            'company_id': self.company_id.id,
            'journal_id': category_id.journal_id.id,
            'line_ids': [(0, 0, voucher_line)],
        }
        invoice = self.env['account.move'].create(invoice_vals)
        self.sale_invoice_id = invoice.id
        return True

    def done(self):
        for rec in self:
            if rec.type in ['enhance','revalue']:
                rec.create_move()
                if rec.depreciable and (
                        rec.asset_method_end, rec.asset_method_number, rec.asset_method_period) != (
                        rec.method_end, rec.method_number, rec.method_period):
                    # to be used in the compute_depreciation_board method
                    rec.write({'state': 'done'})
                rec.asset_id.write({'state': 'open'})
            elif rec.type in ['sale']:
                rec.sale_invoice_id_change()
                rec.asset_id.state = 'sold'
            elif rec.type in ['abandon']:
                rec.abandon()
                rec.asset_id.write({'state': 'close'})
            rec.asset_id.compute_depreciation_board()
        self.write({'state': 'done'})
        return True

    def open_entries(self):
        move_ids = []
        for op in self:
            move_ids.append(op.move_id.id)
        return {
            'name': _('Journal Entries'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', move_ids)],
        }

        return True

    def sale_invoice_id_change(self):
        for line in self:
            if not line.move_id and line.type in ['sale']:
                created_moves = self.env['account.move']
                prec = line.env['decimal.precision'].precision_get('Account')
                asset_name = line.name
                asset_id = line.asset_id
                type = line.type
                category_id = line.asset_id.category_id
                date = line.date
                amount = line.amount
                dis_list = {category_id.account_analytic_id.id}
                distribution = dict.fromkeys(dis_list, 100)
                account_asset_id = False

                company_currency = line.asset_id.company_id.currency_id
                current_currency = line.asset_id.currency_id

                dep_value = line.asset_id.value - line.asset_id.value_residual - line.asset_id.salvage_value
                # Ask about Receivable Acc
                # account_id = line.partner_id.property_account_receivable_id
                account_id = category_id.account_initial_id

                move_line_1 = {
                    'name': asset_name,
                    'account_id': account_id.id,
                    'credit': 0.0 if float_compare(amount, 0.0, precision_digits=prec) > 0 else -amount,
                    'debit': amount if float_compare(amount, 0.0, precision_digits=prec) > 0 else 0.0,
                    'journal_id': category_id.journal_id.id,
                    'analytic_distribution': distribution
                    if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                    # 'currency_id': company_currency !=current_currency and current_currency.id or False,
                    'amount_currency': company_currency !=
                                       current_currency and self.amount or 0.0,
                    'partner_id': self.asset_id.partner_id.id,
                }

                move_line_2 = {
                    'name': asset_name,
                    'account_id': category_id.account_depreciation_id.id,
                    'credit': 0.0 if float_compare(dep_value, 0.0, precision_digits=prec) > 0 else -dep_value,
                    'debit': dep_value if float_compare(dep_value, 0.0, precision_digits=prec) > 0 else 0.0,
                    'journal_id': category_id.journal_id.id,
                    'analytic_distribution': distribution
                    if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                    # 'currency_id': company_currency != current_currency and current_currency.id or False,
                    'amount_currency': company_currency !=
                                       current_currency and self.amount or 0.0,
                }

                if amount >= asset_id.value_residual:
                    revenue = amount - asset_id.value_residual + line.asset_id.salvage_value
                    move_line_3 = {
                        'account_id': line.asset_id.category_id.account_sale_revenue.id,
                        'debit': 0.0 if float_compare(revenue, 0.0, precision_digits=prec) > 0 else -revenue,
                        'credit': revenue if float_compare(revenue, 0.0, precision_digits=prec) > 0 else 0.0,
                        'journal_id': category_id.journal_id.id,
                        'analytic_distribution': distribution
                        if category_id.type == 'purchase' else False,
                        'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                        # 'currency_id': company_currency != current_currency and current_currency.id or False,
                        'amount_currency': company_currency !=
                                           current_currency and self.amount or 0.0,
                    }

                if amount < asset_id.value_residual:
                    lost = asset_id.value_residual - amount + line.asset_id.salvage_value
                    move_line_3 = {
                        'name': asset_name,
                        'account_id': line.category_id.account_sale_lost.id,
                        'credit': 0.0 if float_compare(lost, 0.0, precision_digits=prec) > 0 else -lost,
                        'debit': lost if float_compare(lost, 0.0, precision_digits=prec) > 0 else 0.0,
                        'journal_id': category_id.journal_id.id,
                        # 'analytic_account_id': category_id.account_analytic_id.id
                        # if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                        # 'currency_id': company_currency !=current_currency and current_currency.id or False,
                        'amount_currency': company_currency !=
                                           current_currency and self.amount or 0.0,
                    }

                move_line_4 = {
                    'name': asset_name, 'account_id': line.asset_id.category_id.account_asset_id.id, 'debit': 0.0
                    if float_compare(line.asset_id.value, 0.0, precision_digits=prec) > 0 else -line.asset_id.value,
                    'credit': line.asset_id.value
                    if float_compare(line.asset_id.value, 0.0, precision_digits=prec) > 0 else 0.0,
                    'journal_id': category_id.journal_id.id,
                    'analytic_distribution': distribution
                    if category_id.type == 'purchase' else False,
                    'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                    # 'currency_id': company_currency != current_currency and current_currency.id or False,
                    'amount_currency': company_currency !=
                                       current_currency and self.amount or 0.0, }

                move_vals = {
                    'ref': line.asset_id.code,
                    'date': date or False,
                    'journal_id': category_id.journal_id.id,
                    'line_ids': [(0, 0, move_line_1), (0, 0, move_line_2), (0, 0, move_line_3), (0, 0, move_line_4)],
                }

                move = self.env['account.move'].create(move_vals)
                line.write({'move_id': move.id, 'move_check': True})

                line.asset_id.write({'state': 'sold'})

                if move:
                    move._post()

    def abandon(self):
        for line in self:
            created_moves = self.env['account.move']
            prec = line.env['decimal.precision'].precision_get('Account')
            asset_name = line.name
            asset_id = line.asset_id
            type = line.type
            category_id = line.asset_id.category_id
            date = line.date

            account_asset_id = False

            company_currency = line.asset_id.company_id.currency_id
            current_currency = line.asset_id.currency_id

            dep_value = line.asset_id.value - line.asset_id.value_residual - line.asset_id.salvage_value
            account_id = category_id.account_pl_id
            dis_list = {category_id.account_analytic_id.id}
            distribution = dict.fromkeys(dis_list, 100)
            amount = line.asset_id.value - dep_value
            move_line_1 = {
                'name': asset_name,
                'account_id': account_id.id,
                'credit': 0.0 if float_compare(amount, 0.0, precision_digits=prec) > 0 else -amount,
                'debit': amount if float_compare(amount, 0.0, precision_digits=prec) > 0 else 0.0,
                'journal_id': category_id.journal_id.id,
                'analytic_distribution': distribution
                if category_id.type == 'purchase' else False,
                'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                # 'currency_id': company_currency !=current_currency and current_currency.id or False,
                'amount_currency': company_currency !=
                                   current_currency and self.amount or 0.0,
            }
            move_line_2 = {
                'name': asset_name,
                'account_id': category_id.account_depreciation_id.id,
                'credit': 0.0 if float_compare(dep_value, 0.0, precision_digits=prec) > 0 else -dep_value,
                'debit': dep_value if float_compare(dep_value, 0.0, precision_digits=prec) > 0 else 0.0,
                'journal_id': category_id.journal_id.id,
                'analytic_distribution': distribution
                if category_id.type == 'purchase' else False,
                'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                # 'currency_id': company_currency != current_currency and current_currency.id or False,
                'amount_currency': company_currency !=
                                   current_currency and self.amount or 0.0,
            }
            move_line_3 = {
                'name': asset_name, 'account_id': account_id.id, 'debit': 0.0
                if float_compare(line.asset_id.value, 0.0, precision_digits=prec) > 0 else -line.asset_id.value,
                'credit': line.asset_id.value
                if float_compare(line.asset_id.value, 0.0, precision_digits=prec) > 0 else 0.0,
                'journal_id': category_id.journal_id.id,
                'analytic_distribution': distribution
                if category_id.type == 'purchase' else False,
                'currency_id': company_currency != current_currency and current_currency.id or company_currency.id,
                # 'currency_id': company_currency != current_currency and current_currency.id or False,
                'amount_currency': company_currency !=
                                   current_currency and self.amount or 0.0, }
            move_vals = {
                'ref': line.asset_id.code,
                'date': date or False,
                'journal_id': category_id.journal_id.id,
                'line_ids': [(0, 0, move_line_1), (0, 0, move_line_2), (0, 0, move_line_3)],
            }

            move = self.env['account.move'].create(move_vals)
            line.write({'move_id': move.id, 'move_check': True, 'amount': amount})

            line.asset_id.write({'state': 'close'})

            if move:
                move._post()