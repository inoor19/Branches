# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import models, fields, api, _
from datetime import date
from odoo.exceptions import UserError


class AssetCustomReport(models.TransientModel):
    _name = 'asset.custom.report'

    category_ids = fields.Many2many('account.asset.category')
    asset_ids = fields.Many2many('account.asset.asset', string='Asset')
    report_show = fields.Selection([('sum', 'Summation By Categories'),
                                    ('details', 'Details By Assets')], default='sum', required=1)
    # default date is first day of the current year
    date_from = fields.Date(
        required=1, default=lambda self: date(date.today().year, 1, 1))
    # default date is last day of the current year
    date_to = fields.Date(
        required=1, default=lambda self: date(date.today().year, 12, 31))

    @api.onchange('category_ids')
    def set_category_asset_ids(self):
        """
        If user select a category then filter o2m accounts
        :return:
        """
        # Map categories
        categrory_ids = tuple(self.mapped('category_ids').ids)
        if len(categrory_ids) != 0:
            ids = self.env['account.asset.asset'].search(
                [('category_id', 'in', categrory_ids)])
            tuple_ids = [id.id for id in ids]

            return {'domain': {'asset_ids': [('id', 'in', tuple_ids)]}}
        else:
            return {'domain': {'asset_ids': []}}

    def print_report(self):
        """
        Print Asset Report
        :return:
        """
        if self.date_from > self.date_to:
            raise UserError(
                _("""Date From must be less or equal to Date To!!"""))
        # collect data
        data = {}
        data.update(report_show=self.report_show)
        data.update(date_from=self.date_from)
        data.update(date_to=self.date_to)
        category_filter = []
        categrory_ids = tuple(self.mapped('category_ids').ids)
        if len(categrory_ids) != 0:
            category_filter.append(('id', 'in', categrory_ids))
        # sum of all categories
        super_sum_init_value = 0
        super_sum_added = 0
        super_sum_abandoned = 0
        super_sum_deprciation = 0
        super_sum_abandoned_deprciation = 0
        super_sum_old_deprciation = 0
        super_sum_net_book = 0
        super_sum_salvage = 0.0
        # for Total of data
        all_data = []
        # for row data
        asset_added = 0.0
        asset_abandon = 0.0
        init_value = 0.0
        asset_depreciation = 0.0
        old_asset_deprciation = 0.0
        asset_previous_dep = 0.0
        asset_total = 0.0
        abandoned_deprciation = 0.0
        asset_salvage = 0.0

        for categ in self.env['account.asset.category'].search(category_filter):
            all_sub_data = []
            # sum per category
            sum_init_value = 0
            sum_added = 0
            sum_abandoned = 0
            sum_deprciation = 0
            sum_old_deprciation = 0
            sum_abandoned_deprciation = 0
            sum_prev_deprciation = 0
            sum_net_book = 0
            categ_salvage = 0.0

            asset_list = [('state', 'in', ('open', 'close')), ('category_id', '=', categ.id)]
            if self.report_show == 'details':
                asset_ids = tuple(self.mapped('asset_ids').ids)
                if len(asset_ids) != 0:
                    asset_list.append(('id', 'in', asset_ids))

            for asset in self.env['account.asset.asset'].search(asset_list):

                if asset.depreciation_line_ids.filtered(
                        lambda x: x.depreciation_date <= self.date_to):

                    # get salvage value
                    asset_salvage = asset.salvage_value
                    categ_salvage += asset_salvage

                    # compute initial balance
                    period_balance = asset.depreciation_line_ids.filtered(
                        lambda x: x.move_posted_check == True and x.depreciation_date < self.date_from).mapped(
                        'depreciated_value')
                    if period_balance:
                        init_value = asset.initial_value - period_balance[-1]
                        sum_init_value += init_value
                    else:
                        init_value = 0.0

                    # compute abandon depreciation

                    if asset.filtered(
                            lambda a: a.state == 'close'):
                        abandon_dep = asset.depreciation_line_ids.filtered(
                            lambda
                                x: x.move_posted_check == True and self.date_from <= x.depreciation_date <= self.date_to)

                        if abandon_dep:
                            abandoned_deprciation = sum(asset.depreciation_line_ids.filtered(
                                lambda
                                    x: x.move_posted_check == True and self.date_from <= x.depreciation_date <= self.date_to).mapped(
                                'amount'))
                            sum_abandoned_deprciation += abandoned_deprciation
                        else:
                            abandoned_deprciation = 0.0

                    # compute added
                    added = asset.read_group(
                        [('id', '=', asset.id), ('date', '>=', self.date_from), ('date', '<=', self.date_to)],
                        ['initial_value'], [])

                    asset_added = added[0]['initial_value'] if added[0]['initial_value'] is not None else 0
                    sum_added += asset_added

                    # compute abandoned
                    if asset.filtered(
                            lambda a: a.state == 'close'):
                        abandon_dep = asset.depreciation_line_ids.filtered(
                            lambda
                                x: self.date_from <= x.depreciation_date <= self.date_to).mapped(
                            'amount')

                        if abandon_dep:
                            asset_abandon = abandon_dep[-1]
                            sum_abandoned += asset_abandon

                    # period depreciation
                    depreciation = asset.depreciation_line_ids.read_group(
                        [('asset_id', '=', asset.id), ('move_posted_check', '=', True),
                         ('depreciation_date', '>=',
                          self.date_from), ('depreciation_date', '<=', self.date_to),
                         ('purchase_date', '>=',
                          self.date_from), ('purchase_date', '<=', self.date_to)
                         ],
                        ['amount'], [])
                    # old depreciation
                    old_depreciation = asset.depreciation_line_ids.read_group(
                        [('asset_id', '=', asset.id), ('move_posted_check', '=', True),
                         ('depreciation_date', '>=',
                          self.date_from), ('depreciation_date', '<=', self.date_to),
                         ('purchase_date', '<', self.date_from)
                         ],
                        ['amount'], [])
                    asset_depreciation = depreciation[0]['amount'] if depreciation[0]['amount'] is not None else 0
                    old_asset_deprciation = old_depreciation[0]['amount'] if old_depreciation[0]['amount'] is not None \
                        else 0
                    sum_deprciation += asset_depreciation
                    sum_old_deprciation += old_asset_deprciation

                    # compute previous depreciation
                    prev_depreciation = asset.depreciation_line_ids.read_group(
                        [('asset_id', '=', asset.id),
                         ('depreciation_date', '<', self.date_from), ('move_posted_check', '=', True)],
                        ['amount'], [])
                    asset_previous_dep = prev_depreciation[0]['amount'] if prev_depreciation[0]['amount'] is not None \
                        else 0
                    sum_prev_deprciation += asset_previous_dep

                    new_purchase_value = (
                            sum_init_value
                            +
                            sum_added
                            -
                            sum_abandoned
                    )

                    new_accumlated = sum_deprciation + sum_old_deprciation + sum_abandoned_deprciation
                    sum_net_book += new_purchase_value - new_accumlated
                    # new code
                    asset_total = init_value + asset_added - asset_abandon

                    asset_accumulate = asset_depreciation + old_asset_deprciation + abandoned_deprciation

                    all_sub_data.append([
                        asset.name,  # 0
                        init_value,  # 1
                        asset_added,  # 2
                        asset_abandon,  # 3
                        asset_total - asset_salvage,  # 4
                        asset.category_id.method_number,  # 5
                        asset_depreciation,  # 6
                        old_asset_deprciation,  # 7
                        abandoned_deprciation,  # 8
                        asset_accumulate,  # 9

                        asset_total - asset_accumulate,  # 10
                        asset.date if asset.date else '',  # 11
                        # accumulated_depreciation#11

                    ])
                    all_sub_data = list(
                        filter(lambda a: a[1] != 0 or a[2] != 0 or a[3] != 0 or a[6] != 0 or a[7] != 0 or a[8] != 0,
                               all_sub_data))

            # new code
            sum_accumulative_category = sum_deprciation + sum_old_deprciation + sum_abandoned
            categ_assets_total = sum_init_value + sum_added - sum_abandoned

            all_data.append([categ.name,  # 0
                             all_sub_data,  # 1
                             sum_init_value,  # 2
                             sum_added,  # 3
                             sum_abandoned,  # 4
                             categ_assets_total - categ_salvage,  # 5
                             '-',  # 6
                             sum_deprciation,  # 7
                             sum_old_deprciation,  # 8
                             sum_abandoned_deprciation,  # 9

                             sum_deprciation + sum_old_deprciation - sum_abandoned_deprciation,  # 10
                             sum_deprciation + sum_old_deprciation - sum_abandoned_deprciation,  # 11
                             categ_assets_total - sum_accumulative_category,  # 12
                             '-',  # 13

                             ])
            all_data = list(
                filter(lambda a: a[2] != 0 or a[3] != 0 or a[4] != 0 or a[7] != 0 or a[8] != 0 or a[9] != 0,
                       all_data))
            # sum of all categories
            super_sum_init_value += sum_init_value
            super_sum_added += sum_added
            super_sum_abandoned += sum_abandoned
            super_sum_deprciation += sum_deprciation
            super_sum_abandoned_deprciation += sum_abandoned_deprciation
            super_sum_old_deprciation += sum_old_deprciation
            super_sum_net_book += sum_net_book
            total_init = super_sum_init_value + super_sum_added - super_sum_abandoned
            accumlative = super_sum_deprciation + \
                          super_sum_old_deprciation - super_sum_abandoned_deprciation
            super_sum_salvage += super_sum_salvage

        all_data.append([_('Totals'),
                         [],
                         super_sum_init_value,
                         super_sum_added,
                         super_sum_abandoned,
                         total_init - super_sum_salvage,
                         '-',
                         super_sum_deprciation,
                         super_sum_old_deprciation,
                         super_sum_abandoned_deprciation,
                         super_sum_deprciation - super_sum_abandoned_deprciation + super_sum_old_deprciation,
                         super_sum_deprciation - super_sum_abandoned_deprciation + super_sum_old_deprciation,
                         total_init - accumlative,
                         # accumulated_depreciation
                         ])

        data.update({'self': self})
        data.update({'report_data': all_data})

        # run report
        return self.env.ref('account_asset.action_account_asset_custom').with_context(
            landscape=True).report_action(
            self, data=data)


class AssetMainReportTamplate(models.AbstractModel):
    _name = 'report.account_asset.asset_main_report_tamplate'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'data': data,
            'asset_category': self.env['account.asset.category'],
            'asset_self': self.env['account.asset.asset'],
            'report_self': self.env['asset.custom.report']
            # 'get':self.env['budget.custom.report'],
            # 'current_model': self.env['budget.custom.report.main']
        }
