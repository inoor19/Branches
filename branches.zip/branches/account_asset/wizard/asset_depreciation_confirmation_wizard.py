# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import api, fields, models, _


class AssetDepreciationConfirmationWizard(models.TransientModel):
    _name = "asset.depreciation.confirmation.wizard"
    _description = "asset.depreciation.confirmation.wizard"

    asset_ids = fields.Many2many('account.asset.asset', relation='account_asset_category_asset_rel')
    category_ids = fields.Many2many('account.asset.category', relation='account_asset_category_depreciation_rel')
    date = fields.Date('Account Date Start', required=True,
                       help="Choose Account Date Start for which you want to automatically post the depreciation "
                            "lines of running assets",
                       default=fields.Date.context_today)
    date_end = fields.Date('Account Date End', required=False,
                           help="Choose Account Date End for which you want to automatically post the depreciation "
                                "lines of running assets",
                           default=fields.Date.context_today)

    def asset_compute(self):
        self.ensure_one()
        context = self._context

        if len(self.asset_ids) > 0:
            asset_ids = list(asset.id for asset in self.asset_ids)
        else:
            asset_ids = False

        if len(self.category_ids) > 0:
            category_ids = list(category.id for category in self.category_ids)
        else:
            category_ids = False

        created_move_ids = self.env['account.asset.asset'].compute_generated_entries(self.date, date_end=self.date_end,
        asset_type=context.get('asset_type'), asset_ids=asset_ids, category_ids=category_ids)

        return {
            'name': _('Created Asset Moves') if context.get('asset_type') == 'purchase' else _('Created Revenue Moves'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'domain': "[('id','in',[" + ','.join(str(id) for id in created_move_ids) + "])]",
            'type': 'ir.actions.act_window',
        }
