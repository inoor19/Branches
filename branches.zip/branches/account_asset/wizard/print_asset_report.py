# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, models, _


class budgetCustomReport(models.AbstractModel):
    _name = 'report.account_asset.print_asset_custom_template'


    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'data': data,
            'id':docids,
            'asset':self.env['account.asset.asset'].search([('id','=',docids)])
            #'get':self.env['budget.custom.report'],
            #'current_model': self.env['budget.custom.report.main']
        }
