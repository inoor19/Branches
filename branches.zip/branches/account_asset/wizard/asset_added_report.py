# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models, fields, api, _
from datetime import date, datetime
from odoo.exceptions import UserError
import datetime


class AssetAddedReport(models.TransientModel):
    _name = 'asset.added.report'

    category_ids = fields.Many2many('account.asset.category')
    asset_ids = fields.Many2many('account.asset.asset', string='Asset')

    report_show = fields.Selection([('sum', 'Summation By Categories'),
                                    ('details', 'Details By Assets')], default='sum', required=1)
    # default date is first day of the current year
    date_from = fields.Date(required=1, default=lambda self: date(date.today().year, 1, 1))
    # default date is last day of the current year
    date_to = fields.Date(required=1, default=lambda self: date(date.today().year, 12, 31))

    @api.onchange('category_ids')
    def set_category_asset_ids(self):
        """
        If user select a category then filter o2m accounts
        :return:
        """
        # Map categories
        categrory_ids = tuple(self.mapped('category_ids').ids)
        if len(categrory_ids) != 0:
            ids = self.env['account.asset.asset'].search([('category_id', 'in', categrory_ids)])
            tuple_ids = [id.id for id in ids]

            return {'domain': {'asset_ids': [('id', 'in', tuple_ids)]}}
        else:
            return {'domain': {'asset_ids': []}}

    def print_report(self):
        """
        Print Asset Report
        :return:
        """
        if self.date_from > self.date_to:
            raise UserError(_("""Date From must be less or equal to Date To!!"""))
        # collect data
        data = {}
        data.update(report_show=self.report_show)
        data.update(date_from=self.date_from)
        data.update(date_to=self.date_to)
        category_filter = []
        categrory_ids = tuple(self.mapped('category_ids').ids)
        if len(categrory_ids) != 0:
            category_filter.append(('id', 'in', categrory_ids))
        # sum of all categories
        super_sum_init_value = 0
        super_sum_deprciation = 0
        super_sum_count = 0
        # for Total of data
        all_data = []
        # for row data
        all_sub_data = []
        asset_model = self.env['account.asset.asset']
        for categ in self.env['account.asset.category'].search(category_filter):
            asset_filter = [('category_id', '=', categ.id), ('date', '>=', self.date_from),
                            ('date', '<=', self.date_to)]
            if self.report_show == 'details':
                asset_ids = tuple(self.mapped('asset_ids').ids)
                if len(asset_ids) != 0:
                    asset_filter.append(('id', 'in', asset_ids))
            # sum per category
            sum_init_value = 0
            sum_deprciation = 0
            count = 0
            # to restart (empty)
            all_sub_data = []
            names = []
            for asset in self.env['account.asset.asset'].with_context({'group_by': 'date'}).read_group(asset_filter,
                                                                                                       fields=['date',
                                                                                                               'name'],
                                                                                                       groupby=[
                                                                                                           'date:day',
                                                                                                           'name'],
                                                                                                       orderby='date',
                                                                                                       lazy=False):
                name = asset.get('name')
                # convert date because read_group change any Date type To HELISH FORMAT THING *_* .
                # model.py line 1743
                new_date = datetime.datetime.strptime(asset.get('date:day'), '%d %b %Y').strftime('%m-%d-%Y')
                sum_init = asset_model.read_group(
                    [('name', '=', name), ('date', '<=', self.date_to), ('date', '=', new_date),
                     ('category_id', '=', categ.id)], ['initial_value'], [])
                sum_init_value += sum_init[0]['initial_value'] if sum_init[0]['initial_value'] is not None else 0
                depreciation = asset_model.depreciation_line_ids.read_group(
                    [('asset_id.name', '=', name), ('asset_id.active', '=', True), ('asset_id.date', '=', new_date),
                     ('asset_id.category_id', '=', categ.id), ('move_posted_check', '=', True),
                     ('depreciation_date', '>=', self.date_from), ('depreciation_date', '<=', self.date_to)],
                    ['amount'], [])
                sum_deprciation += depreciation[0]['amount'] if depreciation[0]['amount'] is not None else 0
                count += asset.get('__count', 0)
                asset_id = asset_model.browse(sum_init[0]['id'])
                all_sub_data.append([
                    name,
                    new_date,
                    sum_init[0]['initial_value'] if sum_init[0]['initial_value'] is not None else 0,
                    depreciation[0]['amount'] if depreciation[0]['amount'] is not None else 0,
                    asset.get('__count', 0),
                    # asset_id.department_id.name
                ])
            # sum of all categories
            super_sum_init_value += sum_init_value
            super_sum_deprciation += sum_deprciation
            super_sum_count += count
            # new code
            if count > 0:
                all_data.append([categ.name,
                                 all_sub_data,
                                 sum_init_value,
                                 sum_deprciation,
                                 count,
                                 ])
        all_data.append([_('Totals'),
                         [],
                         super_sum_init_value,
                         super_sum_deprciation,
                         super_sum_count,
                         ])
        data.update({'self': self})
        data.update({'report_data': all_data})
        # run report
        return self.env.ref('account_asset.action_report_asset_added').with_context(landscape=True).report_action(
            self, data=data)


class AssetAddedReportTamplate(models.AbstractModel):
    _name = 'report.account_asset.asset_added_report_tamplate'

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'data': data,
            'asset_category': self.env['account.asset.category'],
            'asset_self': self.env['account.asset.asset'],
            'report_self': self.env['asset.custom.report']
            # 'get':self.env['budget.custom.report'],
            # 'current_model': self.env['budget.custom.report.main']
        }
