# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'Account Assets Management',
    'version': '1.0',
    'category': 'Accounting',
    'summary': 'Assets Management and Depreciations',
    'description': """Manage assets owned by a company or a person.     
    Keeps track of depreciation's, and creates corresponding journal entries""",
    "author": "NCTR",
    "website": "http://www.nctr.sd",
    'depends': ['account', 'base_custom'],
    'license': 'LGPL-3',
    'images': ['static/description/assets.gif'],
    'data': [
        'data/account_asset_data.xml',
        'security/account_asset_security.xml',
        'security/ir.model.access.csv',
        'wizard/asset_added_report.xml',
        'wizard/asset_custom_report.xml',
        'wizard/asset_depreciation_confirmation_wizard_views.xml',
        'wizard/asset_modify_views.xml',
        'views/asset_category_views.xml',
        'views/account_asset_views.xml',
        'views/account_move_views.xml',
        'views/account_asset_templates.xml',
        'views/account_asset_operation.xml',
        'views/config_view.xml',
        'views/product_views.xml',
        'report/asset_custom_report_added_template.xml',
        'report/asset_custom_report_template.xml',
        'report/print_asset_custom_report_template.xml',
        'report/account_asset_report_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'account_asset/static/src/scss/account_asset.scss',
            'account_asset/static/src/js/account_asset.js',
        ],
        'web.qunit_suite_tests': [
            ('after', 'web/static/tests/legacy/views/kanban_tests.js',
             '/account_asset/static/tests/account_asset_tests.js'),
        ],
    },
}
