# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import api, fields, models, tools, _
from odoo.addons import decimal_precision as dp

class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    loan_ids = fields.One2many('hr.loan.archive', 'payslip_id', string='Loans', readonly=True)
    total_loan = fields.Float(compute='compute_basic_net', digits=dp.get_precision('Payroll'), string="Total Loans", store=True, readonly=True)

    @api.depends('line_ids', 'line_ids.total','loan_ids')
    def compute_basic_net(self):
        for payslip in self:
            payslip.basic_wage = 0.0
            payslip.total_allow = 0.0
            payslip.total_deduct = 0.0
            payslip.net_wage = 0.0
            payslip.total_loan = 0.0
            if payslip.type == 'salary':
                payslip.total_loan = payslip.loan_ids and sum(payslip.loan_ids.mapped('amount')) or 0.0
                payslip.basic_wage = payslip._get_salary_line_total('BASIC')
                payslip.net_wage = payslip._get_salary_line_total('NET') - payslip.total_loan
                payslip.total_allow = payslip._get_payslip_line_total('ALW')
                payslip.total_deduct = payslip._get_payslip_line_total('DED')
            else:
                payslip.total_loan = payslip.loan_ids and sum(payslip.loan_ids.mapped('amount')) or 0.0
                payslip.total_allow = payslip._get_payslip_line_total('MonALW')
                payslip.total_allow += payslip._get_payslip_line_total('QrALW')
                payslip.total_allow += payslip._get_payslip_line_total('YearALW')
                payslip.total_allow += payslip._get_payslip_line_total('BONUS')
                payslip.total_deduct = payslip._get_payslip_line_total('DED')
                payslip.net_wage = payslip.total_allow - payslip.total_deduct - payslip.total_loan

    def rollback_loan(self):
        for payslip in self:
            payslip.loan_ids.action_paid()
        return True

    def compute_sheet(self):
        super(HrPayslip, self).compute_sheet()
        loans = self.env['hr.loan.archive']
        for payslip in self:
            payslip.loan_ids.action_paid()
            if payslip.payslip_run_id.type =='salary':
                loan_ids = self.env['hr.loan.archive'].search([
		                ('employee_id', '=', payslip.employee_id.id),
		                ('payment_type', '=', 'salary'),
		                ('state', '=', 'paid'),
		                ('start_date','>=',payslip.date_from),
		                ('end_date','<=',payslip.date_to) ])
            else:
                loan_ids = self.env['hr.loan.archive'].search([
		                ('employee_id', '=', payslip.employee_id.id),
		                ('payment_type', '=', 'bonus'),
		                ('state', '=', 'paid'),
		                ('bonus_id', 'in', payslip.payslip_run_id.bonus_ids.ids),
		                ('start_date','>=',payslip.date_from),
		                ('end_date','<=',payslip.date_to) ])		                
            loan_ids.write({'payslip_id': payslip.id})
            loan_ids.action_done()
        return True
            
            
class HrPayslipRun(models.Model):
    _inherit = 'hr.payslip.run'

    def rollback_payslip_run(self):
        self.slip_ids.rollback_loan()
        super(HrPayslipRun,self).rollback_payslip_run()



    def get_move_line(self):
        lines = super(HrPayslipRun, self).get_move_line()

        #Loans 
        for slip in self.slip_ids:
            for loan in slip.loan_ids:
                if not loan.loan_type_id.loan_account_id:
                    raise UserError(_('No Account defined for loan  (%s).') % (loan.loan_type_id.name))
                line = {
                    'name' : loan.employee_id.name,
                    'account_id':loan.loan_type_id.loan_account_id.id,
                    'quantity':1,
                    'price_unit': -loan.amount,
                    'tax_ids': [],
                    'partner_id': loan.employee_id.address_home_id.id,
                }
                lines.append(line)  
        return lines
