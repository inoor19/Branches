# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>)..
#
##############################################################################

from odoo import api, fields, models, _
from datetime import date, datetime
from odoo.exceptions import UserError, ValidationError
from dateutil import relativedelta
import time


class HrLoan(models.Model):
    _name = 'hr.loan'
    _inherit = ['mail.thread']
    _description = "Loans Requests"
    _order = "date desc, id desc"

    def _default_employee(self):
        return self.env.context.get('default_employee_id') or self.env['hr.employee'].search(
            [('user_id', '=', self.env.uid)], limit=1)

    name = fields.Char(string="Loan Name", default="/", readonly=True)
    date = fields.Date(string="Request Date", default=fields.Date.today(), readonly=True)
    payment_date = fields.Date(string="Payment Start Date", required=True, default=fields.Date.today())
    loan_id = fields.Many2one('hr.loan.type', string='Loan Type', required=True, tracking=True, readonly=True,
        states={'draft': [('readonly', False)]})
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, readonly=True,
        states={'draft': [('readonly', False)]}, default=_default_employee)
    department_id = fields.Many2one('hr.department', related="employee_id.department_id", readonly=True, string="Department", tracking=True)
    refund_from = fields.Selection([
        ('salary', 'Salary'),
        ('bonus', 'Bonus'),
        ('salary_bonus', 'Salary & Bonus')
    ], default='salary', required=True, string='Refund From', tracking=True)
    # refund_from_salary
    salary_installment = fields.Integer(string="Salary Installments", required=False, default=1)
    salary_loan_amount = fields.Float(string="Salary Loan Amount", required=False)
    salary_installment_amount = fields.Float(string="Salary Installment Amount", required=False)
    paid_from_salary = fields.Float(string="Paid From Salary", compute='_amount_all', store=True,readonly=True)
    # refund_from_bonus
    bonus_installment = fields.Integer(string="Bonus Installments", required=False, default=1)
    bonus_loan_amount = fields.Float(string="Bonus Loan Amount", required=False)
    bonus_installment_amount = fields.Float(string="Bonus Installment Amount", required=False)
    paid_from_bonus = fields.Float(string="Paid From Bonus", compute='_amount_all', store=True,readonly=True)
    installment = fields.Integer(string="No Of Installments", required=False, default=1)
    loan_amount = fields.Float(string="Loan Amount", required=True)
    installment_amount = fields.Float(string="Installment Amount", required=False)
    remain_amount = fields.Float(string="Remain Amount", compute='_amount_all', store=True, readonly=True)
    total_paid_amount = fields.Float(string="Total Paid Amount", compute='_amount_all', store=True, readonly=True)
    loan_arc_ids = fields.One2many('hr.loan.archive', 'loan_id', string='Installments', index=True)
    company_id = fields.Many2one('res.company', 'Company', readonly=True, default=lambda self: self.env.user.company_id,
         states={'draft': [('readonly', False)]})
    move_id = fields.Many2one('account.move', string='Move Voucher', readonly=True,copy=False)
    remission_move_id = fields.Many2one('account.move', string='Remission Voucher', readonly=True,copy=False)
    note = fields.Html(string='Notes')
    reject_reason = fields.Text(string='Reject Reason')
    remission = fields.Boolean(string='Remission')
    remission_amount = fields.Float(string="Remission Amount")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('paid', 'Paid'),
        ('done', 'Done'),
        ('rejected', 'Rejected')], string="State", default='draft', tracking=True, copy=False )
    loan_bonus_ids = fields.One2many('hr.loan.bonus', 'loan_id', string='Installments')


    @api.depends(
    'loan_amount',
    'salary_loan_amount', 
    'bonus_loan_amount',
    'loan_arc_ids', 
    'loan_arc_ids.state')
    def _amount_all(self):
        for loan in self:
            loan.total_paid_amount = sum(loan.loan_arc_ids.filtered(lambda x: x.state=='done').mapped('amount'))
            loan.paid_from_salary = sum(loan.loan_arc_ids.filtered(lambda x: x.state=='done' and x.payment_type=='salary').mapped('amount'))
            loan.paid_from_bonus = sum(loan.loan_arc_ids.filtered(lambda x: x.state=='done' and x.payment_type=='bonus').mapped('amount'))
            loan.remain_amount = loan.loan_amount - loan.total_paid_amount

    def name_get(self):
        res = []
        for rec in self:
            if rec.loan_id:
                name = "%s / %s" % (rec.loan_id.name, rec.name)
                res += [(rec.id, name)]
            else:
                res += [(rec.id, rec.name)]
        return res

            
    def unlink(self):
        for loan in self:
            if loan.state not in ('draft'):
                raise UserError(_('You cannot delete a loan which is not draft!'))
            loan.loan_arc_ids.unlink()
        return super(HrLoan, self).unlink()

    @api.model
    def create(self, vals):
        if vals.get('name', '/') == '/':
            vals['name'] = self.env['ir.sequence'].next_by_code('hr.loan.seq') or '/'
        return super(HrLoan, self).create(vals)

    @api.constrains('loan_amount')
    def _check_amount(self):
        loan_amount = 0.0
        for rec in self:
            if rec.loan_id.loan_type == "fixed":
                if rec.loan_id.loan_amount != rec.loan_amount and not rec.loan_id.change_loan_amount:
                    raise ValidationError(_('Loan amount'))
            else:
                for rule in self.loan_id.salary_rule_ids:
                    loan_amount += rule.compute_allowed_deduct_amount(self.employee_id.contract_id)
                if loan_amount != rec.loan_amount and not rec.loan_id.change_loan_amount:
                    raise ValidationError(_('Loan amount'))

    @api.constrains('installment')
    def _check_installment(self):
        for rec in self:
            if rec.loan_id.refund_from == "salary":
                if rec.loan_id.installment != rec.installment and not rec.loan_id.change_installment_no:
                    raise ValidationError(_('installment no'))

    @api.constrains('installment')
    def _check_installment(self):
        for rec in self:
            if rec.loan_id.refund_from == "bonus":
                if rec.loan_id.bonus_installment != rec.bonus_installment and not rec.loan_id.change_installment_no:
                    raise ValidationError(_('installment no'))


    @api.onchange('loan_id', 'employee_id')
    def onchange_loan_id(self):
        if not self.loan_id:
            return
        if self.loan_id.remission != 'no':
            self.remission_amount = 0.0
        loan_amount = 0.0
        if self.loan_id.loan_type == 'fixed':
            loan_amount = self.loan_id.loan_amount
        else:
            for rule in self.loan_id.salary_rule_ids:
                loan_amount += rule.compute_allowed_deduct_amount(self.employee_id.contract_id)
            if self.loan_id.max_loan_amount > 0:
                if loan_amount > self.loan_id.max_loan_amount:
                    loan_amount = self.loan_id.max_loan_amount
        # remission
        if self.loan_id.remission_type == 'amount':
            self.remission_amount = self.loan_id.remission
        if self.loan_id.remission_type == 'percentage':
            self.remission_amount = self.loan_id.remission * loan_amount / 100
        self.loan_amount = loan_amount
        self.refund_from = self.loan_id.refund_from
            
    @api.onchange('loan_amount','refund_from')
    def onchange_loan_amount(self):
        if not self.loan_id:
            return
        self.loan_bonus_ids = [(5, 0, 0)]
        loan_amount = self.loan_amount - self.remission_amount
        if self.refund_from == 'salary':
            self.salary_installment = self.loan_id.installment
            self.salary_installment_amount = loan_amount  / self.salary_installment
            
        elif self.refund_from == 'bonus':
            self.bonus_installment = self.loan_id.bonus_installment
            self.bonus_installment_amount = loan_amount  / self.bonus_installment
            bonus_lines =[]
            for bonus in self.loan_id.loan_type_bonus_ids:
                bonus_vals ={
                    'bonus_id': bonus.bonus_id.id, 
                    'bonus_amount': loan_amount  * bonus.percentage / 100,
                    'installment': bonus.installment 
                }
                bonus_lines.append((0, 0, bonus_vals))
            self.loan_bonus_ids = bonus_lines
            
        elif self.refund_from == 'salary_bonus':
            self.salary_installment = self.loan_id.installment
            self.bonus_installment = self.loan_id.bonus_installment
            self.bonus_loan_amount = loan_amount  * self.loan_id.bonus_percentage / 100
            self.salary_loan_amount = loan_amount  - self.bonus_loan_amount
            self.salary_installment_amount = self.salary_loan_amount / self.salary_installment
            self.bonus_installment_amount = self.bonus_loan_amount / self.bonus_installment
            bonus_lines =[]
            for bonus in self.loan_id.loan_type_bonus_ids:
                bonus_vals ={
                    'bonus_id': bonus.bonus_id.id, 
                    'bonus_amount': self.bonus_loan_amount * bonus.percentage / 100,
                    'installment': bonus.installment 
                }
                bonus_lines.append((0, 0, bonus_vals))
            self.loan_bonus_ids = bonus_lines
            
    @api.onchange('salary_installment','bonus_installment')
    def onchange_loan_installment(self):
        if not self.loan_id:
            return
        self.loan_bonus_ids = [(5, 0, 0)]
        loan_amount = self.loan_amount - self.remission_amount
        if self.refund_from == 'salary':
            self.salary_installment_amount = loan_amount  / self.salary_installment
            
        elif self.refund_from == 'bonus':
            self.bonus_installment_amount = loan_amount  / self.bonus_installment
            bonus_lines =[]
            for bonus in self.loan_id.loan_type_bonus_ids:
                bonus_vals ={
                    'bonus_id': bonus.bonus_id.id, 
                    'bonus_amount': loan_amount  * bonus.percentage / 100,
                    'installment': bonus.installment 
                }
                bonus_lines.append((0, 0, bonus_vals))
            self.loan_bonus_ids = bonus_lines
            
        elif self.refund_from == 'salary_bonus':
            self.bonus_loan_amount = loan_amount  * self.loan_id.bonus_percentage / 100
            self.salary_loan_amount = loan_amount  - self.bonus_loan_amount
            self.salary_installment_amount = self.salary_loan_amount / self.salary_installment
            self.bonus_installment_amount = self.bonus_loan_amount / self.bonus_installment
            bonus_lines =[]
            for bonus in self.loan_id.loan_type_bonus_ids:
                bonus_vals ={
                    'bonus_id': bonus.bonus_id.id, 
                    'bonus_amount': self.bonus_loan_amount * bonus.percentage / 100,
                    'installment': bonus.installment 
                }
                bonus_lines.append((0, 0, bonus_vals))
            self.loan_bonus_ids = bonus_lines            
            
    def action_request(self):
        for loan in self:
            if loan.loan_amount <= 0.0:
                raise UserError(_("Loan Amount Must be Bigger than Zero"))
            if loan.satisfy_condition():
                self.write({'state': 'requested'})
        return True

    def action_request(self):
        self.write({'state': 'requested'})

    def action_approve(self):
        self.write({'state': 'approved'})

    def action_draft(self):
        for loan in self:
            loan.loan_arc_ids.write({'state': 'draft'})
        self.write({'state': 'draft'})

    def action_refuse(self):
        return self.write({'state': 'rejected'})

    def action_payment(self):
        for loan in self:
            loan.loan_arc_ids.write({'state': 'paid'})
        self.write({'state': 'paid'})
        return True
        
    def satisfy_condition(self):
        self.ensure_one()
        # CHECK: Loan Limit is Once:
        if not self._check_loan_limit():
            return False
        # CHECK: Interference:
        if not self._check_interference():
            return False
        # CHECK: Employment years
        if not self._check_year_employment():
            return False

        return True

    def _check_loan_limit(self):
        if self.loan_id.loan_limit == 'one':
            loan_ids = self.search([
                ('employee_id', '=', self.employee_id.id),
                ('loan_id', '=', self.loan_id.id),
                ('state', 'not in', ['draft', 'rejected'])])
            if len(loan_ids) >= 1:
                msg = _("Loan Limit is Once and Already Taken")
                self.write({'state': 'rejected', 'reject_reason': msg})
                return False
        return True

    def _check_interference(self):
        if self.loan_id.loan_limit == 'unlimit' and not self.loan_id.interference:
            loan_ids = self.search([
                ('employee_id', '=', self.employee_id.id),
                ('loan_id', '=', self.loan_id.id),
                ('state', 'not in', ['draft', 'rejected', 'done'])])
            if len(loan_ids) >= 1:
                msg = _("Interference Between same Loan Not Allowed")
                self.write({'state': 'rejected', 'reject_reason': msg})
                return False
        return True

    def _check_year_employment(self):
        if self.loan_id.year_employment > 0:
            loan_year = datetime.strptime(str(self.payment_date), '%Y-%m-%d').year
            employment_year = datetime.strptime(str(self.employee_id.start_date), '%Y-%m-%d').year
            if int(loan_year) - int(employment_year) < self.loan_id.year_employment:
                msg = _("Employment years for Employee Not Fit employment Years for The Loan")
                self.write({'state': 'rejected', 'reject_reason': msg})
                return False
        return True

    def action_transfer(self):
        for loan in self:
            if not loan.loan_arc_ids:
                raise UserError(_("Please Compute installment"))
            if not loan.loan_id.loan_account_id:
                raise UserError(
                        _('Please Enter Accounting Configration for Loan %s.') % (loan.loan_id.name))
            if not loan.loan_id.loan_journal_id:
                raise UserError(
                        _('Please Enter Accounting Journal Configration for Loan %s.') % (loan.loan_id.name))
            if not loan.move_id:
                move_id = self.env['account.move'].sudo().create({
                    'partner_id': loan.employee_id.address_home_id.id,
                    'narration': self.note,
                    'move_type': 'in_invoice',
                    'invoice_user_id': self.env.user.id,
                    'journal_id': loan.loan_id.loan_journal_id.id or False,
                    'company_id': loan.company_id.id,
                    'ref': loan.name or '',
                    'invoice_origin': loan.name,
                    'invoice_date': fields.Date.context_today(self),
                    'source_document': self._name + ',' + str(loan.id),
                    'source_document_state': loan.state,
                    'invoice_line_ids': [(0, 0, {
                        'name': loan.name,
                        'account_id': loan.loan_id.loan_account_id.id,
                        'price_unit': loan.loan_amount,
                        'quantity': 1,
                        'tax_ids': []})]
                })
                loan.write({'move_id': move_id.id})
            else:
                loan.move_id.invoice_line_ids.sudo().unlink()
                loan.move_id.sudo().write({
                    'invoice_line_ids': [(0, 0, {
                        'name': loan.name,
                        'account_id': loan.loan_id.loan_account_id.id,
                        'price_unit': loan.loan_amount,
                        'quantity': 1,
                        'tax_ids': []})]
                })

            loan.loan_arc_ids.write({'state': 'paid'})
            self.write({'state': 'paid'})

    def compute_installment(self):
        for loan in self:
            if loan.refund_from == 'salary_bonus':
                if loan.loan_amount != (loan.salary_loan_amount + loan.bonus_loan_amount + loan.remission_amount):
                    raise ValidationError(
                        _('Sumation of salary & bonus loan amount must equal loan amount %s.') % (loan.loan_amount))

            loan.loan_arc_ids.unlink()
            if loan.refund_from in ['salary', 'salary_bonus']:
                date_start = datetime.strptime(str(loan.payment_date), '%Y-%m-%d')
                start_date = datetime.strptime(str(loan.payment_date), '%Y-%m-%d')
                amount = loan.salary_installment_amount
                for i in range(1, loan.salary_installment + 1):
                    end_date = start_date + relativedelta.relativedelta(day=31)
                    self.env['hr.loan.archive'].create({
                        'start_date': start_date,
                        'end_date': end_date,
                        'payment_type': 'salary',
                        'amount': amount,
                        'employee_id': loan.employee_id.id,
                        'loan_type_id': loan.loan_id.id,
                        'loan_id': loan.id})
                    computed_installment = sum(loan.loan_arc_ids.mapped('amount'))
                    date_start = date_start + relativedelta.relativedelta(day=1, months=+1)
                    start_date = start_date + relativedelta.relativedelta(day=1, months=+1)

            if loan.refund_from in ['bonus', 'salary_bonus']:
                for bonus in loan.loan_bonus_ids:
                    date_start = datetime.strptime(str(loan.payment_date), '%Y-%m-%d')
                    start_date = datetime.strptime(str(loan.payment_date), '%Y-%m-%d')
                    amount = bonus.bonus_amount/bonus.installment
                    for i in range(1, bonus.installment + 1):
                        if bonus.bonus_id.category_id.frequency == 'monthly':
                            end_date = start_date + relativedelta.relativedelta(day=31)
                            frequency = 1
                        elif bonus.bonus_id.category_id.frequency == 'quarterly':
                            end_date = start_date + relativedelta.relativedelta(day=31, months=+2)
                            frequency = 3
                        elif bonus.bonus_id.category_id.frequency == 'yearly':
                            end_date = start_date + relativedelta.relativedelta(day=31, month=12)
                            frequency = 12
                        self.env['hr.loan.archive'].create({
		                    'start_date': start_date,
		                    'end_date': end_date,
		                    'payment_type': 'bonus',
		                    'amount': amount,
		                    'bonus_id': bonus.bonus_id.id,
		                    'employee_id': loan.employee_id.id,
		                    'loan_type_id': loan.loan_id.id,
		                    'loan_id': loan.id})
                        date_start = date_start + relativedelta.relativedelta(months=+frequency)
                        start_date = start_date + relativedelta.relativedelta(day=1, months=+frequency)
		                
            if loan.remission_amount > 0:
                self.env['hr.loan.archive'].create({
                    'employee_id': loan.employee_id.id,
                    'start_date': start_date,
                    'end_date': end_date,
                    'payment_type': 'remission',
                    'amount': loan.remission_amount,
                    'loan_id': loan.id})


class LoanBonus(models.Model):
    _name = "hr.loan.bonus"
    _description = "Loan Bonus"
    
    bonus_id = fields.Many2one('hr.salary.rule', string='Bonus')
    loan_id = fields.Many2one('hr.loan', string="Loan")
    installment = fields.Integer(string="Installments", required=True, default=1)
    bonus_amount = fields.Float(string="Amount", required=True)
    
    
class LoanArchive(models.Model):
    _name = "hr.loan.archive"
    _description = "Loan Archive"
    _rec_name = 'employee_id'
    
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    employee_id = fields.Many2one('hr.employee', string="Employee")
    amount = fields.Float(string="Amount", required=True)
    loan_type_id = fields.Many2one('hr.loan.type', string="Loan Type")
    loan_id = fields.Many2one('hr.loan', string="Loan")
    payment_type = fields.Selection([
        ('salary', 'Salary'),
        ('bonus', 'Bonus'),
        ('direct_payment', 'Direct Payment'),
        ('remission', 'Remission'),
    ], string='Payment Type', required=True, default='salary')
    payslip_id = fields.Many2one('hr.payslip', string="Payslip Ref.", ondelete='set null')
    arch_voucher_id = fields.Many2one('account.move', string='Move Voucher', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('suspend', 'Suspend'),
        ('delay', 'Delay'),
        ('paid', 'To Deduct'),
        ('done', 'Done')
    ], string='Status', readonly=True, copy=False, default='draft')
    bonus_id = fields.Many2one('hr.salary.rule', string='Bonus', readonly=True)

    def create_voucher_remission(self):
        for rec in self:
            if rec.payment_type == 'remission':
                if not rec.loan_id.loan_id.loan_account_id or not rec.loan_id.loan_id.loan_remission_account_id:
                    raise UserError(
                        _('Please Enter Accounting Configration for Loan %s.') % (rec.loan_id.name))

                date = time.strftime('%Y-%m-%d')
                lines = []
                line_remission = {
                    'account_id': rec.loan_id.loan_id.loan_remission_account_id.id,
                    'price_unit': rec.amount,
                    'name': rec.loan_id.loan_id.name,
                    'quantity': 1,
                    'tax_ids': []
                }
                lines.append(line_remission)
                line_loan = {
                    'account_id': rec.loan_id.loan_id.loan_account_id.id,
                    'price_unit': -rec.amount,
                    'name': rec.loan_id.loan_id.name,
                    'quantity': 1,
                    'tax_ids': []
                }
                lines.append(line_loan)
                if not rec.arch_voucher_id:
                    voucher_id = self.env['account.move'].sudo().create({
		                'ref': rec.loan_id.name,
		                'partner_id': rec.employee_id.address_home_id.id,
		                'invoice_user_id': self.env.user.id,
		                'move_type': 'in_invoice',
		                'journal_id': rec.loan_id.loan_id.loan_journal_id.id or False,
		                'company_id': rec.loan_id.company_id.id,
		                'source_document': self._name + ',' + str(rec.id),
		                'source_document_state': rec.state,
		                'invoice_origin': rec.loan_id.name,
		                'invoice_line_ids': [(0, 0, x) for x in lines],
                    })
                    self.loan_id.write({'remission_move_id': voucher_id})
                    self.write({'arch_voucher_id': voucher_id})
                else:
                    rec.arch_voucher_id.invoice_line_ids.sudo().unlink()
                    rec.arch_voucher_id.sudo().write({'invoice_line_ids': [(0, 0, x) for x in lines]})
                self.write({'state': 'done'})
        return True

    def action_create_new_arah(self):
        for arch in self:
            if arch.payment_type == 'salary':
                loan_archive = self.search([
		            ('loan_id', '=', arch.loan_id.id),
		            ('payment_type', '=', arch.payment_type)], order='start_date desc', limit=1)
                date_start = datetime.strptime(str(loan_archive.start_date), '%Y-%m-%d')  
                start_date = date_start + relativedelta.relativedelta(day=1, months=+1)
                end_date = start_date + relativedelta.relativedelta(day=31)
                
            if arch.payment_type == 'bonus':
                loan_archive = self.search([
		            ('loan_id', '=', arch.loan_id.id),
		            ('bonus_id', '=', arch.bonus_id.id),
		            ('payment_type', '=', arch.payment_type)], order='start_date desc', limit=1)
		                            
                date_start = datetime.strptime(str(loan_archive.start_date), '%Y-%m-%d')
                if arch.bonus_id.category_id.frequency == 'monthly':
                    start_date = date_start + relativedelta.relativedelta(day=1, months=+1)
                    end_date = start_date + relativedelta.relativedelta(day=31)
                elif arch.bonus_id.category_id.frequency == 'quarterly':
                    start_date = date_start + relativedelta.relativedelta(day=1, months=+3)
                    end_date = start_date + relativedelta.relativedelta(day=31, months=+2)
                elif arch.bonus_id.category_id.frequency  == 'yearly':
                    start_date = date_start + relativedelta.relativedelta(day=1, month=1, years=+1)
                    end_date = start_date + relativedelta.relativedelta(day=31, month=12)
		            
            self.create({
                'start_date': start_date,
                'end_date': end_date,
                'payment_type': arch.payment_type,
                'amount': arch.amount,
                'employee_id': arch.employee_id.id,
                'bonus_id': arch.bonus_id.id,
                'loan_type_id': arch.loan_type_id.id,
                'loan_id': arch.loan_id.id,
                'state': 'paid'
            })
        return True

    def action_suspend(self):
        self.action_create_new_arah()
        self.write({'state': 'suspend'})

    def action_paid(self):
        self.write({'state': 'paid', 'payslip_id': False})
        for arc in self:
            if arc.loan_id.state == 'done' and arc.loan_id.remain_amount > 0.0:
                arc.loan_id.write({'state': 'paid'})
        return True

    def action_done(self):
        self.write({'state': 'done'})
        for arc in self:
            if arc.loan_id.remain_amount <= 0 and arc.loan_id.state == 'paid':
                arc.loan_id.write({'state': 'done'})
        return True

    def action_delay(self):
        self.action_create_new_arah()
        self.write({'state': 'delay'})
