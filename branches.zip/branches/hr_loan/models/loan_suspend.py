# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class LoanSuspend(models.Model):
    _name = "hr.loan.suspend"
    _inherit = ['mail.thread']
    _description = "Suspended Loans"
    _order = "id desc"

    def _default_employee(self):
        return self.env.context.get('default_employee_id') or self.env['hr.employee'].search(
            [('user_id', '=', self.env.uid)], limit=1)

    name = fields.Char("Name", readonly=True)
    date = fields.Date(string="Request Date", default=fields.Date.today(), readonly=True)
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, readonly=True,
        states={'draft': [('readonly', False)]}, default=_default_employee)
    loan_id = fields.Many2one("hr.loan", 'Loan', required=True, readonly=True,
        states={'draft': [('readonly', False)]}, tracking=True)
    loan_type_id = fields.Many2one('hr.loan.type', related='loan_id.loan_id' ,string='Loan Type', required=True, readonly=True,
        states={'draft': [('readonly', False)]})
    arc_ids = fields.Many2many('hr.loan.archive', string='Installments')
    notes = fields.Html("Notes")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string='Status', readonly=True, copy=False, index=True, tracking=True, default='draft')

    @api.model
    def create(self, vals):
        if not vals.get('name', False):
            vals['name'] = self.env['ir.sequence'].next_by_code('hr.loan.suspend') or '/'
        return super(LoanSuspend, self).create(vals)


    def action_reject(self):
        self.write({'state': 'rejected'})

    def action_draft(self):
        self.write({'state': 'draft'})

    def action_approve(self):
        self.arc_ids.action_suspend()
        self.write({'state': 'approved'})

    def action_request(self):
        if not self.arc_ids:
            raise UserError(_('Please specify installment'))
        times_of_stop = self.search([
            ('loan_id', '=', self.loan_id.id), ('state', 'in', ['requested', 'approved'])])
        if len(times_of_stop) >= self.loan_id.loan_id.times_stop_loan:
            raise ValidationError(
                _('You cannot suspend a loan max  suspend times is  %s.') % (self.loan_id.loan_id.times_stop_loan,))
        if len(self.arc_ids) > self.loan_id.loan_id.period_stop_loan:
            raise ValidationError(
                _('Suspend Duration is bigger than allowed duration  %s.') % (self.loan_id.loan_id.period_stop_loan,))
        return self.write({'state': 'requested'})

    def unlink(self):
        if self.state != 'draft':
            raise UserError(_('You cannot delete a record which is not draft!'))
        return super(LoanSuspend, self).unlink()
