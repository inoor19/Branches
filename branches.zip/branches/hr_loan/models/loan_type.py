# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _


class LoansType(models.Model):
    _name = "hr.loan.type"
    _description = "Loans Types"

    name = fields.Char(string='Loan Name', required=True, translate=True)
    code = fields.Char(string='Loan code')
    active = fields.Boolean(default=True)
    start_date = fields.Date('Start Date', default=fields.Date.context_today)
    end_date = fields.Date('End Date')
    loan_type = fields.Selection([
        ('fixed', 'Fixed Amount'),
        ('salary', 'Based on Salary')
    ], required=True, default='fixed', string='Loan Type')
    refund_from = fields.Selection([
        ('salary', 'Salary'),
        ('bonus', 'Bonus'),
        ('salary_bonus', 'Salary & Bonus')
    ], default='salary', required=True, string='Refund From')

    bonus_ids = fields.Many2many('hr.salary.rule', 's_rule_loan_type_rel', 's_rule_id', 'type_id',
                                       string='Bonus')
    bonus_installment = fields.Integer(string="Bonus Installments", required=True, default=1)
    bonus_percentage = fields.Float(string="Bonus Percentage")

    loan_amount = fields.Float(string="Loan Amount", required=True)
    max_loan_amount = fields.Float(string="Max Loan Amount")
    installment = fields.Integer(string="Salary Installments", required=True, default=1)
    loan_account_id = fields.Many2one('account.account', domain=[('deprecated', '=', False)], string="Loan Account",
                                      company_dependent=True)
    loan_journal_id = fields.Many2one('account.journal', 'Journal', domain=[('type', '=', 'purchase')], company_dependent=True, required=True)
    pay_journal_id = fields.Many2one('account.journal', 'Payment Journal', domain=[('type', '=', 'sale')], company_dependent=True, required=True)
    payment_journal_id = fields.Many2one('account.journal', 'Payment Journal', company_dependent=True, required=True,)
    times_stop_loan = fields.Integer(string="Times of Stop Loan")
    period_stop_loan = fields.Integer(string="Period of Stop Loan")
    loan_limit = fields.Selection([
        ('one', 'Once'),
        ('unlimit', 'Unlimit')], default='one', string='Limit', required=True)
    salary_rule_ids = fields.Many2many('hr.salary.rule', 'rule_type_rel', 'rule_id', 'type_id',
                                       string='Salary Rules')
    interference = fields.Boolean(string='Allow Interference')
    year_employment = fields.Integer(string="Years of Employment")
    note = fields.Html(string='Description')
    decimal_calculate = fields.Selection([
        ('with', 'With decimal part'),
        ('without', 'Without decimal part')], default='with', string='decimal calculating', required=True)
    remission_type = fields.Selection([('no', 'No Remission'), ('amount', 'Amount'),
                                       ('percentage', 'Percentage')], default='no', string='Remission Type',
                                      required=True)
    loan_remission_account_id = fields.Many2one('account.account',
                                                string="Remission Account",
                                                help="This account will be used to transfer the the amount of remission of the loan",
                                                company_dependent=True)
    remission = fields.Float(string="Remission Amount/percentage")
    change_loan_amount = fields.Boolean(string='Change loan Amount')
    change_installment_no = fields.Boolean(string='Change Installment No')
    is_period_after_loan = fields.Boolean(string='Is Period After Last Loan')
    period_after_last_loan = fields.Integer(string="Period")
    loan_type_bonus_ids = fields.One2many('hr.loan.type.bonus', 'loan_type_id', string='Installments')



    _sql_constraints = [
        ('code_uniq', 'unique (code)', 'The code of the loan must be unique !'),
        ('name_uniqe', 'unique (name)', 'The name of the loan must be unique !'),

    ]



class LoanTypeBonus(models.Model):
    _name = "hr.loan.type.bonus"
    _description = "Loan Type Bonus"
    
    bonus_id = fields.Many2one('hr.salary.rule', string='Bonus')
    loan_type_id = fields.Many2one('hr.loan.type', string="Loan Type")
    installment = fields.Integer(string="Installments", required=True, default=1)
    percentage = fields.Float(string="Percentage (%)", default=100)
    
    
    
   
    
