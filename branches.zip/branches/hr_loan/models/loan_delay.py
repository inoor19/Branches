# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class LoanDelay(models.Model):
    _name = "hr.loan.delay"
    _inherit = ['mail.thread']
    _description = "Delay Loans"

    name = fields.Char("Name", readonly=True)
    loan_type_id = fields.Many2one('hr.loan.type', 'Loan Type', required=True, readonly=True,
        states={'draft': [('readonly', False)]})
    start_date = fields.Date("Delay Start Date", required=True, readonly=True,
        states={'draft': [('readonly', False)]})
    end_date = fields.Date("Delay End Date", required=True, readonly=True,
        states={'draft': [('readonly', False)]})
    arc_ids = fields.Many2many('hr.loan.archive', string='Installments', readonly=True,
        states={'draft': [('readonly', False)]}, )
    notes = fields.Html("Notes")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string='Status', readonly=True, copy=False, index=True, tracking=True, default='draft')

    @api.model
    def create(self, vals):
        if not vals.get('name', False):
            vals['name'] = self.env['ir.sequence'].next_by_code('hr.loan.delay') or '/'
        return super(LoanDelay, self).create(vals)

    @api.onchange('start_date', 'end_date')
    def _onchange_dates(self):
        for rec in self:
            lines = []
            for line in rec.arc_ids:
                if line.date >= rec.start_date and line.date <= rec.end_date:
                    lines.append(line.id)
            rec.arc_ids = [(6, 0, [x for x in lines])]

    def action_reject(self):
        self.write({'state': 'rejected'})

    def action_draft(self):
        self.write({'state': 'draft'})

    def action_approve(self):
        self.arc_ids.action_delay()
        self.write({'state': 'approved'})

    def action_request(self):
        if not self.arc_ids:
            raise UserError(_('Please specify installment'))
        return self.write({'state': 'requested'})

    def unlink(self):
        if self.state != 'draft':
            raise UserError(_('You cannot delete a record which is not draft!'))
        return super(LoanDelay, self).unlink()

