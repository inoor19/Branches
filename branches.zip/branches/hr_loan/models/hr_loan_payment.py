# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import date, datetime
from dateutil import relativedelta


class LoanPayment(models.Model):
    _name = 'hr.loan.payment'
    _inherit = ['mail.thread']
    _description = "Loans Payment"
    _order = "date desc, id desc"

    def _default_employee(self):
        return self.env.context.get('default_employee_id') or self.env['hr.employee'].search(
            [('user_id', '=', self.env.uid)], limit=1)

    name = fields.Char("Name", readonly=True)
    date = fields.Date("Payment Date", default=fields.datetime.now(), required=True, readonly=True,
        states={'draft': [('readonly', False)]})
    loan_type_id = fields.Many2one('hr.loan.type', related='loan_id.loan_id', string='Loan Type', required=True, readonly=True,
         states={'draft': [('readonly', False)]})
    loan_code = fields.Char(related="loan_type_id.code", string="Loan code", readonly=True, store=True)
    loan_date = fields.Date(related="loan_id.payment_date", string="Loan Date", readonly=True, store=True)
    loan_amount = fields.Float(related="loan_id.loan_amount", string="Loan Amount", readonly=True, store=True)
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, readonly=True,
        states={'draft': [('readonly', False)]}, default=_default_employee)
    loan_id = fields.Many2one('hr.loan', 'Loan', required=True, readonly=True,
        states={'draft': [('readonly', False)]})
    remain_amount = fields.Float(string='Remain Amount')
    amount = fields.Float("Amount")
    arc_ids = fields.Many2many('hr.loan.archive', string='Payment Installments')
    move_id = fields.Many2one('account.move', string='Invoice', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('requested', 'Requested'),
        ('transfered', 'Transfered'),
        ('paid', 'Paid')
    ], string='Status', readonly=True, copy=False, index=True, tracking=True, default='draft')
    payment_type = fields.Selection([
        ('partial', 'Partial'),
        ('all', 'All')], string='Payment Type', required=True, readonly=True,
        states={'draft': [('readonly', False)]}, default='partial')
    installment_type = fields.Selection([
        ('pay', 'Pay Installments'),
        ('reduce', 'Reduce Installments')], string='Installment Payment Type', readonly=True,
        states={'draft': [('readonly', False)]}, required=False)
    notes = fields.Html("Notes")

    @api.model
    def create(self, vals):
        if not vals.get('name', False):
            vals['name'] = self.env['ir.sequence'].next_by_code('hr.loan.payment') or '/'
        if vals.get('loan_id', False):
            vals['remain_amount'] = self.env['hr.loan'].browse(vals['loan_id']).remain_amount
        return super(LoanPayment, self).create(vals)

    def write(self, vals):
        if vals.get('loan_id', False):
            vals['remain_amount'] = self.env['hr.loan'].browse(vals['loan_id']).remain_amount
        return super(LoanPayment, self).write(vals)

    @api.onchange('loan_id')
    def _onchange_loan_id(self):
        for rec in self:
            rec.remain_amount = rec.loan_id.remain_amount

    def unlink(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_('You cannot delete a record which is not draft!'))
        return super(LoanPayment, self).unlink()


    def action_request(self):
        self.write({'state': 'requested'})

    def action_transfer(self):
        for payment in self:
            if not payment.loan_id.loan_id.loan_account_id:
                raise UserError(_("Please Enter Accounting Configration for Loan"))
            if not payment.loan_id.loan_id.pay_journal_id:
                raise UserError(_("Please Enter Accounting Payment Journal Configration for Loan"))
            amount = payment.amount
            if payment.payment_type == 'all':
                amount = payment.remain_amount
            else:
                if payment.installment_type == 'pay':
                    amount = sum(payment.mapped('arc_ids.amount'))
            move_id = self.env['account.move'].sudo().create({
                'partner_id': payment.employee_id.address_home_id.id,
                'narration': self.notes,
                'move_type': 'out_invoice',
                'invoice_user_id': self.env.user.id,
                'invoice_date': payment.date ,
                'source_document': payment._name + ',' + str(payment.id),
                'source_document_state': payment.state,
                'journal_id':payment.loan_id.loan_id.pay_journal_id.id or False,
                'company_id': payment.loan_id.company_id.id,
                'ref': payment.name or '',
                'invoice_origin': payment.name,
                'invoice_origin': payment.name,
                'invoice_line_ids': [(0, 0, {
                    'name': payment.name,
                    'account_id': payment.loan_type_id.loan_account_id.id or False,
                    'price_unit': amount,
                    'quantity': 1,
                    'tax_ids': []})],
            })

            self.write({'move_id': move_id.id})
            self.action_payment()

    def action_draft(self):
        self.write({'state': 'draft'})

    def action_payment(self):
        for payment in self:
            
            if payment.payment_type == 'all':
                arc_ids = payment.loan_id.loan_arc_ids.filtered(lambda arch: arch.state == 'paid')
                arc_ids.write({'payment_type': 'direct_payment'})
                arc_ids.action_done()
            else:
                if payment.installment_type == 'pay':
                    payment.arc_ids.write({'payment_type': 'direct_payment'})
                    payment.arc_ids.action_done()
                else:
                    remain_amount = payment.remain_amount - payment.amount
                    arc_ids = payment.loan_id.loan_arc_ids.filtered(lambda arch: arch.state == 'paid')
                    installment_amount = payment.amount / len(arc_ids)
                    for arc in arc_ids:
                        arc.write({'amount': arc.amount - installment_amount})
                    date_start = datetime.strptime(str(payment.date), '%Y-%m-%d')        
                    new_arc_id = self.env['hr.loan.archive'].create({
                        'start_date': payment.date,
                        'end_date': payment.date,
                        'amount': payment.amount,
                        'employee_id': payment.employee_id.id,
                        'loan_type_id': payment.loan_id.loan_id.id,
                        'loan_id': payment.loan_id.id,
                        'payment_type': 'direct_payment'})
                    new_arc_id.action_done()
        self.write({'state': 'paid'})
