# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, models, fields


class ResCompany(models.Model):
    _inherit = 'res.company'

    max_employee = fields.Float(string="Max Percentage for Total Loans Per Employee", default=100)
    max_department = fields.Float(string="Max Percentage for Total Loans Per Department", default=100)
    allowed_number = fields.Integer(string="Allowed Number",
                                    help='Number of loans per employee , if its 0 thats mean no limit for number of loans',
                                    default=0)
    salary_rule_id = fields.Many2one('hr.salary.rule', 'Salary')
