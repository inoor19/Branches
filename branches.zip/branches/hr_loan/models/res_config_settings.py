# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    max_employee = fields.Float(string='Max Percentage for Total Loans Per Employee')
    max_department = fields.Float(string='Max Percentage for Total Loans Per Department')
    allowed_number = fields.Integer(string='Allowed Number',help='Number of loans per employee , if its 0 thats mean no limit for number of loans')



    

