# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from . import res_config_settings
from . import hr_loan
from . import loan_type
from . import loan_delay
from . import loan_suspend
from . import employee
from . import hr_loan_payment
from . import company
from . import hr_payslip

