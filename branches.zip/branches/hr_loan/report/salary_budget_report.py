# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import fields, models, api, exceptions, _
import time
from datetime import datetime,date
import calendar
from dateutil.relativedelta import relativedelta


class EmpSalaryBudgeReport(models.AbstractModel):
    _inherit = 'report.hr_payroll.salary_budget_report'

    def _get_salary_budget(self, data):
        res = super(EmpSalaryBudgeReport,self)._get_salary_budget(data)
        if res :
            for salary in res['first_docs']:

                for from_total_loan in salary.loan_ids.mapped('amount') :

                    res['docs'][salary.employee_id][3] += from_total_loan

            for salary in res['second_docs']:
                for to_total_loan in salary.loan_ids.mapped('amount') :
                    res['docs'][salary.employee_id][7] += to_total_loan

        return res




