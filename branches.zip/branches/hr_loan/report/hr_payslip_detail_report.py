# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, models

class HRPayslipDetailsReport(models.AbstractModel):
    _inherit = 'report.hr_payroll.payroll_detailed_report'
    _description = 'Payslip Details Report'


    def get_salary_details(self,payslip_run):
        res = super(HRPayslipDetailsReport,self).get_salary_details(payslip_run)
        #print (">>>>>>>>>>>>>>>.rs,",res)
        loan_names = []
        loan_indesc = {}
        loan_names_total = {}
        amount = 0.0
        # report_data_dic = {}
        for rec in payslip_run:
            for line in rec.slip_ids:
                emp_loan_dict = {}
                for loan in line.loan_ids :
                    if loan.loan_type_id.name not in loan_names:
                        loan_names.append(loan.loan_type_id.name)
                        loan_indesc[loan.loan_type_id.name] = len(loan_names)
                        loan_names_total[loan_indesc[loan.loan_type_id.name]] = 0
                        #print (">>>>>>>>>.emp_loan_dict[loan_indesc[loan.loan_type_id.name]]",emp_loan_dict[loan_indesc[loan.loan_type_id.name]])
                        emp_loan_dict[loan_indesc[loan.loan_type_id.name]] = 0
                        #amount = loan.amount
                    # else :
                    #     amount += loan.amount
                    emp_loan_dict[loan_indesc[loan.loan_type_id.name]] = round(loan.amount,2)
                    loan_names_total[loan_indesc[loan.loan_type_id.name]] = round(loan_names_total[loan_indesc[loan.loan_type_id.name]],
                                                                      2) + round(loan.amount, 2)

                emp_loan_total =  sum(line.loan_ids.mapped('amount'))

                res['report_data_dic'][line.employee_id.id].update({'emp_loan' : emp_loan_dict,
                                                                    'emp_loan_total' : emp_loan_total})
                

            print (">>>>>>>>>>.loan_names_total",loan_names_total)
            for y in res['report_data_dic'] :
                res.update({
                    'loan_names': loan_names,
                    'total_loan_total': loan_names_total,
                    'loan_shift': len(loan_names),
                })

            print (">>>>>>>>>>>>>res",res['allwo_names'])
            return res

