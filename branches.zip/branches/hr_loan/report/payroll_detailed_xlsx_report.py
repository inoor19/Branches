# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models , _
import string


class DetailedXlsxReport(models.AbstractModel):
    _name = 'report.hr_payroll.xlsx_payroll_detailed_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        format1 = workbook.add_format(
            {'font_size': 12, 'align': 'vcenter', 'bold': True, 'bg_color': '#d2ecfa', 'color': 'black',
             'bottom': True, })
        format2 = workbook.add_format(
            {'font_size': 12, 'align': 'vcenter', 'bold': True, 'bg_color': '#d2ecfa', 'color': 'black',
             'num_format': '#,##0.00'})
        format3 = workbook.add_format({'font_size': 11, 'align': 'vcenter', 'bold': False, 'num_format': '#,##0.00'})
        format3_colored = workbook.add_format(
            {'font_size': 11, 'align': 'vcenter', 'bg_color': '#f7fcff', 'bold': False, 'num_format': '#,##0.00'})
        format4 = workbook.add_format({'font_size': 12, 'align': 'vcenter', 'bold': True,'color':'#118aa6'})
        format5 = workbook.add_format({'font_size': 12, 'align': 'vcenter', 'bold': False})
        sheet = workbook.add_worksheet('Employees Sheet')
        cols = list(string.ascii_uppercase) + ['AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK',
                                               'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV',
                                               'AW', 'AX', 'AY', 'AZ']
        datas = self.env['report.hr_payroll.payroll_detailed_report'].get_salary_details(lines)
        rules = []
        rules_ids = datas['allwo_names'] + datas['dedu_names']
        report_data_dic = datas['report_data_dic']
        
        col_no = 3
        # allowance_shift = 0
        # deduction_shift = 0
        # Fetch available salary rules:
        # if lines.type == 'salary' :
        #     rule_ids = self.env['hr.payroll.structure'].browse(lines.struct_ids.ids).get_all_rules()
        #     sorted_rule_ids = [id for id, sequence in sorted(rule_ids, key=lambda x: x[1])]
        #     rule_ids = self.env['hr.salary.rule'].browse(sorted_rule_ids)
        #     for rule in rule_ids :
        #         if rule not in rules_ids :
        #             rules_ids.append(rule)
        # else :
        #     for slip in lines.slip_ids:
        #         for line in slip.line_ids :
        #             if line.salary_rule_id not in rules_ids :
        #                 rules_ids.append(line.salary_rule_id)
        loans = []
        for slip in lines.slip_ids:
            for loan in slip.loan_ids:
                if loan.loan_type_id not in loans :
                    loans.append(loan.loan_type_id)
        for rule in rules_ids :

            col_title = ''
            row = [None, None, None, None, None,None]
            row[0] = col_no
            #row[1] = item.code
            row[2] = rule
            
            if len(rule) < 8:
                row[4] = 12
            else:
                row[4] = len(rule) + 2
            # if item.category_id.rule_type == 'allowances':
            #     row[5] = 'allowance'
            #     # allowance_shift += 1
            # elif item.category_id.rule_type == 'deduction':
            #     row[5] = 'deduction'
            # elif item.category_id.rule_type == 'bonus':
            #     row[5] = 'bonus'
                # deduction_shift += 1
            rules.append(row)
            col_no += 1


        # List report column headers:
        batch_period = str(lines.date_start.strftime('%B %d, %Y')) + '  To  ' + str(
            lines.date_end.strftime('%B %d, %Y'))
        company_name = lines.env.company.name
        # Company Name
        sheet.write(0, 0, company_name, format4)

        sheet.write(0, 2, _('Payslip Detailed Report :'), format4)
        sheet.write(0, 3, batch_period, format5)

        # sheet.merge_range(2, 3, 2, 6, 'Allowances', format1)
        # sheet.merge_range(2, allowance_shift, 2, col_no, 'Deduction', format1)

        i = 1
        sheet.write(3, 0, _('Employee Code'), format1)
        sheet.write(3, 1, _('Employee Name'), format1)
        sheet.write(3, 2, _('Structure'), format1)
        for rule in rules:
            sheet.write(3, rule[0], rule[2], format1)
        # for deduct in datas['dedu_names']:
        #     sheet.write(3, rule[0], rule[2], format1)
        for loan in datas['loan_names']:
            sheet.write(3, rule[0]+i,loan, format1)
            i += 1
            col_no += 1

        sheet.write(3, rule[0]+i,_('NET'), format1)

        # Report
        # Details:
        details_row = 4
        
        has_payslips = False
        
        for dic in report_data_dic :
            col_no = 3
            has_payslips = True
            sheet.write(details_row, 0, report_data_dic[dic]['code'], format3)
            sheet.write(details_row, 1, report_data_dic[dic]['name'], format3)
            sheet.write(details_row, 2, report_data_dic[dic]['degree'], format3)
            for allow in range(0,len(datas['allwo_names'])):
                sheet.write(details_row, col_no, report_data_dic[dic]['emp_allwo'].get(allow + 1, 0.0), format3)
                col_no +=1

            for deduct in range(0,len(datas['dedu_names'])):
                sheet.write(details_row, col_no, report_data_dic[dic]['emp_dedu'].get(deduct + 1, 0.0), format3)
                col_no +=1

            for loan in range(0,len(datas['loan_names'])):
                print (">>>>>>>>>>>>>>loan",report_data_dic[dic]['emp_loan'].get(loan + 1, 0.0))
                sheet.write(details_row, col_no , report_data_dic[dic]['emp_loan'].get(loan + 1, 0.0), format3)
                col_no += 1 
            sheet.write(details_row, col_no , report_data_dic[dic]['emp_net_salary'], format3)
            
            details_row += 1
            
          
        # Generate summission row at report end:
        sum_x = details_row
        if has_payslips == True:
            sheet.write(sum_x, 0, 'Total', format2)
            sheet.write(sum_x, 1, '', format2)
            sheet.write(sum_x, 2, '', format2)
            for i in range(3, col_no+1):
                sum_start = cols[i] + '3'
                sum_end = cols[i] + str(sum_x)
                sum_range = '{=SUM(' + str(sum_start) + ':' + sum_end + ')}'
                sheet.write_formula(sum_x, i, sum_range, format2)
                i += 1

        # set width and height of colmns & rows:
        sheet.set_column('A:A', 35)
        sheet.set_column('B:B', 25)
        sheet.set_column('C:C', 25)
        col_no = 3
        for rule in rules:
            col_title = str(cols[col_no]) + ':' + str(cols[col_no])
            row[3] = col_title
            sheet.set_column(row[3], rule[4])
            col_no += 1 
        for loan in range(0,len(datas['loan_names'])):
            col_title = str(cols[col_no]) + ':' + str(cols[col_no])
            row[3] = col_title
            sheet.set_column(row[3], rule[4])
            col_no += 1 
        col_title = str(cols[col_no]) + ':' + str(cols[col_no])
        row[3] = col_title
        sheet.set_column(row[3], rule[4])
        
