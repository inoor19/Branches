# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import fields, models, api, exceptions, _
import time
from datetime import datetime,date
import calendar
import string


class SalaryBudgetXlsxReport(models.AbstractModel):
    _name = 'report.hr_payroll.salary_budget_xlsx_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data,budget):

        format1 = workbook.add_format(
            {'font_size': 12, 'align': 'center', 'bold': True, 'bg_color': '#d2ecfa', 'color': 'black',
             'bottom': True})
        format2 = workbook.add_format(
            {'font_size': 12, 'align': 'center', 'bold': True, 'bg_color': 'gray', 'color': 'black',
             'bottom': True, 'top': True, 'left': True, 'right': True})

        format3 = workbook.add_format({'font_size': 11, 'align': 'vcenter', 'bold': False, 'num_format': '#,##0.00'})
        format3_colored = workbook.add_format(
            {'font_size': 11, 'align': 'vcenter', 'bg_color': '#f7fcff', 'bold': False, 'num_format': '#,##0.00'})
        format4 = workbook.add_format({'font_size': 15, 'align': 'vcenter', 'bold': True})
        cols = list(string.ascii_uppercase) + ['AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK',
                                               'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV',
                                               'AW', 'AX', 'AY', 'AZ']
        sheet = workbook.add_worksheet('Salary Budget')

        first_month = data['first_month']
        second_month = data['second_month']
        first_year = data['first_year']
        second_year = data['second_year']

        # get first month from and to date
        month_date_from = date(int(first_year), int(first_month), 1)
        first_from_date = month_date_from.replace(day=1)
        first_to_date = first_from_date.replace(day=calendar.monthrange(first_from_date.year, first_from_date.month)[1])

        # get second month from and to date
        month_date_to = date(int(second_year), int(second_month), 1)
        second_from_date = month_date_to.replace(day=1)
        second_to_date = second_from_date.replace(
            day=calendar.monthrange(second_from_date.year, second_from_date.month)[1])

        # get all payslips at this period
        first_docs = self.env['hr.payslip'].search(
            [('date_from', '=', first_from_date), ('date_to', '=', first_to_date), ('type', '=', 'salary')])

        second_docs = self.env['hr.payslip'].search(
            [('date_from', '=', second_from_date), ('date_to', '=', second_to_date), ('type', '=', 'salary')])

        employee_ids = list(second_docs.mapped('employee_id'))
        for emps in first_docs.mapped('employee_id'):
            if emps not in employee_ids:
                employee_ids.append(emps)
        employee_lines = dict(map(lambda x: (x, [x, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,0.0, 0.0, 0.0]), employee_ids))

        for salary in first_docs:
            from_total_allowance = sum(
                salary.line_ids.filtered(lambda x: x.category_id.rule_type == "allowance").mapped('total'))
            from_total_deduction = sum(
                salary.line_ids.filtered(lambda x: x.category_id.rule_type == "deduction").mapped('total'))

            # total_loan = salary.line_ids.filtered(lambda x: x.category_id.rule_type ==  "allowance").mapped('total')
            from_net = salary.net_wage

            employee_lines[salary.employee_id][1] += from_total_allowance
            employee_lines[salary.employee_id][2] += from_total_deduction
            for from_total_loan in salary.loan_ids.mapped('amount') :
                employee_lines[salary.employee_id][3] += from_total_loan
            employee_lines[salary.employee_id][4] += from_net

        for salary in second_docs:
            to_total_allowance = sum(
                salary.line_ids.filtered(lambda x: x.category_id.rule_type == "allowance").mapped('total'))
            to_total_deduction = sum(
                salary.line_ids.filtered(lambda x: x.category_id.rule_type == "deduction").mapped('total'))
            # total_loan = salary.line_ids.filtered(lambda x: x.category_id.rule_type ==  "allowance").mapped('total')
            to_net = salary.net_wage

            employee_lines[salary.employee_id][5] += to_total_allowance
            employee_lines[salary.employee_id][6] += to_total_deduction
            for to_total_loan in salary.loan_ids.mapped('amount') :
                employee_lines[salary.employee_id][7] += to_total_loan
            employee_lines[salary.employee_id][8] += to_net

        # Report Tiltle
        sheet.merge_range('E2:K2', 'Salary Budget For' + ' ' + first_month + ' ' + 'and' + ' ' + second_month,
                          format4)

        #get header
        sheet.merge_range('C4:E4', 'Allowances', format2)
        sheet.merge_range('F4:H4', 'Deductions', format2)
        sheet.merge_range('I4:K4', 'Loans', format2)
        sheet.merge_range('L4:N4', 'Net', format2)
        sheet.write(4, 0, 'Name', format1)
        sheet.write(4, 1, 'Structure', format1)
        sheet.write(4, 2, first_month, format1)
        sheet.write(4, 3, second_month, format1)
        sheet.write(4, 4, 'Difference', format1)
        sheet.write(4, 5, first_month, format1)
        sheet.write(4, 6, second_month, format1)
        sheet.write(4, 7, 'Difference', format1)
        sheet.write(4, 8, first_month, format1)
        sheet.write(4, 9, second_month, format1)
        sheet.write(4, 10, 'Difference', format1)
        sheet.write(4, 11, first_month, format1)
        sheet.write(4, 12, second_month, format1)
        sheet.write(4, 13, 'Difference', format1)

        row = 5
        for budget in employee_lines:
            #get employee details
            sheet.write(row, 0, employee_lines[budget][0].name, format3)
            sheet.write(row, 1, employee_lines[budget][0].contract_id.struct_id.name, format3)
            #get allowances
            sheet.write(row, 2, round(employee_lines[budget][1],2), format3)
            sheet.write(row, 3, round(employee_lines[budget][5],2), format3)
            sheet.write(row, 4, round(employee_lines[budget][1] - employee_lines[budget][5],2), format3)

            #get deductions
            sheet.write(row, 5, round(employee_lines[budget][2],2), format3)
            sheet.write(row, 6, round(employee_lines[budget][6],2), format3)
            sheet.write(row, 7, round(employee_lines[budget][2] - employee_lines[budget][6],2 ), format3)

            #get loans
            sheet.write(row, 8, round(employee_lines[budget][3],2), format3)
            sheet.write(row, 9, round(employee_lines[budget][7],2), format3)
            sheet.write(row, 10, round(employee_lines[budget][3] - employee_lines[budget][7],2 ), format3)

            #get net
            sheet.write(row, 11, round(employee_lines[budget][4],2), format3)
            sheet.write(row, 12, round(employee_lines[budget][8],2), format3)
            sheet.write(row, 13, round(employee_lines[budget][4] - employee_lines[budget][8],2 ), format3)

            row += 1

        # Generate summission row at report end:
        sheet.write(row, 0, 'Total', format1)

        for i in range(2, 14):
            sum_start = cols[i] + '3'
            sum_end = cols[i] + str(row)
            sum_range = '{=SUM(' + str(sum_start) + ':' + sum_end + ')}'
            sheet.write_formula(row, i, sum_range, format1)
            i += 1

        # set columns size
        sheet.set_column('A:A', 25)
        sheet.set_column('B:B', 20)
        sheet.set_column('C:C', 20)
        sheet.set_column('D:D', 20)
        sheet.set_column('E:E', 20)
        sheet.set_column('F:F', 20)
        sheet.set_column('G:G', 20)
        sheet.set_column('H:H', 20)
        sheet.set_column('I:I', 20)
        sheet.set_column('J:J', 20)
        sheet.set_column('K:K', 20)
        sheet.set_column('L:L', 20)
        sheet.set_column('M:M', 20)
        sheet.set_column('N:N', 20)


















