# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

import time
from odoo import _, api, fields, models
from odoo.exceptions import UserError


class EmployeeLoans(models.AbstractModel):
    _name = 'report.hr_loan.employee_loans'

    def get_employee_loans_report_data(self, data):
        docargs = {}
        loan = self.env['hr.loan']
        emp_dic = {}
        date_from = data['date_from']
        date_to = data['date_to']
        emp_ids = data['employee_ids']

        loan_ids = data['loan_type_ids']
        if loan_ids:
            type_ids = self.env['hr.loan.type'].browse(loan_ids)
        else:
            type_ids = self.env['hr.loan.type'].search([])

        if emp_ids:
            employee_ids = self.env['hr.employee'].browse(emp_ids)
        else:
            employee_ids = self.env['hr.employee'].search([])

        for type in type_ids:
            loans = loan.search([
                ('loan_id', '=', type.id), ('employee_id', 'in', employee_ids.ids), ('date', '>=', date_from),
                ('date', '<=', date_to)])
            if loans:
                emp_dic[type.id] = {
                    'name': type.name,
                    'loans': loans,
                }

        docargs['employees'] = emp_dic
        return docargs

    @api.model
    def _get_report_values(self, docids, data=None):
        docargs = self.get_employee_loans_report_data(data)
        docargs['doc_ids'] = self.ids
        docargs['doc_model'] = 'hr.loan'
        docargs['data'] = data
        docargs['date_from'] = data['date_from']
        docargs['date_to'] = data['date_to']
        return docargs


