# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from . import hr_payslip_detail_report
from . import employee_loans
from . import employee_salary_card_xlsx
from . import payroll_detailed_xlsx_report
from . import salary_budget_report
from . import salary_budget_xlsx

