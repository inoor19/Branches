# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, exceptions, _
from datetime import datetime
import calendar


class EmployeeLoansReportWiz(models.TransientModel):
    _name = 'employee.loans.report.wiz'

    date_from = fields.Date(string='Start Date')
    date_to = fields.Date(string='End Date')
    loan_type_ids = fields.Many2many('hr.loan.type', string='Loan Type', required=True)
    employee_ids = fields.Many2many(
        'hr.employee',
        string='Employees',
    )

    def print_report(self):
        """
        Call Abstract Model To Generate Report and pass the data
        :return:report
        """
        data = {
            'ids': [],
            'date_from': self.date_from,
            'date_to': self.date_to,
            'loan_type_ids': self.loan_type_ids.ids,
            'employee_ids': self.employee_ids.ids,

        }
        return self.env.ref('hr_loan.employee_loan_report_action').report_action(self, data=data)


