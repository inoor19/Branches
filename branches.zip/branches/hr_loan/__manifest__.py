# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    "name": "Loans Management",
    "version": "1.0",
    "category": "Human Resources/Loan",
    "sequence": 2,
    "description": """ 
    Manage Loan Requests
    """,
    "author": "NCTR",
    "website": "http://www.nctr.sd",
    "depends": ['hr_payroll',
                'account_custom',
                'hr_custom'],
    "data": [
        "security/hr_loan_security.xml",
        "security/ir.model.access.csv",
        "data/hr_loan_seq.xml",
        "views/hr_loan_view.xml",
        "views/loan_type_view.xml",
        "views/loan_suspend_view.xml",
        "views/loan_delay_view.xml",
        "views/hr_employee_view.xml",
        "views/hr_loan_payment_view.xml",
        "views/hr_payslip_view.xml",
        "report/report.xml",
        "report/certificate_of_loan.xml",
        "report/employee_loans.xml",
        "report/employee_salary_card_template.xml",
        "report/payroll_detailed_pdf_template.xml",
        "report/salary_budget_template.xml",
        "report/payroll_summary_pdf_template.xml",
        "wizard/employee_loans_report_wiz_view.xml",
    ],
    'license': 'LGPL-3',
    'application': True,
}
