# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api , fields, models,_
from odoo.exceptions import ValidationError


class Employee(models.Model):
    _inherit = "hr.employee"

    wage = fields.Monetary('Wage', required=True, tracking=True, help="Employee's monthly gross wage.")

    @api.model
    def create(self, vals):
        rec = super(Employee, self).create(vals)
        contract = {'name': vals.get('emp_code'),
                    'employee_id': rec.id,
                    'date_start': vals.get('start_date'),
                    'date_end': vals.get('departure_date'),
                    'department_id': vals.get('department_id'),
                    'job_id': vals.get('job_id'),
                    'wage': vals.get('wage'),
                    'state': 'draft'}
        contract_id = self.env['hr.contract'].create(contract)
        rec.write({'contract_id': contract_id.id})
        return rec

    def write(self, vals):
        res = super(Employee, self).write(vals)
        for rec in self:
            rec.reflect_to_contract(vals)
        return res

    def reflect_to_contract(self, vals, contract_vals={}, flag=False):
        if vals.get('company_id') and vals['company_id'] != self.contract_id.company_id.id:
            flag = True
            contract_vals.update({'company_id':vals['company_id']})

        if vals.get('department_id') and vals['department_id'] != self.contract_id.department_id.id:
            flag = True
            contract_vals.update({'department_id':vals['department_id']})

        if vals.get('job_id') and vals['job_id'] != self.contract_id.job_id.id:
            flag = True
            contract_vals.update({'job_id':vals['job_id']})

        if vals.get('wage') and vals['wage'] != self.contract_id.wage:
            flag = True
            contract_vals.update({'wage':vals['wage']})

        if vals.get('start_date') and vals['start_date'] != str(self.contract_id.date_start):
            flag = True
            contract_vals.update({'date_start':vals['start_date']})
        
        if vals.get('departure_date') and vals['departure_date'] != str(self.contract_id.date_end):
            flag = True
            contract_vals.update({'date_end':vals['departure_date']})
        if flag:
            self.contract_id.write(contract_vals)
        return True

    def unlink(self):
        for record in self:
            if record.state != 'draft':
                raise ValidationError(_('You cannot delete a record which is not draft!'))
            else:
                if record.user_id:
                    record.user_id.unlink()
        return super(Employee, self).unlink()

    def action_draft(self):
        self.contract_id.state = 'draft'
        return super(Employee, self).action_draft()

    def action_approved(self):
        self.contract_id.state = 'open'
        return super(Employee, self).action_approved()

    def action_refuse(self):
        res = super(Employee, self).action_refuse()
        self.contract_id.state = 'close'
        return res
