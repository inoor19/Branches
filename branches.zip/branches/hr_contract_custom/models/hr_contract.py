# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api , fields, models,_


class Contract(models.Model):

    _inherit = 'hr.contract'

    def reflect_to_employee(self,vals,employee_vals={},flag=False):
        if vals.get('company_id') and vals['company_id'] != self.employee_id.company_id.id :
            flag=True
            employee_vals.update({'company_id':vals['company_id']})

        if vals.get('department_id') and vals['department_id'] != self.employee_id.department_id.id :
            flag=True
            employee_vals.update({'department_id':vals['department_id']})

        if vals.get('job_id') and vals['job_id'] != self.employee_id.job_id.id :
            flag=True
            employee_vals.update({'job_id':vals['job_id']})

        if vals.get('date_start') and vals['date_start'] != str(self.employee_id.start_date) :
            flag=True
            employee_vals.update({'start_date':vals['date_start']})

        if vals.get('date_end') and vals['date_end'] != self.employee_id.departure_date :
            flag=True
            employee_vals.update({'departure_date':vals['date_end']})
        if flag :
            self.employee_id.write(employee_vals)
        
        return True

    def update_employee_state(self,state) :
        if state and state == 'draft' :
            self.employee_id.state='draft'
        if state and state == 'open' :
            self.employee_id.state = 'approved'
        if state and state == 'close' :
            self.employee_id.state = 'refuse'

