# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from . import allow_deduct_exception
from . import emplayee_salary_card
from . import salary_budget_wizard
from . import hr_payroll_index_wizard


