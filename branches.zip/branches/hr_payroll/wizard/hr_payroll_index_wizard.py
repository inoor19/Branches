# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.tools import format_date


class HrPayrollIndex(models.TransientModel):
    _name = 'hr.payroll.index'
    _description = 'Index Employees'

    @api.model
    def default_get(self, field_list):
        res = super().default_get(field_list)
        res['employee_ids'] = self.env.context.get('active_ids', [])
        return res

    percentage = fields.Float("Percentage")
    description = fields.Char("Description",
                              default=lambda self: _("Wage indexed on %s") % format_date(self.env, fields.Date.today()),
                              help="Will be used as the message specifying why the wage on the employee has been "
                                   "modified")
    employee_ids = fields.Many2many('hr.employee', string="Employees")
    display_warning = fields.Boolean("Error", compute='_compute_display_warning')

    @api.depends('employee_ids')
    def _compute_display_warning(self):
        for index in self:
            employees = index.employee_ids
            index.display_warning = any(emp.state != 'approved' for emp in employees)

    def _index_wage(self, emp):
        if self.percentage:
            emp.write({'wage': emp.wage + emp.wage * self.percentage / 100})
        else:
            emp.write({'wage': emp.wage + emp.wage * emp.struct_id.increase_rate / 100})

    def action_confirm(self):
        self.ensure_one()

        if self.display_warning:
            raise UserError(
                _('You have selected non running employees, if you really need to index them, please do it by hand'))

        for emp in self.employee_ids:
            self._index_wage(emp)

            # emp.message_post(body=self.description, message_type="comment", subtype="mail.mt_note")
