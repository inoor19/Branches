# -*- coding: utf-8 -*-
##############################################################################
#
#	NCTR, Nile Center for Technology Research
#	Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from datetime import timedelta, datetime, date
import calendar
from odoo import fields, models
import time


class SalaryCardWizard(models.TransientModel):
    _name = 'salary.card.wizard'
    _description = 'Salary Card'

    year = fields.Selection([(str(num), str(num)) for num in range(datetime.now().year, datetime.now().year - 10, -1)],
                            string="year", default=str(datetime.now().year), required=True)
    month = fields.Selection([(str(num), str(calendar.month_name[num])) for num in range(1, 12 + 1)], string="month",
                             default=str(datetime.now().month), required=True)
    type = fields.Selection([('salary', 'Salary'), ('bonus', 'Bonus')], string="Type", required=True, default='salary')

    def print_pdf_report(self):
        data = {
            'month': self.month,
            'year': self.year,
            'type': self.type,
        }

        return self.env.ref('hr_payroll.action_employee_salary_card').with_context(
            landscape=False).report_action(
            self, data=data)

    def print_xlsx_report(self):
        data = {
            'month': self.month,
            'year': self.year,
            'type': self.type,
        }

        return self.env.ref('hr_payroll.action_employee_salary_card_xlsx').with_context(
            landscape=True).report_action(
            self, data=data)
