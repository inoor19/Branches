# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

class AllowDeductException(models.TransientModel):
    _name = "hr.allow.deduct.exception"
    _description = "Salary Exceptions Wizard"

    action = fields.Selection([('allocation', 'Allocation'), ('exclude', 'Exclude')], 'Expectation Type', required=True,
                              default='allocation')
    employee_ids = fields.Many2many('hr.employee', 'exception_employee_rel', 'exception', 'employee_id', 'Employees',
                                    required=True)
    allow_deduct_id = fields.Many2one('hr.salary.rule', 'Allowance/Deduction', required=True)
    start_date = fields.Date("Start Date", required=True)
    end_date = fields.Date("End Date")
    amount = fields.Float("Amount/Percentage", )

    @api.constrains('start_date', 'end_date')
    def check_dates(self):
        if self.start_date and self.end_date:
            if self.start_date > self.end_date:
                raise ValidationError(_('Start Date Must Be Less Than End Date'))

    @api.constrains('employee_ids', 'end_date')
    def duplicate_rec(self):
        process_obj = self.env['hr.salary.exception']
        for record in self.employee_ids:
            check_salary = process_obj.search([('employee_id', '=', record.id), ('exception_type', '=', self.action),
                                               ('date_from', '=', self.start_date),
                                               ('salary_rule_id', '=', self.allow_deduct_id.id)])
            if check_salary:
                raise ValidationError(_('The Employee %s Already Have Exception') % record.name)

    @api.onchange('action')
    def onchange_action(self):
        if self.action == 'allocation':
            return {'domain': {'allow_deduct_id': [('special', '=', True)]}}
        else:
            return {'domain': {'allow_deduct_id': []}}

    def create_exception(self):
        """
       Method that adds special allowance/deduction for a group of employees in same department in specific period .
       @return: Dictionary 
       """
        exception_obj = self.env['hr.salary.exception']
        for rec in self:
            for emp in self.employee_ids:
                exception_obj.create({
                    'employee_id': emp.id,
                    'contract_id': emp.contract_id.id,
                    'salary_rule_id': rec.allow_deduct_id.id,
                    'date_from': rec.start_date,
                    'date_to': rec.end_date,
                    'amount': rec.amount,
                    'exception_type': rec.action,
                })
        return True
