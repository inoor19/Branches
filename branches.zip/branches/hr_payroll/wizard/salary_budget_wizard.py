# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import fields, models, api, exceptions, _
import time
from datetime import datetime
import calendar
from dateutil.relativedelta import relativedelta


class EmpSalaryBudgetWiz(models.TransientModel):
    _name = "employee.salary.budget.wiz"
    _description = "Employee Salary Budget"

    struct_ids = fields.Many2many("hr.payroll.structure", string="Structs", required=True)
    first_year = fields.Selection(
        [(str(num), str(num)) for num in range(datetime.now().year, datetime.now().year - 10, -1)],
        string="First year", default=time.strftime('%Y'), required=True)
    second_year = fields.Selection(
        [(str(num), str(num)) for num in range(datetime.now().year, datetime.now().year - 10, -1)],
        string="Second year", default=time.strftime('%Y'), required=True)
    first_month = fields.Selection([(str(num), str(calendar.month_name[num])) for num in range(1, 13)],
                                   string="First Month",
                                   required=True)
    second_month = fields.Selection([(str(num), str(calendar.month_name[num])) for num in range(1, 13)],
                                    string="Second Month",
                                    required=True)
    with_diff = fields.Boolean(string="who have different in salary")

    def print_pdf_report(self):
        datas = {
            'ids': self.id,
            'model': 'hr.payslip',
            'first_year': self.first_year,
            'second_year': self.second_year,
            'first_month': self.first_month,
            'second_month': self.second_month,
            'struct_ids': self.struct_ids.ids,
            'with_diff': self.with_diff,
        }

        return self.env.ref('hr_payroll.action_salary_budget').report_action(self, data=datas)

    def print_xlsx_report(self):
        datas = {
            'ids': self.id,
            'model': 'hr.payslip',
            'first_year': self.first_year,
            'second_year': self.second_year,
            'first_month': self.first_month,
            'second_month': self.second_month,
            'with_diff': self.with_diff,
        }

        return self.env.ref('hr_payroll.action_salary_budget_xlsx').report_action(self, data=datas)
