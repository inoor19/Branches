# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


{
    'name': 'Payroll',
    'category': 'Human Resources',
    'version': '16.0.1.0.0',
    'author': 'NCTR',
    'company': 'NCTR',
    'website': 'http://www.nctr.sd',
    'summary': 'Manage your employee payroll records',
    'description': "Manage employee payroll records",
    'depends': [
        'hr_contract_custom',
        'hr_holidays',
        'account',
        'hr_custom',
        'report_xlsx'
    ],
    'data': [
        'security/hr_payroll_security.xml',
        'security/ir.model.access.csv',
        'data/hr_payroll_sequence.xml',
        'data/hr_payroll_data.xml',
        'views/hr_contract_views.xml',
        'views/hr_views.xml',
        'views/hr_employee_views.xml',
        'views/hr_salary_rule_views.xml',
        'views/hr_payslip_views.xml',
        'views/hr_leave_type_view.xml',
        'wizard/hr_payroll_index_wizard_views.xml',
        'wizard/employee_salary_card.xml',
        'wizard/salary_budget_wizard.xml',
        'wizard/allow_deduct_exception_view.xml',
        'report/reports_actions.xml',
        'report/payroll_summary_pdf_template.xml',
        'report/payroll_detailed_pdf_template.xml',
        'report/employee_salary_card_template.xml',
        'report/salary_budget_template.xml',

    ],
    'license': 'LGPL-3',
    'application': True,
}
