# -*- coding: utf-8 -*-
##############################################################################
#
#	NCTR, Nile Center for Technology Research
#	Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta
from datetime import datetime, date
from odoo.fields import Datetime


class EmployeeCardPDF(models.AbstractModel):
    _name = 'report.hr_payroll.employee_salary_card_report'
    _description = 'Employee Salary Card Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        emp = self.env['hr.employee'].browse(self.env.context.get('active_id'))
        month = data['month']
        year = data['year']
        type = data['type']

        from_date = Datetime.to_string(Datetime.now().replace(day=1,month=int(month), year=int(year)))
        to_date = str(datetime.now().replace(month=int(month), year=int(year)) + relativedelta(months=+1, day=1, days=-1))[:10]

        docs = self.env['hr.payslip'].search(
            [('date_from', '=', from_date), ('date_to', '=', to_date)
                , ('employee_id', '=', emp.id),('type', '=', type),('payslip_run_id.appears_on_report', '=', True)])
        if not docs:
            raise ValidationError(_("There is no Computed %s for this Month",type))

        return {
            'doc_ids': docids,
            'doc_model': 'hr.employee',
            'docs': docs,
            'data': data,
        }

