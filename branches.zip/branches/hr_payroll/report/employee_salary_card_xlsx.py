from odoo import api, fields, models, _
import string
from datetime import datetime, date
from odoo.fields import Datetime
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta


class SalaryCardXlsxReport(models.AbstractModel):
    _name = 'report.hr_payroll.employee_salary_card_xlsx_report'
    _inherit = 'report.report_xlsx.abstract'
    _description = 'Salary Card Report'

    def generate_xlsx_report(self, workbook, data,salary):
        emp = self.env['hr.employee'].browse(self.env.context.get('active_id'))

        format1 = workbook.add_format(
            {'font_size': 12, 'align': 'vcenter', 'bold': True, 'bg_color': '#d2ecfa', 'color': 'black',
             'bottom': True, })
        format_value = workbook.add_format(
            {'font_size': 12, 'align': 'vcenter', 'bg_color': '#D3D3D3', 'color': 'black',
             'bottom': True, })
        format3 = workbook.add_format({'font_size': 11, 'align': 'vcenter', 'bold': False, 'num_format': '#,##0.00'})
        format3_colored = workbook.add_format(
            {'font_size': 11, 'align': 'vcenter', 'bg_color': '#f7fcff', 'bold': False, 'num_format': '#,##0.00'})
        format4 = workbook.add_format({'font_size': 15, 'align': 'vcenter', 'bold': True})
        sheet = workbook.add_worksheet('Salary Card')

        month = data['month']
        year = data['year']
        type = data['type']

        from_date = Datetime.to_string(Datetime.now().replace(day=1,month=int(month), year=int(year)))
        to_date = str(datetime.now().replace(month=int(month), year=int(year)) + relativedelta(months=+1, day=1, days=-1))[:10]

        docs = self.env['hr.payslip'].search(
            [('date_from', '=', from_date), ('date_to', '=', to_date)
                , ('employee_id', '=', emp.id),('type', '=', type)])
        if not docs:
            raise ValidationError(_("There is no Computed %s for this Month",type))

        # Report Tiltle
        sheet.merge_range('C1:I1',  _('%s Details For Month')+type +' '+month +' '+_('For Year')+ ' ' +year, format4)

        #Employee Name and Department :
        sheet.write(3, 0, 'Name', format1)
        sheet.merge_range('B4:F4', emp.name, format_value)

        sheet.merge_range('G4:H4', 'Department', format1)
        sheet.merge_range('I4:M4', emp.department_id.name, format_value)

        #Allowances:
        allow_total = 0.0
        row = 6

        sheet.merge_range('C6:E6', 'Allowance', format1)
        sheet.merge_range('F6:G6', 'Amount', format1)

        for allow in docs.line_ids.filtered(lambda s: s.salary_rule_id.category_id.rule_type == 'allowance' and s.salary_rule_id.code != 'NET'):

            sheet.merge_range(row, 2,row, 4,allow.salary_rule_id.name, format3)
            if allow.total > 0:
                sheet.merge_range(row, 5, row, 6, allow.total, format3_colored)
            else:
                sheet.merge_range(row, 5, row, 6, allow.total, format3)
            if allow.code != 'GROSS' :
                allow_total += allow.total
            row +=1
        # get allowances total

        sheet.merge_range(row, 2, row, 4, 'Total', format1)
        sheet.merge_range(row, 5, row, 6, allow_total, format1)
        row +=2
        
        # Deductions :
        deduct_total = 0.0
        deduct_row = 6

        sheet.merge_range('K6:M6', 'Deductions', format1)
        sheet.merge_range('N6:O6', 'Amount', format1)

        for deduct in docs.line_ids.filtered(
                lambda s: s.salary_rule_id.category_id.rule_type == 'deduction'):
            sheet.merge_range(deduct_row, 10, deduct_row, 12, deduct.salary_rule_id.name, format3)
            if deduct.total > 0:
                sheet.merge_range(deduct_row, 13, deduct_row, 14, deduct.total, format3_colored)
            else:
                sheet.merge_range(deduct_row, 13, deduct_row, 14, deduct.total, format3)

            deduct_total += deduct.total
            deduct_row += 1

        # get deduction total
        sheet.merge_range(deduct_row, 10, deduct_row, 12, 'Total', format1)
        sheet.merge_range(deduct_row, 13, deduct_row, 14, deduct_total, format1)

        # get NET
        allow_total -= deduct_total
        sheet.merge_range(row, 2, row, 4, 'Total', format1)
        sheet.merge_range(row, 5, row, 6, allow_total, format1)









