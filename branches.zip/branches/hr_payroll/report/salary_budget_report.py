# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import fields, models, api, exceptions, _
import time
from datetime import datetime,date
import calendar
from dateutil.relativedelta import relativedelta


class EmpSalaryBudgeReport(models.AbstractModel):
    _name = 'report.hr_payroll.salary_budget_report'
    _description = 'Salary Budget'

    def get_child_struct_ids(self,emp,struct):
        emp_id = self.env['hr.employee'].search([('id', '=', emp.id),('struct_id', 'child_of', struct)])
        if emp_id :
            return True
        else :
            return False

    def _get_salary_budget(self, data):
        first_month = data['first_month']
        second_month = data['second_month']
        first_year = data['first_year']
        second_year = data['second_year']
        struct_ids = data['struct_ids']
        struct_list = []
        for struct_id in struct_ids :
            struct_id = self.env['hr.payroll.structure'].search([('id' ,'=' ,struct_id)])
            struct_dic = {'struct_id' : struct_id.id,
                           'struct_name' : struct_id.name}
            struct_list.append(struct_dic)
        print (struct_list,">>>>>>>>>>structs_name")
        

        #get first month from and to date
        month_date_from = date(int(first_year), int(first_month), 1)
        first_from_date = month_date_from.replace(day=1)
        first_to_date = first_from_date.replace(day=calendar.monthrange(first_from_date.year, first_from_date.month)[1])

        # get second month from and to date
        month_date_to = date(int(second_year), int(second_month), 1)
        second_from_date = month_date_to.replace(day=1)
        second_to_date = second_from_date.replace(day=calendar.monthrange(second_from_date.year, second_from_date.month)[1])

        #get all payslips at this period
        first_docs = self.env['hr.payslip'].search(
            [('date_from', '=', first_from_date), ('date_to', '=', first_to_date), ('type', '=', 'salary'),('struct_id', 'child_of', struct_ids)])
        second_docs = self.env['hr.payslip'].search(
            [('date_from', '=', second_from_date), ('date_to', '=', second_to_date), ('type', '=', 'salary'),('struct_id', 'child_of', struct_ids)])
        employee_ids = list(second_docs.mapped('employee_id'))
        for emps in first_docs.mapped('employee_id'):
            if emps not in employee_ids:
                employee_ids.append(emps)
        if employee_ids :
            employee_lines = dict(map(lambda x: (x, [x, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]), employee_ids))

            for salary in first_docs:
                from_total_allowance = sum(salary.line_ids.filtered(lambda x: x.category_id.rule_type == "allowance").mapped('total'))
                from_total_deduction = sum(salary.line_ids.filtered(lambda x: x.category_id.rule_type == "deduction").mapped('total'))

                from_net = salary.net_wage

                employee_lines[salary.employee_id][1] += from_total_allowance
                employee_lines[salary.employee_id][2] += from_total_deduction
                employee_lines[salary.employee_id][4] += from_net

            for salary in second_docs:
                to_total_allowance = sum(salary.line_ids.filtered(lambda x: x.category_id.rule_type == "allowance").mapped('total'))
                to_total_deduction = sum(salary.line_ids.filtered(lambda x: x.category_id.rule_type == "deduction").mapped('total'))
                to_net = salary.net_wage

                employee_lines[salary.employee_id][5] += to_total_allowance
                employee_lines[salary.employee_id][6] += to_total_deduction
                employee_lines[salary.employee_id][8] += to_net


            date_time = datetime.strftime(datetime.now(), '%Y-%m-%d')

            with_diff_salary = {}
            if data['with_diff'] :
                for emp in employee_ids :
                    if employee_lines[emp][1] != employee_lines[emp][5] or employee_lines[emp][2] != employee_lines[emp][6] or employee_lines[emp][4] != employee_lines[emp][8]:
                        with_diff_salary[emp] = employee_lines[emp]
            
                employee_lines = with_diff_salary
            print (">>>>>>>>>..employee_lines",first_docs,second_docs)
            return{
                'doc_ids': self.ids,
                'doc_model': 'hr.payslip',
                'docs': employee_lines,
                'struct_ids_list' : struct_list,
                'date_time': date_time,
                'first_month': first_month,
                'second_month': second_month,
                'first_docs' : first_docs,
                'second_docs' : second_docs,
                'doc' : self,
            }

    @api.model
    def _get_report_values(self, docids, data=None):
        return self._get_salary_budget(data)




