# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
###############################################################################


from odoo import api, models, _


class PayrollSummaryPDF(models.AbstractModel):
    _name = 'report.hr_payroll.payroll_summary_report'
    _description = 'Total Payslip Batches report'

    def get_child_struct_ids(self, emp, struct):
        emp_id = self.env['hr.employee'].search([('id', '=', emp.id), ('struct_id', 'child_of', struct.id)])
        if emp_id:
            return True
        else:
            return False

    def _get_report_values(self, docids, data=None):
        payslip_run = self.env['hr.payslip.run'].browse(docids)
        return {
            'doc': self,
            'docs': payslip_run,
        }
