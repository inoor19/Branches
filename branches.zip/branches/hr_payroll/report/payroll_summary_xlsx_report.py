# -*- coding: utf-8 -*-
##############################################################################
#
#	NCTR, Nile Center for Technology Research
#	Copyright (C) 2021-2021 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import models
import string


class SummaryXlsxReport(models.AbstractModel):
    _name = 'report.hr_payroll.xlsx_payroll_summary_report'
    _inherit = 'report.report_xlsx.abstract'
    _description = 'Summary Payroll Report'

    def generate_xlsx_report(self, workbook, data, lines):
        format1 = workbook.add_format(
            {'font_size': 12, 'align': 'vcenter', 'bold': True, 'bg_color': '#d2ecfa', 'color': 'black',
             'bottom': True, })
        format2 = workbook.add_format(
            {'font_size': 12, 'align': 'vcenter', 'bold': True, 'bg_color': '#d2ecfa', 'color': 'black',
             'num_format': '#,##0.00'})
        format3 = workbook.add_format({'font_size': 11, 'align': 'vcenter', 'bold': False, 'num_format': '#,##0.00'})
        format3_colored = workbook.add_format(
            {'font_size': 11, 'align': 'vcenter', 'bg_color': '#f7fcff', 'bold': False, 'num_format': '#,##0.00'})
        format4 = workbook.add_format({'font_size': 12, 'align': 'vcenter', 'bold': True})
        format5 = workbook.add_format({'font_size': 12, 'align': 'vcenter', 'bold': False})
        sheet = workbook.add_worksheet('Employees Sheet')
        cols = list(string.ascii_uppercase) + ['AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK',
                                               'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV',
                                               'AW', 'AX', 'AY', 'AZ']


        # List report column headers:
        batch_period = str(lines.date_start.strftime('%B %d, %Y')) + '  To  ' + str(
            lines.date_end.strftime('%B %d, %Y'))
        company_name = lines.env.company.name
        # Company Name
        sheet.write(0, 0, company_name, format4)

        sheet.write(0, 2, 'Payslip Period:', format4)
        sheet.write(0, 3, batch_period, format5)

        sheet.write(2, 0, 'Employee Name', format1)
        # sheet.write(2, 1, 'Department', format1)
        sheet.write(2, 1, 'Structure', format1)
        sheet.write(2, 2, 'Net', format1)

        # Report
        # Details:
        details_row = 3
        has_payslips = False
        for slip in lines.slip_ids:
            if lines.slip_ids:
                has_payslips = True
                sheet.write(details_row, 0, slip.employee_id.name, format3)
                # sheet.write(details_row, 1, slip.employee_id.department_id.name, format3)
                sheet.write(details_row, 1, slip.struct_id.name, format3)
                sheet.write(details_row, 2, slip.net_wage, format3)
                details_row += 1

        # Generate summission row at report end:
        sum_x = details_row
        total = 0.0
        if has_payslips == True:
            sheet.write(sum_x, 0, 'Total', format2)
            sheet.write(sum_x, 1, '', format2)
            for slip in lines.slip_ids :
                total += slip.net_wage
            sheet.write(sum_x, 2, total, format2)

        # set width and height of colmns & rows:
        sheet.set_column('A:A', 35)
        sheet.set_column('B:B', 20)
        sheet.set_column('C:C', 20)
        #sheet.set_column('D:D', 20)
