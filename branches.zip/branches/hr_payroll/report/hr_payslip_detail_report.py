# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
###############################################################################


from odoo import api, models


class HRPayslipDetailsReport(models.AbstractModel):
    _name = 'report.hr_payroll.payroll_detailed_report'
    _description = 'Payslip Details Report'

    def get_salary_details(self, payslip_run):
        allwo_names = []
        allwo_names_total = {}
        alow_total = 0
        allwo_indesc = {}
        dedu_names = []
        deduct_names_total = {}
        du_total = 0
        dedu_indesc = {}
        report_data_dic = {}
        for line in payslip_run.slip_ids:
            alow_total = 0
            allow_dict_dict = {}
            ded_total = 0
            emp_alow_total = 0.0
            emp_dedu_total = 0.0
            emp_net_salary = 0.0

            emp_dedu_dict = {}

            for allwo in line.line_ids.filtered(lambda d: d.salary_rule_id.category_id.rule_type in ['allowance',
                                                                                                     'bonus'] and d.salary_rule_id.code not in [
                                                              'NET', 'GROSS']):
                if allwo.name not in allwo_names:
                    allwo_names.append(allwo.name)
                    allwo_indesc[allwo.name] = len(allwo_names)
                    allwo_names_total[allwo_indesc[allwo.name]] = 0
                allow_dict_dict[allwo_indesc[allwo.name]] = allwo.total
                allwo_names_total[allwo_indesc[allwo.name]] = round(allwo_names_total[allwo_indesc[allwo.name]],
                                                                    2) + round(allwo.total, 2)
            for ded in line.line_ids.filtered(lambda d: d.salary_rule_id.category_id.rule_type == 'deduction'):
                if ded.name not in dedu_names:
                    dedu_names.append(ded.name)
                    dedu_indesc[ded.name] = len(dedu_names)
                    deduct_names_total[dedu_indesc[ded.name]] = 0
                emp_dedu_dict[dedu_indesc[ded.name]] = ded.total
                deduct_names_total[dedu_indesc[ded.name]] = round(deduct_names_total[dedu_indesc[ded.name]],
                                                                  2) + round(ded.total, 2)

            emp_alow_total = sum(
                line.line_ids.filtered(
                    lambda d: d.salary_rule_id.category_id.rule_type == 'allowance' and d.salary_rule_id.code not in [
                        'NET', 'GROSS']).mapped(
                    'total'))
            emp_dedu_total = sum(
                line.line_ids.filtered(lambda d: d.salary_rule_id.category_id.rule_type == 'deduction').mapped(
                    'total'))
            emp_net_salary = line.net_wage
            report_data_dic[line.employee_id.id] = {
                'emp_id': line.employee_id,
                'name': line.employee_id.name,
                'code': line.employee_id.emp_code,
                'degree': line.employee_id.struct_id.name,
                'degree_id': line.employee_id.struct_id.id,
                'emp_allwo': allow_dict_dict,
                'emp_dedu': emp_dedu_dict,
                'emp_alow_total': emp_alow_total,
                'emp_dedu_total': emp_dedu_total,
                'emp_net_salary': emp_net_salary,

            }
        for y in report_data_dic:
            docargs = {
                'doc_ids': payslip_run,
                'doc_model': 'hr.payslip',
                # allowances
                'allwo_names': allwo_names,
                'total_allow_total': allwo_names_total,
                'alw_total': alow_total,
                'allowance_shift': len(allwo_names),
                # deductions
                'dedu_names': dedu_names,
                'total_deduct_total': deduct_names_total,
                'du_total': du_total,
                'deduction_shift': len(dedu_names),
                'report_data_dic': report_data_dic,
            }
        return docargs

    def get_child_struct_ids(self, emp, struct):
        emp_id = self.env['hr.employee'].search([('id', '=', emp.id), ('struct_id', 'child_of', struct.id)])
        if emp_id:
            return True
        else:
            return False

    @api.model
    def _get_report_values(self, docids, data=None):
        payslip_run = self.env['hr.payslip.run'].browse(docids)
        datas = self.get_salary_details(payslip_run)
        return {
            'doc_ids': docids,
            'doc_model': 'hr.payslip.run',
            'docs': payslip_run,
            'data': data,
            'doc': self,
            'get_salary_details': datas,
        }
