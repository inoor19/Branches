# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class HrEmployee(models.Model):
    _inherit = 'hr.employee'
    _order = "struct_id, emp_code"

    last_promotion_date = fields.Date('Last Promotion Date', readonly=True, tracking=True)
    struct_id = fields.Many2one('hr.payroll.structure', string='Salary Structure', tracking=True)
    medical_allowance = fields.Monetary(string="Medical Allowance", help="Medical allowance")
    tax_exempted = fields.Boolean(string='Tax Exempted', default=False, readonly=True, tracking=True)

    @api.model
    def create(self, vals):
        rec = super(HrEmployee, self).create(vals)
        rec.contract_id.write({'struct_id': vals.get('struct_id'),})
        return rec
        
    @api.constrains('wage')
    def _check_wage(self):
        for rec in self:
            if rec.struct_id.min_limit and rec.wage < rec.struct_id.min_limit:
                raise ValidationError(_('Wage must be between salary structure minimum Limit and maximum Limit'))
            if rec.struct_id.max_limit and rec.wage > rec.struct_id.max_limit:
                raise ValidationError(_('Wage must be between salary structure minimum Limit and maximum Limit'))



    def get_work_days_data(self, from_datetime, to_datetime, contract=None, calendar=None):
        """
        modify the origin method in resource ==> resource_mixin 
        @param contract: payslip contract 
        @param date_from: date field
        @param date_to: date field
        @return: returns dictionary off employee worked days and hours based on employee contract types
        :param from_datetime:
        """
        contract = contract or self.contract_id
        # work_days = contract.structure_type_id.work_days
        # hours = contract.structure_type_id.work_hours
        return {
            'days': 30,
            'hours': 8,
        }

    def write(self, vals):
        res = super(HrEmployee, self).write(vals)
        for rec in self:
            rec.reflect_to_contract(vals)

        return res

    def reflect_to_contract(self, vals, contract_vals={}, flag=False):
        if vals.get('struct_id') and vals['struct_id'] != self.contract_id.struct_id.id:
            flag = True
            contract_vals.update({'struct_id': vals['struct_id']})

        if flag:
            self.contract_id.write(contract_vals)
        return super(HrEmployee, self).reflect_to_contract(vals)

    def _index_employees(self):
        action = self.env.ref('hr_payroll.action_hr_payroll_index').read()[0]
        action['context'] = repr(self.env.context)
        return action
