# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api , fields, models,_

class HolidaysType(models.Model):
    _inherit = "hr.leave.type"
    
    payslip_type = fields.Selection([
        ('paid','Paid') ,
        ('unpaid','Unpaid') ,
        ('addition','Addition') ,
        ('exclusion','Exclusion'),('percentage','Percentage') ] ,string = "Payslip Type" , default="paid", required=True)
    rule_ids = fields.Many2many('hr.salary.rule',string = "Rules")
    percentage =fields.Float(string='Percentage')
    
    
