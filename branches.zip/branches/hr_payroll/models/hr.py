# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

class HrPromotion(models.Model):
    _name = 'hr.promotion'
    _description = "Promotions"
    _inherit = ['mail.thread']
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', 'Employee', required=True, domain=[('state', '=', 'approved')])
    date = fields.Date('Date', required=True, default=fields.Date.today())
    current_degree_id = fields.Many2one('hr.payroll.structure', string='Current Degree', required=True, tracking=True)
    new_degree_id = fields.Many2one('hr.payroll.structure', 'New Degree', required=True, tracking=True)
    change_job = fields.Boolean("Change Job", default=True, tracking=True)
    current_job_id = fields.Many2one("hr.job", string="Current Job Position", tracking=True)
    new_job_id = fields.Many2one('hr.job', 'New Job Position', tracking=True)
    current_wage = fields.Float(string="Current Wage", required=True)
    new_wage = fields.Float('New Wage', tracking=True, required=True)
    job_transfer_id = fields.Many2one("hr.employee.job.transfer")
    note = fields.Html("Note")
    company_id = fields.Many2one(related='employee_id.company_id', readonly=True, store=True)
    state = fields.Selection([('draft', 'draft'), ('approve', 'approved')], 'State', default='draft', tracking=True)

    @api.constrains('new_wage')
    def _check_wage(self):
        for rec in self:
            if rec.new_degree_id.min_limit and rec.new_wage < rec.new_degree_id.min_limit:
                raise ValidationError(_('Wage must be between salary structure minimum Limit and maximum Limit'))
            if rec.new_degree_id.max_limit and rec.new_wage > rec.new_degree_id.max_limit:
                raise ValidationError(_('Wage must be between salary structure minimum Limit and maximum Limit'))

    @api.onchange('employee_id')
    def _employee_id(self):
        if self.employee_id:
            self.current_degree_id = self.employee_id.struct_id.id
            self.current_job_id = self.employee_id.job_id.id
            self.current_wage = self.employee_id.wage

    def approve_promotion(self):
        for rec in self:
            rec.employee_id.write({
                'struct_id': rec.new_degree_id.id,
                'last_promotion_date': rec.date,
                'wage': rec.new_wage
                })
            self.write({'state': 'approve'})
            if rec.change_job:
                if not rec.job_transfer_id:
                    job_transfer_id = rec.env['hr.employee.job.transfer'].create({
                        'employee_id': rec.employee_id.id,
                        'date': rec.date,
                        'current_job_id': rec.current_job_id.id,
                        'new_job_id': rec.new_job_id.id,
                        'state': rec.state
                    })
                    rec.job_transfer_id = job_transfer_id
                else:
                    rec.job_transfer_id.write({
                        'employee_id': rec.employee_id.id,
                        'date': rec.date,
                        'current_job_id': rec.current_job_id.id,
                        'new_job_id': rec.new_job_id.id,
                        'state': rec.state})
                rec.employee_id.write({'job_id': rec.new_job_id.id, })

    def set_to_draft(self):
        for rec in self:
            self.write({'state': 'draft'})
            self.employee_id.write({
                'struct_id': self.current_degree_id.id,
                'job_id': self.current_job_id.id,
                'last_promotion_date': '',
                'wage': rec.current_wage
            })

    def unlink(self):
        if self.state != 'draft':
            raise UserError(_('You cannot delete a record which is not draft!'))
        return super(HrPromotion, self).unlink()


class Job(models.Model):
    _inherit = 'hr.job'

    struct_id = fields.Many2one("hr.payroll.structure", string="Structure")
