# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import api, fields, models


class HrContract(models.Model):
    """
    Employee contract based on the visa, work permits
    allows to configure different Salary structure
    """
    _inherit = 'hr.contract'
    _description = 'Employee Contract'

    struct_id = fields.Many2one('hr.payroll.structure', string='Salary Structure')
    resource_calendar_id = fields.Many2one(required=True, help="Employee's working schedule.")
    exception_ids = fields.One2many('hr.salary.exception', 'contract_id', string='Salary Expectations ', copy=True,
                                    store=True)

    def get_all_structures(self):

        """
        @return: the structures linked to the given contracts, ordered by hierarchy (parent=False first,
                 then first level children and so on) and without duplicate
        """
        structures = self.mapped('struct_id')
        if not structures:
            return []
        # YTI TODO return browse records
        return list(set(structures._get_parent_structure().ids))

    def write(self, vals):
        res = super(HrContract, self).write(vals)
        for rec in self:
            rec.reflect_to_employee(vals)
        return res

    def reflect_to_employee(self, vals, employee_vals={}, flag=False):
        if vals.get('struct_id') and vals['struct_id'] != self.employee_id.struct_id.id:
            flag = True
            employee_vals.update({'struct_id': vals['struct_id']})

        if flag:
            self.employee_id.write(employee_vals)

        return super(HrContract, self).reflect_to_employee(vals)

class SalaryException(models.Model):
    _name = 'hr.salary.exception'
    _description = 'Salary Exceptions'
    _inherit = ['mail.thread']

    contract_id = fields.Many2one('hr.contract', string='Contract', required=True)
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True, tracking=True)
    exception_type = fields.Selection([
        ('allocation', 'Allocation'),
        ('exclude', 'Exclude')], 'Expectation Type', tracking=True, required=True)
    salary_rule_id = fields.Many2one('hr.salary.rule', string='Allowance/Deduction', tracking=True, required=True)
    amount = fields.Float(string='Amount', required=True, )
    date_from = fields.Date(string='Start Date', required=True, )
    date_to = fields.Date(string='End Date')
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(related='employee_id.company_id')
    

    @api.onchange('exception_type')
    def onchange_action(self):
        if self.exception_type == 'allocation':
            return {'domain': {'salary_rule_id': [('special', '=', True)]}}
        else:
            return {'domain': {'salary_rule_id': []}}
            
    @api.model
    def _cron_check_exception_end(self):
        # Called by a cron

       date = fields.Date.today()
       end_exception_ids = self.search([('date_to', '<=', date)])
       if end_exception_ids:
              end_exception_ids.write({'active':False})
    
