# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


import babel
from collections import defaultdict
import time
from calendar import monthrange
from datetime import date, datetime, timedelta, time as datetime_time
from dateutil.relativedelta import relativedelta
import math
from pytz import utc

from odoo import api, fields, models, tools, _
from odoo.addons import decimal_precision as dp
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_utils

# This will generate 16th of days
ROUNDING_FACTOR = 16


class HrPayslip(models.Model):
    _name = 'hr.payslip'
    _description = 'Pay Slips'
    _order = 'date_to desc ,struct_id, emp_code'

    struct_id = fields.Many2one('hr.payroll.structure', string='Structure', readonly=True,)
    name = fields.Char(string='Payslip Name', readonly=True)
    number = fields.Char(string='Reference', readonly=True, copy=False, help="References")
    emp_code = fields.Char(string='Employee Code', readonly=True, copy=False, help="References")
    department_id = fields.Many2one('hr.department', 'Department')
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True, readonly=True, help="Employee")
    contract_id = fields.Many2one('hr.contract', string='Contract', readonly=True, help="Contract")
    payslip_run_id = fields.Many2one('hr.payslip.run', string='Payslip Batches', readonly=True,copy=False)
    type = fields.Selection(string='Type', related='payslip_run_id.type', index=True, copy=False)
    bonus_ids = fields.Many2many('hr.salary.rule', string='Bonuses', related='payslip_run_id.bonus_ids')
    date_from = fields.Date(string='Date From', readonly=True, required=True, help="Start date",
        default=lambda self: fields.Date.to_string(date.today().replace(day=1)))
    date_to = fields.Date(string='Date To', readonly=True, required=True, help="End date",
        default=lambda self: fields.Date.to_string((datetime.now() + relativedelta(months=+1, day=1, days=-1)).date()))
    state = fields.Selection([
        ('draft', 'Draft'),
        ('compute', 'Computed'),
        ('confirm', 'Confirmd'),
        ('verify', 'Verify'),
        ('approve', 'Approved'),
        ('close', 'Close'),
        ('cancel', 'Rejected'),], 
        string='Status', index=True, readonly=True, copy=False, default='draft')
    line_ids = fields.One2many('hr.payslip.line', 'slip_id', string='Payslip Lines', readonly=True)
    company_id = fields.Many2one('res.company', string='Company', readonly=True, copy=False, help="Company",
        default=lambda self: self.env['res.company']._company_default_get())
    worked_days_line_ids = fields.One2many('hr.payslip.worked_days', 'payslip_id',
        string='Payslip Worked Days', copy=True, readonly=True,  help="Payslip worked days")
    basic_wage = fields.Float(compute='compute_basic_net', string="Basic", digits=dp.get_precision('Payroll'), store=True, readonly=True)
    net_wage = fields.Float(compute='compute_basic_net', string="Net", digits=dp.get_precision('Payroll'), store=True, readonly=True)
    total_allow = fields.Float(compute='compute_basic_net', digits=dp.get_precision('Payroll'), string="Total Allowances", store=True, readonly=True)
    total_deduct = fields.Float(compute='compute_basic_net', digits=dp.get_precision('Payroll'), string="Total Deductions", store=True, readonly=True)
    bank_account_id = fields.Many2one('res.partner.bank', 'Bank Account Number')
    
    @api.depends('line_ids', 'line_ids.total')
    def compute_basic_net(self):
        for payslip in self:
            payslip.basic_wage = 0.0
            payslip.total_allow = 0.0
            payslip.total_deduct = 0.0
            payslip.net_wage = 0.0
            if payslip.type == 'salary':
                payslip.basic_wage = payslip._get_salary_line_total('BASIC')
                payslip.net_wage = payslip._get_salary_line_total('NET')
                payslip.total_allow = payslip._get_payslip_line_total('ALW')
                payslip.total_deduct = payslip._get_payslip_line_total('DED')
            else:
                payslip.total_allow = payslip._get_payslip_line_total('MonALW')
                payslip.total_allow += payslip._get_payslip_line_total('QrALW')
                payslip.total_allow += payslip._get_payslip_line_total('YearALW')
                payslip.total_allow += payslip._get_payslip_line_total('BONUS')
                payslip.total_deduct = payslip._get_payslip_line_total('DED')
                payslip.net_wage = payslip.total_allow - payslip.total_deduct

    def unlink(self):
        if any(self.filtered(lambda payslip: payslip.state not in ('draft','compute'))):
            raise UserError(_('You cannot delete a payslip which is not draft'))
        return super(HrPayslip, self).unlink()

    # TODO move this function into hr_contract module, on hr.employee object
    @api.model
    def get_contract(self, employee, date_from, date_to):

        """
        @param employee: recordset of employee
        @param date_from: date field
        @param date_to: date field
        @return: returns the ids of all the contracts for the given employee that need to be considered for the given dates
        """
        # a contract is valid if it ends between the given dates
        clause_1 = ['&', ('date_end', '<=', date_to), ('date_end', '>=', date_from)]
        # OR if it starts between the given dates
        clause_2 = ['&', ('date_start', '<=', date_to), ('date_start', '>=', date_from)]
        # OR if it starts before the date_from and finish after the date_end (or never finish)
        clause_3 = ['&', ('date_start', '<=', date_from), '|', ('date_end', '=', False), ('date_end', '>=', date_to)]
        clause_final = [('employee_id', '=', employee.id), ('state', '=', 'open'), '|',
                        '|'] + clause_1 + clause_2 + clause_3
        return self.env['hr.contract'].search(clause_final).ids

    def recompute_sheet(self):
        for payslip in self:
            payslip.onchange_employee()
            payslip.compute_sheet()
            
        return True
        
    def compute_sheet(self):
        for payslip in self:
            # delete old payslip lines
            payslip.line_ids.unlink()
            rules = [(rule.id, rule.sequence) for rule in payslip.bonus_ids]
            # set the list of contract for which the rules have to be applied
            # if we don't give the contract, then the rules to apply should be for all current contracts of the employee
            contract_ids = payslip.contract_id.ids or \
                           self.get_contract(payslip.employee_id, payslip.date_from, payslip.date_to)
            lines = [(0, 0, line) for line in
                     self.with_context({'rules': rules})._get_payslip_lines(contract_ids, payslip.id)]
            payslip.write({'line_ids': lines,'state': 'compute'})
        return True

    @api.model
    def get_worked_day_lines(self, contracts, date_from, date_to):

        """
        @param contract: Browse record of contracts
        @return: returns a list of dict containing the input that should be applied for the given contract between date_from and date_to
        """
        res = []
        day_from = datetime.combine(fields.Date.from_string(date_from), datetime_time.min)
        day_to = datetime.combine(fields.Date.from_string(date_to), datetime_time.max)
        # fill only if the contract as a working schedule linked
        for contract in contracts.filtered(lambda contract: contract.resource_calendar_id):

            work_data = contract.employee_id.get_work_days_data(day_from, day_to, contract=contract)
            attendances = {
                'name': _("Normal Working Days paid at 100%"),
                'sequence': 1,
                'code': 'WORK100',
                'number_of_days': work_data['days'],
                'number_of_hours': work_data['hours'],
                'contract_id': contract.id,
            }
            res.append(attendances)

            days = 0
            time_delta = relativedelta(day_to, day_from)
            date_from_days = monthrange(date_from.year, date_from.month)[1]
            date_to_days = monthrange(date_to.year, date_to.month)[1]
            if time_delta.years >= 0 and time_delta.months == 11 and time_delta.days in (28, 29, 30, 31):
                days = 365 * (time_delta.years + 1)
            else:
                all_days = time_delta.days + (time_delta.months * 30) + (time_delta.years * 365)
                month_days = time_delta.months * 30
                year_days = time_delta.years * 365
                days = month_days + year_days
                i = 1
                if date_from.month != date_to.month:
                    if date_to_days in (28, 29):
                        if time_delta.days + i in (28, 29):
                            days += 30
                        else:
                            days += time_delta.days + i
                    else:
                        if time_delta.days % work_data['days'] != 0:
                            days += time_delta.days + i
                        else:
                            days += time_delta.days
                else:
                    if date_to_days in (28, 29):
                        if time_delta.days + i in (28, 29):
                            days += 30
                        else:
                            days += time_delta.days + i
                    else:
                        if time_delta.days % work_data['days'] != 0:
                            days += time_delta.days + i
                        else:
                            days += time_delta.days
            salary_period = {
                'name': _("Computation Period"),
                'sequence': 1,
                'code': 'salary_period',
                'number_of_days': days,
                'number_of_hours': work_data['hours'],
                'contract_id': contract.id,
            }
            res.append(salary_period)

            number_of_day = 0
            date_end = fields.Date.from_string(contract.date_end)
            date_start = fields.Date.from_string(contract.date_start)
            from_date = fields.Date.from_string(date_from)
            to_date = fields.Date.from_string(date_to)
            if date_start > from_date:
                time_delta = date_start - from_date
                number_of_day += math.ceil(time_delta.days + float(time_delta.seconds) / 86400)
            if contract.date_end:
                if date_end < to_date:
                    time_delta = to_date - date_end
                    number_of_day += math.ceil(time_delta.days + float(time_delta.seconds) / 86400)
            if number_of_day > 0:
                employment = {
                    'name': _("Employment"),
                    'sequence': 6,
                    'code': 'EMP',
                    'number_of_days': number_of_day,
                    'number_of_hours': 0.0,
                    'contract_id': contract.id,
                }
                res.append(employment)
            # compute leave days
            leaves = self.get_employee_leaves(contract.employee_id,date_from,date_to)
            holidays = {}
            if leaves:
                for leave in leaves:
                    percentage =100
                    if leave.holiday_status_id.payslip_type == 'percentage':
                        percentage = leave.holiday_status_id.percentage
                    current_leave_struct = holidays.setdefault(leave.holiday_status_id, {
                        'name': leave.holiday_status_id.name,
                        'sequence': 5,
                        'code': leave.holiday_status_id.payslip_type,
                        'number_of_days': 0.0,
                        'number_of_hours': 0.0,
                        'percentage': percentage,
                        'holiday_status_id':leave.holiday_status_id.id,
                        'contract_id': self.contract_id,
                    })
                    
                    start_leave=date_from
                    end_leave=date_to
                    if leave.date_from.date()>date_from:
                        start_leave=leave.date_from
                    if leave.date_to.date()<date_to:
                        end_leave=leave.date_to
                    start_leave = fields.Datetime.from_string(start_leave)
                    end_leave = fields.Datetime.from_string(end_leave)
                    time_delta = end_leave - start_leave
                    number_of_days= math.ceil(time_delta.days + float(time_delta.seconds) / 86400)
                    current_leave_struct['number_of_days'] += number_of_days

            res.extend(holidays.values())

        return res

    def get_employee_leaves(self,employee_id,date_from,date_to):
        holiday_status_ids=self.env['hr.leave.type'].search([('payslip_type', 'in', ['paid','unpaid','exclusion','percentage'])])
        employee_leaves=self.env['hr.leave'].search([('employee_id', '=', employee_id.id),
            ('holiday_status_id','in',holiday_status_ids.ids),
            ('state','in',['validate','cut']),
            ('date_to', '>=', date_from),
            ('date_from', '<=', date_to)])
        return employee_leaves

    @api.model
    def _get_payslip_lines(self, contract_ids, payslip_id):
        def _sum_salary_rule_category(localdict, category, amount):
            if category.parent_id:
                localdict = _sum_salary_rule_category(localdict, category.parent_id, amount)
            localdict['categories'].dict[category.code] = category.code in localdict['categories'].dict and \
                                                          localdict['categories'].dict[category.code] + amount or amount
            return localdict

        class BrowsableObject(object):
            def __init__(self, employee_id, dict, env):
                self.employee_id = employee_id
                self.dict = dict
                self.env = env

            def __getattr__(self, attr):
                return attr in self.dict and self.dict.__getitem__(attr) or 0.0

        class InputLine(BrowsableObject):
            """a class that will be used into the python code, mainly for usability purposes"""

            def sum(self, code, from_date, to_date=None):
                if to_date is None:
                    to_date = fields.Date.today()
                self.env.cr.execute("""
                    SELECT sum(amount) as sum
                    FROM hr_payslip as hp, hr_payslip_input as pi
                    WHERE hp.employee_id = %s AND hp.state = 'done'
                    AND hp.date_from >= %s AND hp.date_to <= %s AND hp.id = pi.payslip_id AND pi.code = %s""",
                                    (self.employee_id, from_date, to_date, code))
                return self.env.cr.fetchone()[0] or 0.0

        class WorkedDays(BrowsableObject):
            """a class that will be used into the python code, mainly for usability purposes"""

            def _sum(self, code, from_date, to_date=None):
                if to_date is None:
                    to_date = fields.Date.today()
                self.env.cr.execute("""
                    SELECT sum(number_of_days) as number_of_days, sum(number_of_hours) as number_of_hours
                    FROM hr_payslip as hp, hr_payslip_worked_days as pi
                    WHERE hp.employee_id = %s AND hp.state = 'done'
                    AND hp.date_from >= %s AND hp.date_to <= %s AND hp.id = pi.payslip_id AND pi.code = %s""",
                                    (self.employee_id, from_date, to_date, code))
                return self.env.cr.fetchone()

            def sum(self, code, from_date, to_date=None):
                res = self._sum(code, from_date, to_date)
                return res and res[0] or 0.0

            def sum_hours(self, code, from_date, to_date=None):
                res = self._sum(code, from_date, to_date)
                return res and res[1] or 0.0

        class Payslips(BrowsableObject):
            """a class that will be used into the python code, mainly for usability purposes"""

            def sum(self, code, from_date, to_date=None):
                if to_date is None:
                    to_date = fields.Date.today()
                self.env.cr.execute("""SELECT sum(case when hp.credit_note = False then (pl.total) else (-pl.total) end)
                            FROM hr_payslip as hp, hr_payslip_line as pl
                            WHERE hp.employee_id = %s AND hp.state = 'done'
                            AND hp.date_from >= %s AND hp.date_to <= %s AND hp.id = pl.slip_id AND pl.code = %s""",
                                    (self.employee_id, from_date, to_date, code))
                res = self.env.cr.fetchone()
                return res and res[0] or 0.0

        # we keep a dict with the result because a value can be overwritten by another rule with the same code
        result_dict = {}
        rules_dict = {}
        worked_days_dict = {}
        inputs_dict = {}
        blacklist = []
        payslip = self.env['hr.payslip'].browse(payslip_id)
        for worked_days_line in payslip.worked_days_line_ids:
            worked_days_dict[worked_days_line.code] = worked_days_line

        categories = BrowsableObject(payslip.employee_id.id, {}, self.env)
        worked_days = WorkedDays(payslip.employee_id.id, worked_days_dict, self.env)
        payslips = Payslips(payslip.employee_id.id, payslip, self.env)
        rules = BrowsableObject(payslip.employee_id.id, rules_dict, self.env)
        baselocaldict = {'categories': categories, 'rules': rules, 'payslip': payslips, 'worked_days': worked_days}
        # get the ids of the structures on the contracts and their parent id as well
        contracts = self.env['hr.contract'].browse(contract_ids)
        if len(contracts) == 1 and payslip.struct_id:
            structure_ids = list(set(payslip.struct_id._get_parent_structure().ids))
        else:
            structure_ids = contracts.get_all_structures()
        # get the rules of the structure and thier children
        rule_ids = self.env['hr.payroll.structure'].browse(structure_ids).get_all_rules()
        # run the rules by sequence
        sorted_rule_ids = [id for id, sequence in sorted(rule_ids, key=lambda x: x[1])]
        sorted_rules = self.env['hr.salary.rule'].browse(sorted_rule_ids)
        for contract in contracts:
            employee = contract.employee_id
            localdict = dict(baselocaldict, employee=employee, contract=contract)
            for rule in sorted_rules:
                key = rule.code + '-' + str(contract.id)
                localdict['result'] = None
                localdict['result_qty'] = 1.0
                localdict['result_rate'] = 100
                # check if the rule can be applied
                if rule._satisfy_condition(localdict) and rule.id not in blacklist:
                    # compute the amount of the rule
                    amount, qty, rate = rule._compute_rule(localdict)
                    # check if there is already a rule computed with that code
                    previous_amount = rule.code in localdict and localdict[rule.code] or 0.0
                    # set/overwrite the amount computed for this rule in the localdict
                    tot_rule = amount * qty * rate / 100.0
                    localdict[rule.code] = tot_rule
                    rules_dict[rule.code] = rule
                    # sum the amount for its salary category
                    localdict = _sum_salary_rule_category(localdict, rule.category_id, tot_rule - previous_amount)
                    # create/overwrite the rule in the temporary results
                    result_dict[key] = {
                        'salary_rule_id': rule.id,
                        'contract_id': contract.id,
                        'name': rule.name,
                        'code': rule.code,
                        'sequence': rule.sequence,
                        'amount': amount,
                        'employee_id': contract.employee_id.id,
                        'quantity': qty,
                        'rate': rate,
                    }

        return list(result_dict.values())

    # YTI TODO To rename. This method is not really an onchange, as it is not in any view
    # employee_id and contract_id could be browse records
    def onchange_employee_id(self, payslip_run, date_from, date_to, employee_id=False, contract_id=False):

        # defaults
        res = {
            'value': {
                'line_ids': [],
                # delete old input lines
                # delete old worked days lines
                'worked_days_line_ids': [(2, x,) for x in self.worked_days_line_ids.ids],
                # 'details_by_salary_head':[], TODO put me back
                'name': '',
                'contract_id': False,
                'struct_id': False,
            }
        }
        if (not employee_id) or (not date_from) or (not date_to):
            return res
        ttyme = datetime.fromtimestamp(time.mktime(time.strptime(str(date_from), "%Y-%m-%d")))
        employee = self.env['hr.employee'].browse(employee_id)
        locale = self.env.context.get('lang') or 'en_US'
        if payslip_run.type == 'salary':
            res['value'].update({
                'name': _('Salary Slip of %s for %s') % (
                    employee.name, tools.ustr(babel.dates.format_date(date=ttyme, format='MMMM-y', locale=locale))),
                'company_id': employee.company_id.id,
            })
        else:
            res['value'].update({
                'name': _('Bonus Slip of %s for %s') % (
                    employee.name, tools.ustr(babel.dates.format_date(date=ttyme, format='MMMM-y', locale=locale))),
                'company_id': employee.company_id.id,
            })

        if not self.env.context.get('contract'):
            # fill with the first contract of the employee
            contract_ids = self.get_contract(employee, date_from, date_to)
        else:
            if contract_id:
                # set the list of contract for which the input have to be filled
                contract_ids = [contract_id]
            else:
                # if we don't give the contract, then the input to fill should be for all current contracts of the employee
                contract_ids = self.get_contract(employee, date_from, date_to)

        if not contract_ids:
            return res
        contract = self.env['hr.contract'].browse(contract_ids[0])
        res['value'].update({
            'contract_id': contract.id
        })
        struct = contract.struct_id
        if not struct:
            return res
        res['value'].update({
            'struct_id': struct.id,
        })
        # computation of the salary input
        contracts = self.env['hr.contract'].browse(contract_ids)
        flags = []
        worked_days_line_ids = ''
        if payslip_run.type == 'salary':
            flags.append(True)

        elif payslip_run.type == 'bonus':
            for bonus in payslip_run.bonus_ids:
                # if bonus.absence == True :
                flags.append(True)
        else:
            flags.append(False)
        for flag in flags:
            if flag == True:
                worked_days_line_ids = self.get_worked_day_lines(contracts, date_from, date_to)
        res['value'].update({
            'worked_days_line_ids': worked_days_line_ids,
        })
        return res

    @api.onchange('employee_id', 'date_from', 'date_to','line_ids')
    def onchange_employee(self):

        if (not self.employee_id) or (not self.date_from) or (not self.date_to):
            return

        employee = self.employee_id
        date_from = self.date_from
        date_to = self.date_to
        contract_ids = []

        ttyme = datetime.combine(fields.Date.from_string(date_from), datetime_time.min)
        locale = self.env.context.get('lang') or 'en_US'
        if self.payslip_run_id.type == 'salary':
            self.name = _('Salary Slip of %s for %s') % (
                employee.name, tools.ustr(babel.dates.format_date(date=ttyme, format='MMMM-y', locale=locale)))
        else:
            self.name = _('Bonus Slip of %s for %s') % (
                employee.name, tools.ustr(babel.dates.format_date(date=ttyme, format='MMMM-y', locale=locale)))
        self.company_id = employee.company_id

        if not self.env.context.get('contract') or not self.contract_id:
            contract_ids = self.get_contract(employee, date_from, date_to)
            if not contract_ids:
                return
            self.contract_id = self.env['hr.contract'].browse(contract_ids[0])

        if not self.contract_id.struct_id:
            return
        self.struct_id = self.contract_id.struct_id
        if self.contract_id:
            contract_ids = self.contract_id.ids
        # computation of the salary input
        contracts = self.env['hr.contract'].browse(contract_ids)
        worked_days_line_ids = self.get_worked_day_lines(contracts, date_from, date_to)
        worked_days_lines = self.worked_days_line_ids.browse([])
        for r in worked_days_line_ids:
            worked_days_lines += worked_days_lines.new(r)
        self.worked_days_line_ids = worked_days_lines

        return

    def _get_salary_line_total(self, code):
        lines = self.line_ids.filtered(
            lambda line: line.code == code and line.salary_rule_id.company_contribution == False)
        return sum([line.total for line in lines])

    def _get_payslip_line_total(self, code):
        lines = self.line_ids.filtered(lambda line: line.category_id.code == code)
        return sum([line.total for line in lines])

    @api.onchange('contract_id')
    def onchange_contract(self):
        if not self.contract_id:
            self.struct_id = False
        self.with_context(contract=True).onchange_employee()
        return

    def get_salary_line_total(self, code):
        self.ensure_one()
        line = self.line_ids.filtered(lambda line: line.code == code)
        if line:
            return line[0].total
        else:
            return 0.0


class HrPayslipLine(models.Model):
    _name = 'hr.payslip.line'
    _description = 'Allowance and Deduction Archive'
    _order = 'employee_id, sequence, code'

    name = fields.Char(required=True)
    note = fields.Text(string='Description')
    sequence = fields.Integer(required=True, index=True, default=5,
        help='Use to arrange calculation sequence')
    code = fields.Char(required=True,
        help="The code of salary rules can be used as reference in computation of other rules. In that case, it is case sensitive.")
    slip_id = fields.Many2one('hr.payslip', string='Pay Slip', required=True, ondelete='cascade', help="Payslip")
    salary_rule_id = fields.Many2one('hr.salary.rule', string='Allowances/Deduction', required=True, help="Allowances/Deduction")
    rule_type = fields.Selection(string='Rule Type', index=True, required=False, related='salary_rule_id.rule_type', store=True)
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True, help="Employee")
    contract_id = fields.Many2one('hr.contract', string='Contract', required=False, index=True, help="Contract")
    register_id = fields.Many2one('hr.contribution.register', string='Contribution Register',
         help="Eventual third party involved in the salary payment of the employees.")
    rate = fields.Float(string='Rate (%)', digits=dp.get_precision('Payroll Rate'), default=100.0)
    amount = fields.Float(digits=dp.get_precision('Payroll'))
    quantity = fields.Float(digits=dp.get_precision('Payroll'), default=1.0)
    total = fields.Float(compute='_compute_total', string='Total', help="Total", digits=dp.get_precision('Payroll'), store=True)
    amount_select = fields.Selection(related='salary_rule_id.amount_select', readonly=True)
    amount_fix = fields.Float(related='salary_rule_id.amount_fix', readonly=True)
    amount_percentage = fields.Float(related='salary_rule_id.amount_percentage', readonly=True)
    category_id = fields.Many2one(related='salary_rule_id.category_id', readonly=True, store=True)
    date_from = fields.Date(string='From', related="slip_id.date_from", store=True)
    date_to = fields.Date(string='To', related="slip_id.date_to", store=True)
    company_id = fields.Many2one(related='slip_id.company_id', store=True)
    days = fields.Integer(required=True, default=30)

    @api.depends('quantity', 'amount', 'rate')
    def _compute_total(self):
        for line in self:
            line.total = float(line.quantity) * line.amount * line.rate / 100

    @api.model_create_multi
    def create(self, vals_list):
        for values in vals_list:
            if 'employee_id' not in values or 'contract_id' not in values:
                payslip = self.env['hr.payslip'].browse(values.get('slip_id'))
                values['employee_id'] = values.get('employee_id') or payslip.employee_id.id
                values['contract_id'] = values.get('contract_id') or payslip.contract_id and payslip.contract_id.id
                if not values['contract_id']:
                    raise UserError(_('You must set a contract to create a payslip line.'))
        return super(HrPayslipLine, self).create(vals_list)


class HrPayslipWorkedDays(models.Model):
    _name = 'hr.payslip.worked_days'
    _description = 'Payslip Worked Days'
    _order = 'payslip_id, sequence'

    name = fields.Char(string='Description', required=True, translate=True)
    payslip_id = fields.Many2one('hr.payslip', string='Pay Slip', required=True, ondelete='cascade', index=True,help="Payslip")
    sequence = fields.Integer(required=True, index=True, default=10, help="Sequence")
    code = fields.Char(required=True, help="The code that can be used in the salary rules")
    number_of_days = fields.Float(string='Number of Days', help="Number of days worked")
    number_of_hours = fields.Float(string='Number of Hours', help="Number of hours worked")
    percentage = fields.Float(string='Percentage', default=100)
    contract_id = fields.Many2one('hr.contract', string='Contract', required=False, help="The contract for which applied this input")
    holiday_status_id = fields.Many2one("hr.leave.type", string="Leave Type")


class HrPayslipRun(models.Model):
    _name = 'hr.payslip.run'
    _inherit = ['mail.thread']
    _description = 'Payslips Computation'
    _order = 'id desc'

    name = fields.Char(required=True, readonly=True, states={'draft': [('readonly', False)]})
    slip_ids = fields.One2many('hr.payslip', 'payslip_run_id', string='Payslips', readonly=True,
        states={'draft': [('readonly', False)]})
    state = fields.Selection([
        ('draft', 'Draft'),
        ('compute', 'Computed'),
        ('confirm', 'Confirmd'),
        ('verify', 'Verify'),
        ('approve', 'Approved'),
        ('close', 'Close'),
        ('cancel', 'Rejected'),
    ], string='Status', index=True, readonly=True, copy=False, default='draft', tracking=True)
    struct_ids = fields.Many2many("hr.payroll.structure", string="Structure", required=True, readonly=True,
        states={'draft': [('readonly', False)]}, tracking=True)
    type = fields.Selection([
        ('salary', 'Salary'),
        ('bonus', 'Bonus'),
    ], string='Type', readonly=True, states={'draft': [('readonly', False)]}, index=True, copy=False, default='salary')
    bonus_ids = fields.Many2many('hr.salary.rule', string='Bonuses', readonly=True,
        states={'draft': [('readonly', False)]})
    employee_ids = fields.Many2many('hr.employee', string='Employees', states={'draft': [('readonly', False)]}, readonly=True)
    date_start = fields.Date(string='Date From', required=True, readonly=True, help="start date",
        states={'draft': [('readonly', False)]}, default=lambda self: fields.Date.to_string(date.today().replace(day=1)))
    date_end = fields.Date(string='Date To', required=True, readonly=True, help="End date",
        states={'draft': [('readonly', False)]}, default=lambda self: fields.Date.to_string( (datetime.now() + relativedelta(months=+1, day=1, days=-1)).date()))
    compute_date = fields.Date(string='Compute Date', required=True, readonly=True, help="Compute Date",
        states={'draft': [('readonly', False)]},  default=lambda self: fields.Date.to_string(date.today()))
    payslip_count = fields.Integer(compute='_compute_payslip_count')
    move_id = fields.Many2one('account.move', 'Accounting Entry', readonly=True, copy=False)
    company_id = fields.Many2one('res.company', string='Company', readonly=True, required=True, default=lambda self: self.env.company)
    payment_state = fields.Selection(
        selection=[
            ('not_paid', 'Not Registered'),
            ('in_payment', 'In Payment'),
            ('paid', 'Paid'),
            ('reversed', 'Reversed'),
        ], string="Payment Status", compute='_compute_payment_state', store=True, readonly=True, copy=False, tracking=True)
    net_wage = fields.Float(compute='_compute_net', string="Net", store=True, readonly=True, copy=False, tracking=True)
    appears_on_report = fields.Boolean(default=True)
    
    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        if any(self.filtered(lambda run: run.date_start > run.date_end)):
            raise ValidationError(_("Payslip 'Date From' must be earlier 'Date To'."))

    @api.depends('move_id.payment_state')
    def _compute_payment_state(self):
        for payslip_run in self:
            payment_state = 'not_paid'
            if payslip_run.move_id:
               payment_state = 'in_payment'
               if payslip_run.move_id.payment_state in ['paid','partial']:
                   payment_state = 'paid'
               if payslip_run.move_id.payment_state in ['reversed','cancel']:
                   payment_state = 'reversed'
            payslip_run.payment_state = payment_state
                        
    @api.depends('slip_ids.net_wage' )
    def _compute_net(self):
        for run in self:  
            total = 0.0
            for line in run.slip_ids:
                total += line.net_wage
            run.net_wage = total
              
    def _compute_payslip_count(self):
        for payslip_run in self:
            payslip_run.payslip_count = len(self.slip_ids)

    @api.model
    def get_contract(self, struct_ids, employee_ids, date_from, date_to):
        """
        @param employee: recordset of employee
        @param date_from: date field
        @param date_to: date field
        @return: returns the ids of all the contracts for the given employee that need to be considered for the given dates
        """

        # a contract is valid if it ends between the given dates
        clause_1 = ['&', ('date_end', '<=', date_to), ('date_end', '>=', date_from)]
        # OR if it starts between the given dates
        clause_2 = ['&', ('date_start', '<=', date_to), ('date_start', '>=', date_from)]
        # OR if it starts before the date_from and finish after the date_end (or never finish)
        clause_3 = ['&', ('date_start', '<=', date_from), '|', ('date_end', '=', False), ('date_end', '>=', date_to)]
        clause_final = [('state', '=', 'open'), '|', '|'] + clause_1 + clause_2 + clause_3
        if struct_ids:
            clause_final += [ ('struct_id', 'child_of', struct_ids.ids)]
        if employee_ids:
            clause_final += [('employee_id', 'in', employee_ids.ids)]
        return self.env['hr.contract'].search(clause_final).ids

    def compute_sheet(self):
        compute_start = datetime.now()
        self.slip_ids.unlink()
        payslips = self.env['hr.payslip']
        payslips_line = self.env['hr.payslip.line']
        from_date = self.date_start
        to_date = self.date_end
        payslip_run = self
        contracts = self.get_contract(self.struct_ids, self.employee_ids, from_date, to_date)
        clause_1 = (['&', ('date_to', '<=', to_date), ('date_to', '>=', from_date)])
        clause_2 = ['&', ('date_from', '<=', to_date), ('date_from', '>=', from_date)]
        clause_3 = ['&', ('date_from', '<=', from_date), '|', ('date_to', '=', False), ('date_to', '>=', to_date)]
        clause = [('type', '=', self.type), ('contract_id', 'in', contracts),
                  ('struct_id', 'child_of', self.struct_ids.ids), '|', '|'] + clause_1 + clause_2 + clause_3
        payslip_ids = payslips.search(clause)
        if payslip_ids and self.type == 'bonus':
           bonuses = payslips_line.search([('salary_rule_id', 'in', self.bonus_ids.ids), ('slip_id', 'in', payslip_ids.ids)])
           if not bonuses:
                payslip_ids = []
        if payslip_ids:
            raise UserError(_('The %s In The %sth Month Year Of %s It is  Already Computed')
                            % (self.type, self.date_start, self.date_end))
        for contract in self.env['hr.contract'].browse(contracts):
            for employee in contract.employee_id:
                slip_data = self.env['hr.payslip'].with_context(contract=True).onchange_employee_id(payslip_run,
                                                                                                    from_date, to_date,
                                                                                                    employee.id,
                                                                                                    contract_id=contract.id)
                res = {
                    'employee_id': employee.id,
                    'emp_code': employee.emp_code,
                    'name': slip_data['value'].get('name'),
                    'struct_id': slip_data['value'].get('struct_id'),
                    'contract_id': contract.id,
                    'payslip_run_id': self.id,
                    'worked_days_line_ids': [(0, 0, x) for x in slip_data['value'].get('worked_days_line_ids')],
                    'date_from': from_date,
                    'date_to': to_date,
                    'company_id': employee.company_id.id,
                    'department_id': contract.department_id.id,
                    'bank_account_id': employee.bank_account_id.id,
                    'bonus_ids': [(6, 0, self.bonus_ids.ids)],
                }
                payslips += self.env['hr.payslip'].create(res)        

        payslips.compute_sheet()
        compute_time = datetime.now() - compute_start
        print(">>>>>>>>>>>>>>>>>>compute_time<<<<<<<<<<<<<<<<<<<<<<",compute_time)
        return self.write({'state': 'compute'})

    def unlink(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_('You cannot delete a record which is not draft!'))
        return super(HrPayslipRun, self).unlink()
        
    def confirm_payslip_run(self):
        self.slip_ids.write({'state': 'confirm'})
        return self.write({'state': 'confirm'})
        
    def verify_payslip_run(self):
        self.slip_ids.write({'state': 'verify'})
        return self.write({'state': 'verify'})
        
    def approve_payslip_run(self):
        self.slip_ids.write({'state': 'approve'})
        return self.write({'state': 'approve'})
            
    def to_edit_payslip_run(self):
        self.slip_ids.write({'state': 'compute'})
        return self.write({'state': 'compute'})
        
    def rollback_payslip_run(self):
        self.slip_ids.unlink()
        return self.write({'state': 'draft'})

    def close_payslip_run(self):
        for rec in self:
            for structure in self.env['hr.payroll.structure'].browse(rec.struct_ids.ids) :
                journal_id = structure.journal_id
                break
            if not rec.move_id :
                move_id = self.env['account.move'].sudo().create({
                    'narration': rec.name,
                    'move_type': 'in_invoice',
                    'invoice_user_id': self.env.user.id,
                    'journal_id': journal_id.id or False,
                    'company_id': rec.company_id.id,
                    'ref': rec.name or '',
                    'invoice_date': fields.Date.context_today(self),
                    'source_document': self._name + ',' + str(rec.id),
                    'source_document_state': rec.state,
                    'invoice_line_ids': [(0, 0, x) for x in rec.get_move_line()],
                })
                rec.move_id=move_id
            else :
                rec.move_id.line_ids.unlink()
                rec.move_id.write({'invoice_line_ids': [(0, 0, x) for x in rec.get_move_line()]})

        self.slip_ids.write({'state': 'close'})
        return self.write({'state': 'close'})

    def get_move_line(self):
        lines = []
        allowances = []
        #Allowances    
        self.env.cr.execute("""
            select pl.salary_rule_id as salary_rule_id,
            hp.struct_id as struct_id, 
            sum(COALESCE(pl.total,0)) as total 
            from hr_payslip_line pl 
            left join hr_payslip hp on (pl.slip_id = hp.id)
            where  pl.rule_type != 'deduction' and pl.slip_id IN %s 
            group by  pl.salary_rule_id, hp.struct_id""" , (tuple(self.slip_ids.ids),)) 
        allowances_res = self.env.cr.dictfetchall()
        rules = self.env['hr.salary.rule']
        structures = self.env['hr.payroll.structure']
        for r in allowances_res:
            rule = rules.browse(r['salary_rule_id'])
            if rule.code not in ('NET','GROSS') :
                amount=  round(r['total'], 2) 
                structure = structures.browse(r['struct_id'])
                account_id = rule.account_id and rule.account_id or structure.account_id or False
                if not account_id:
                    raise UserError(_('No Account defined for salary rule  (%s).') % (rule.name))
                dis_list = {structure.account_analytic_id.id}
                distribution = dict.fromkeys(dis_list, 100)
                #if not r['account_analytic_id']:
                #raise UserError(_('No Analytic Account Defined' ))

                line = {
                'name' : rule.name,
                'account_id':account_id.id,
                'quantity':1,
                'price_unit':amount,
                'analytic_distribution': structure.account_analytic_id and distribution or False,
                'tax_ids': []
                }
                allowances.append(line)
            
        lines = self.group_lines(allowances)
        #Deductions 
        deductions =[]
        self.env.cr.execute("""
            select pl.salary_rule_id as salary_rule_id, 
            sum(COALESCE(pl.total,0)) as total 
            from hr_payslip_line pl 
            where pl.rule_type = 'deduction' and pl.slip_id IN %s 
            group by  pl.salary_rule_id""" , (tuple(self.slip_ids.ids),)) 
        deduction_res = self.env.cr.dictfetchall()
        rules = self.env['hr.salary.rule']
        for r in deduction_res:
            rule = rules.browse(r['salary_rule_id'])
            if not rule.account_id:
                raise UserError(_('No Account defined for salary rule  (%s).') % (rule.name))
            amount=  round(r['total'], 2)  
            line = {
                'name' : rule.name,
                'account_id':rule.account_id.id,
                'quantity':1,
                'price_unit':-amount,
                'tax_ids': []
            }
            deductions.append(line)
        lines += self.group_lines(deductions)
        return lines
        
    def group_lines(self, lines):
        line_grouped = {}
        for line in lines:
            key = (line['account_id'])
            if not key in line_grouped:
                line_grouped[key] = line
                if line['price_unit'] > 0:
                    line_grouped[key]['name'] = line['name']
            else:
                line_grouped[key]['price_unit'] += line['price_unit']
                line_grouped[key]['name'] = line_grouped[key]['name'] + "/" +line['name']
        grouped = []
        for key, val in line_grouped.items():
            grouped.append(val)
        return grouped


class ResourceMixin(models.AbstractModel):
    _inherit = "resource.mixin"

    def get_work_days_data(self, from_datetime, to_datetime, compute_leaves=True, calendar=None, domain=None):
        """
            By default the resource calendar is used, but it can be
            changed using the `calendar` argument.

            `domain` is used in order to recognise the leaves to take,
            None means default value ('time_type', '=', 'leave')

            Returns a dict {'days': n, 'hours': h} containing the
            quantity of working time expressed as days and as hours.
        """
        resource = self.resource_id
        calendar = calendar or self.resource_calendar_id

        # naive datetimes are made explicit in UTC
        if not from_datetime.tzinfo:
            from_datetime = from_datetime.replace(tzinfo=utc)
        if not to_datetime.tzinfo:
            to_datetime = to_datetime.replace(tzinfo=utc)

        # total hours per day: retrieve attendances with one extra day margin,
        # in order to compute the total hours on the first and last days
        from_full = from_datetime - timedelta(days=1)
        to_full = to_datetime + timedelta(days=1)
        intervals = calendar._attendance_intervals(from_full, to_full, resource)
        day_total = defaultdict(float)
        for start, stop, meta in intervals:
            day_total[start.date()] += (stop - start).total_seconds() / 3600

        # actual hours per day
        if compute_leaves:
            intervals = calendar._work_intervals(from_datetime, to_datetime, resource, domain)
        else:
            intervals = calendar._attendance_intervals(from_datetime, to_datetime, resource)
        day_hours = defaultdict(float)
        for start, stop, meta in intervals:
            day_hours[start.date()] += (stop - start).total_seconds() / 3600

        # compute number of days as quarters
        days = sum(
            float_utils.round(ROUNDING_FACTOR * day_hours[day] / day_total[day]) / ROUNDING_FACTOR
            for day in day_hours
        )
        return {
            'days': days,
            'hours': sum(day_hours.values()),
        }
