# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools.safe_eval import safe_eval
from odoo.addons import decimal_precision as dp


class HrPayrollStructure(models.Model):
    _name = 'hr.payroll.structure'
    _description = 'Salary Structure'
    _order = 'code'

    name = fields.Char(required=True)
    code = fields.Char(string='Reference', required=True)
    company_id = fields.Many2one('res.company', string='Company')
    note = fields.Text(string='Description')
    rule_ids = fields.Many2many('hr.salary.rule', 'hr_structure_salary_rule_rel', 'struct_id', 'rule_id', string='Salary Rules')
    parent_id = fields.Many2one('hr.payroll.structure', string='Parent')
    taxable = fields.Boolean('Taxable', default=True,
        help="the portion of a person's or company's gross income that the government deems subject to taxes.")
    min_limit = fields.Float('Minimum Limit')
    max_limit = fields.Float('Maximum Limit')
    increase_rate = fields.Float('Increase Rate', default=10,
         help="Percentage increase granted to the employee.")
    margin_time = fields.Integer('Margin Time',
        help="The Difference Between Each Structure And The Next")
    journal_id = fields.Many2one('account.journal', string="Journal", domain=[('type', '=', 'purchase')])
    account_id = fields.Many2one('account.account', 'Account', domain=[('deprecated', '=', False)])
    account_analytic_id = fields.Many2one('account.analytic.account', string='Analytic Account')
    active = fields.Boolean(default=True)

    def name_get(self):
        res = []
        for rec in self:
            if rec.parent_id:
                name = "%s / %s" % (rec.parent_id.name, rec.name)
                res += [(rec.id, name)]
            else:
                res += [(rec.id, rec.name)]
        return res

    @api.constrains('parent_id')
    def _check_parent_id(self):
        if not self._check_recursion():
            raise ValidationError(_('You cannot create a recursive salary structure.'))

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {}, code=_("%s (copy)") % self.code)
        return super(HrPayrollStructure, self).copy(default)

    def get_all_rules(self):
        """
        @return: returns a list of tuple (id, sequence) of rules that are maybe to apply
        """
        all_rules = []
        if self.env.context.get('rules'):
            all_rules = self.env.context.get('rules')
        else:
            for struct in self:
                all_rules += struct.rule_ids._recursive_search_of_rules()

        return all_rules

    def _get_parent_structure(self):
        parent = self.mapped('parent_id')
        if parent:
            parent = parent._get_parent_structure()
        return parent + self
        

class HrContributionRegister(models.Model):
    _name = 'hr.contribution.register'
    _description = 'Contribution Register'

    company_id = fields.Many2one('res.company', string='Company')
    partner_id = fields.Many2one('res.partner', string='Partner')
    name = fields.Char(required=True, translate=True)
    # register_line_ids = fields.One2many('hr.payslip.line', 'register_id',
    #                                     string='Register Line', readonly=True)
    note = fields.Text(string='Description')


class HrSalaryRuleCategory(models.Model):
    _name = 'hr.salary.rule.category'
    _description = 'Salary Rule Category'

    name = fields.Char(required=True, translate=True)
    code = fields.Char(required=True)
    rule_type = fields.Selection([
        ('allowance', 'Allowance'),
        ('deduction', 'Deduction'),
        ('bonus', 'Bonus')
    ], string='Type', index=True, required=True, default='allowance')
    frequency = fields.Selection([
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('yearly', 'Yearly')
    ], string='Frequency', default='monthly')
    parent_id = fields.Many2one('hr.salary.rule.category', string='Parent',
        help="Linking a salary category to its parent is used only for the reporting purpose.")
    children_ids = fields.One2many('hr.salary.rule.category', 'parent_id', string='Children')
    note = fields.Text(string='Description')
    company_id = fields.Many2one('res.company', string='Company')
    active = fields.Boolean(default=True)

    @api.constrains('parent_id')
    def _check_parent_id(self):
        if not self._check_recursion():
            raise ValidationError(_('Error! You cannot create recursive hierarchy of Salary Rule Category.'))


class HrSalaryRule(models.Model):
    _name = 'hr.salary.rule'
    _order = 'sequence, id'
    _description = 'Salary Rule'

    name = fields.Char(required=True)
    code = fields.Char(required=True,
        help="The code of salary rules can be used as reference in computation of other rules. In that case, it is case sensitive.")
    sequence = fields.Integer(required=True, index=True, default=5, help='Use to arrange calculation sequence')
    quantity = fields.Char(default='1.0',
       	help="It is used in computation for percentage and fixed amount. "
            "For e.g. A rule for Meal Voucher having fixed amount of "
            u"1€ per worked day can have its quantity defined in expression "
            "like worked_days.WORK100.number_of_days.")
    category_id = fields.Many2one('hr.salary.rule.category', string='Category', required=True)
    rule_type = fields.Selection(string='Type', index=True, required=False, related='category_id.rule_type', store=True)
    parent_rule_id = fields.Many2one('hr.salary.rule', string='Parent Salary Rule', index=True)
    company_id = fields.Many2one('res.company', string='Company')
    special = fields.Boolean(string='Special')
    based_employment = fields.Boolean('Employment Based')
    condition_select = fields.Selection([
        ('none', 'Always True'),
        ('range', 'Range'),
        ('python', 'Python Expression')
    ], string="Condition Based on", default='none', required=True)
    condition_range = fields.Char(string='Range Based on', default='employee.wage',
                                  help='This will be used to compute the % fields values; in general it is on basic, '
                                       'but you can also use categories code fields in lowercase as a variable names '
                                       '(hra, ma, lta, etc.) and the variable basic.')
    condition_python = fields.Text(string='Python Condition', required=True,
                                   default='''
                    # Available variables:
                    #----------------------
                    # payslip: object containing the payslips
                    # employee: hr.employee object
                    # rules: object containing the rules code (previously computed)
                    # categories: object containing the computed salary rule categories (sum of amount of all rules belonging to that category).
                    # Note: returned value have to be set in the variable 'result'

                    result = rules.NET > categories.NET * 0.10''',
                                   help='Applied this rule for calculation if condition is true. You can specify condition like basic > 1000.')
    condition_range_min = fields.Float(string='Minimum Range', help="The minimum amount, applied for this rule.")
    condition_range_max = fields.Float(string='Maximum Range', help="The maximum amount, applied for this rule.")
    amount_select = fields.Selection([
        ('percentage', 'Percentage (%)'),
        ('fix', 'Amount'),
        ('code', 'Python Code'),
    ], string='Computation Type', index=True, required=True, default='fix',
        help="The computation method for the rule amount.")
    amount_fix = fields.Float(string='Fixed Amount', digits=dp.get_precision('Payroll'))
    amount_percentage = fields.Float(string='Percentage (%)', digits=dp.get_precision('Payroll Rate'),
        help='For example, enter 50.0 to apply a percentage of 50%')
    amount_python_compute = fields.Text(string='Python Code',
                                        default='''
                    # Available variables:
                    #----------------------
                    # payslip: object containing the payslips
                    # employee: hr.employee object
                    # rules: object containing the rules code (previously computed)
                    # categories: object containing the computed salary rule categories (sum of amount of all rules belonging to that category).
                    # Note: returned value have to be set in the variable 'result'

                    result = employee.wage * 0.10''')
    select_linked = fields.Selection([
        ('fix', 'Fixed'), 
        ('struct', 'Linked To Structure'),
        ('department', 'Linked To Department'),
        ('job', 'Linked To Job')
        ], string='Type', index=True, required=True, default='fix')
    amount_percentage_base = fields.Many2many('hr.salary.rule', 'hr_salary_rule_ids', 'hr_salary_rule_id',
        'parent_rule_id', string='Linked Allowance/Deduction', )
    salary_amount_ids = fields.One2many('hr.salary.amount', 'salary_rule_id', copy=True)
    company_contribution = fields.Boolean('Company Contribution', default=False)
    register_id = fields.Many2one('hr.contribution.register', string='Contribution Register',
        help="Eventual third party involved in the salary payment of the employees.")
    absence = fields.Boolean("Linked To Absence")
    leave_type_ids = fields.Many2many('hr.leave.type', string="Leaves")
    taxable = fields.Boolean('Taxable',
        help="the portion of a person's or company's gross income that the government deems subject to taxes.")
    tax_deduct = fields.Integer("Exempted Amount")
    note = fields.Text(string='Description')
    active = fields.Boolean(default=True)
    account_id = fields.Many2one('account.account', 'Account', domain=[('deprecated', '=', False)], company_dependent=True)
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')

    @api.constrains('amount_percentage_base')
    def _check_sequence(self):
        for rec in self:
            for salary_rule_id in rec.amount_percentage_base:
                if salary_rule_id.sequence > rec.sequence:
                    raise ValidationError(
                        _('Please make salary rule %s  sequence less than %s sequence!!!!.') %
                        (salary_rule_id.name, rec.name))
                if salary_rule_id.id == rec.id:
                    raise ValidationError(
                        _('You can not select salary rule %s for salary rule %s') %
                        (salary_rule_id.name, rec.name))

    @api.constrains('sequence')
    def _check_seq_of_parent(self):
        salary_rule_ids = self.env['hr.salary.rule'].search([])
        for rec in self:
            for salary_rule_id in salary_rule_ids:
                if rec.id in salary_rule_id.amount_percentage_base.ids:
                    if rec.sequence > salary_rule_id.sequence:
                        raise ValidationError(
                            _('You can make salary rule %s  sequence more than %s sequence!!!!.') %
                            (rec.name, salary_rule_id.name))

    @api.constrains('parent_rule_id')
    def _check_parent_rule_id(self):
        if not self._check_recursion(parent='parent_rule_id'):
            raise ValidationError(_('Error! You cannot create recursive hierarchy of Salary Rules.'))

    def _rule_amount_percentage(self, contract):
        amount = 0.0
        record =[]
        if self.select_linked == 'fix':
            amount = self.amount_select == 'fix' and self.amount_fix or self.amount_percentage or 0.0
            return amount
        elif self.select_linked == 'struct':
           record = self.env['hr.salary.amount'].search([('salary_rule_id', '=', self.id),('structure_id', 'parent_of', contract.struct_id.id)])
        elif self.select_linked == 'job':
            record = self.env['hr.salary.amount'].search([('salary_rule_id', '=', self.id),('job_id', '=', contract.job_id.id)])
        elif self.select_linked == 'department':
            record = self.env['hr.salary.amount'].search([('salary_rule_id', '=', self.id),('department_id', 'child_of', contract.department_id.id)])
        amount = record and record.amount or 0.0
        return amount

    def _recursive_search_of_rules(self):
        """
        @return: returns a list of tuple (id, sequence) which are all the children of the passed rule_ids
        """
        return [(rule.id, rule.sequence) for rule in self]

        # TODO should add some checks on the type of result (should be float)

    def _compute_rule(self, localdict):

        """
        :param localdict: dictionary containing the environement in which to compute the rule
        :return: returns a tuple build as the base/amount computed, the quantity and the rate
        :rtype: (float, float, float)
        """
        self.ensure_one()

        if self.special:
            amount = 0.0
            exeption = self.env['hr.salary.exception'].search([
                '|',
                ('employee_id', '=', localdict['contract'].employee_id.id),
                ('contract_id', '=', localdict['contract'].id),
                ('exception_type', '=', 'allocation'),
                ('salary_rule_id', '=', self.id)])
            if exeption:
                for excep in exeption:
                    amount += excep.amount
            return amount, float(safe_eval(self.quantity, localdict)), 100.0
        if self.amount_select == 'fix':
            try:
                amount_fix = self._rule_amount_percentage(localdict['contract'])
                amount_fix = self._worked_days_amount(localdict, amount_fix)
                return amount_fix, float(safe_eval(self.quantity, localdict)), 100.0
            except:
                raise UserError(_('Wrong quantity defined for salary rule %s (%s).') % (self.name, self.code))

        elif self.amount_select == 'percentage':
            amount_percentage = self._rule_amount_percentage(localdict['contract'])

            try:
                fix_amount = 0.0
                amount_percentage = self._rule_amount_percentage(localdict['contract'])
                if amount_percentage:
                    for salary_rule_id in self.amount_percentage_base:
                        allow_deduct = localdict.get(salary_rule_id.code, 0.0)
                        qty = 1
                        rate = 100
                        if not allow_deduct:
                            if salary_rule_id._satisfy_condition(localdict):
                                allow_deduct, qty, rate = salary_rule_id._compute_rule(localdict)
                        if salary_rule_id.rule_type in ['allowance', 'bonus']:
                            fix_amount += allow_deduct * qty * rate / 100.0
                            if self.rule_type == 'bonus':
                                localdict[salary_rule_id.code] = allow_deduct * qty * rate / 100.0
                                localdict['categories'].dict[
                                    salary_rule_id.category_id.code] = salary_rule_id.category_id.code in localdict[
                                    'categories'].dict and localdict['categories'].dict[
                                                                           salary_rule_id.category_id.code] + localdict[
                                                                           salary_rule_id.code] or localdict[
                                                                           salary_rule_id.code]
                        elif salary_rule_id.rule_type == 'deduction':
                            fix_amount -= allow_deduct * qty * rate / 100.0

                return (float(fix_amount), float(safe_eval(self.quantity, localdict)), amount_percentage)
            except:
                raise UserError(
                    _('Wrong percentage base or quantity defined for salary rule %s (%s).') % (self.name, self.code))
        else:
            try:
                safe_eval(self.amount_python_compute, localdict, mode='exec', nocopy=True)
                localdict['result'] = self._worked_days_amount(localdict, localdict['result'])
                return float(localdict['result']), 'result_qty' in localdict and localdict[
                    'result_qty'] or 1.0, 'result_rate' in localdict and localdict['result_rate'] or 100.0
            except:
                raise UserError(_('Wrong python code defined for salary rule %s (%s).') % (self.name, self.code))


    def compute_allowed_deduct_amount(self, contract_id):
        def _sum_salary_rule_category(localdict, category, amount):
            if category.parent_id:
                localdict = _sum_salary_rule_category(localdict, category.parent_id, amount)
            localdict['categories'].dict[category.code] = category.code in localdict['categories'].dict and \
                                                          localdict['categories'].dict[category.code] + amount or amount
            return localdict

        class BrowsableObject(object):
            def __init__(self, employee_id, dict, env):
                self.employee_id = employee_id
                self.dict = dict
                self.env = env

            def __getattr__(self, attr):
                return attr in self.dict and self.dict.__getitem__(attr) or 0.0

        # we keep a dict with the result because a value can be overwritten by another rule with the same code
        result_dict = {}
        rules_dict = {}
        blacklist = []
        categories = BrowsableObject(contract_id.employee_id.id, {}, self.env)
        rules = BrowsableObject(contract_id.employee_id.id, rules_dict, self.env)
        baselocaldict = {'categories': categories, 'rules': rules}
       
        structure_ids = contract_id.get_all_structures()
        rule_ids = self.env['hr.payroll.structure'].browse(structure_ids).get_all_rules()
        rule_ids.append((self.id,self.sequence))
        sorted_rule_ids = [id for id, sequence in sorted(rule_ids, key=lambda x: x[1])  if  sequence <= self.sequence]
        sorted_rules = self.env['hr.salary.rule'].browse(sorted_rule_ids)
        localdict = dict(baselocaldict, employee=contract_id.employee_id, contract=contract_id)
        for rule in sorted_rules:
            key = rule.code
            localdict['result'] = None
            localdict['result_qty'] = 1.0
            localdict['result_rate'] = 100
            # check if the rule can be applied
            if rule._satisfy_condition(localdict) and rule.id not in blacklist:
                amount, qty, rate = rule._compute_rule(localdict)
                previous_amount = rule.code in localdict and localdict[rule.code] or 0.0
                tot_rule = amount * qty * rate / 100.0
                localdict[rule.code] = tot_rule
                rules_dict[rule.code] = rule
                localdict = _sum_salary_rule_category(localdict, rule.category_id, tot_rule - previous_amount)
                result_dict[key] = {
                   'code': rule.code,
                   'sequence': rule.sequence,
                   'amount': amount,
                   'quantity': qty,
                   'rate': rate,
                   'tot_rule':tot_rule
                }
        return result_dict.get(self.code) and result_dict[self.code]['tot_rule'] or 0.0
    

    def _worked_days_amount(self, localdict, amount):
        unpaid_days = 0
        paid_days = 0.0
        if self.env.context.get('rules'):
            context = self.env.context.get('rules')[0][0]
            salary_rule_id = self.env['hr.salary.rule'].browse(context)
        else:
            salary_rule_id = self
        if self.code not in ['GROSS', 'NET']:
            if localdict.get('worked_days', 0.0):
                fix_amount = amount
                days = localdict['worked_days'].WORK100.number_of_days
                hours = localdict['worked_days'].WORK100.number_of_hours
                if localdict['worked_days'].salary_period:
                    if salary_rule_id.category_id.frequency == 'monthly' and localdict[
                        'worked_days'].salary_period.number_of_days != days:
                        paid_days += localdict['worked_days'].salary_period.number_of_days
                    elif salary_rule_id.category_id.frequency == 'quarterly' and localdict[
                        'worked_days'].salary_period.number_of_days >= days * 3:
                        paid_days += localdict['worked_days'].salary_period.number_of_days
                        days = localdict['worked_days'].WORK100.number_of_days * 3
                    elif salary_rule_id.category_id.frequency == 'yearly' and localdict[
                        'worked_days'].salary_period.number_of_days >= 365:
                        paid_days += localdict['worked_days'].salary_period.number_of_days
                        days = 365
                    if paid_days:
                        amount = amount / days * paid_days   
                # UNPAID
                if localdict['worked_days'].unpaid:
                    for line in localdict['worked_days'].unpaid:
                          unpaid_days += line.number_of_days
                    
                if localdict['worked_days'].exclusion:
                    for line in localdict['worked_days'].exclusion:
                        if self.id in line.holiday_status_id.rule_ids.ids:
                            unpaid_days += line.number_of_days

                if self.based_employment:
                    if localdict['worked_days'].EMP:
                        unpaid_days += localdict['worked_days'].EMP.number_of_days
                        
                if self.absence:
                    if self.leave_type_ids:
                        for line in localdict['worked_days'].paid:
                            if line.holiday_status_id.id in self.leave_type_ids.ids:
                                unpaid_days += line.number_of_days
                
                if unpaid_days:
                    ded_amount = fix_amount / days * unpaid_days
                    amount -= ded_amount
                    
                if localdict['worked_days'].percentage:
                    for line in localdict['worked_days'].percentage:
                        ded_amount = fix_amount / days * line.number_of_days
                        amount -= ded_amount * line.percentage /100 
                        
                
        return amount

    def _satisfy_condition(self, localdict):

        """
        @param contract_id: id of hr.contract to be tested
        @return: returns True if the given rule match the condition for the given contract. Return False otherwise.
        """
        self.ensure_one()
        if localdict.get('payslip', False) and localdict.get('contract', False):
            exception_ids = self.env['hr.salary.exception'].search([
                '|', ('date_to', '>=', localdict['payslip'].date_from), ('date_to', '=', False),
                ('date_from', '<=', localdict['payslip'].date_to),
                ('contract_id', '=', localdict['contract'].id),
                ('salary_rule_id', '=', self.id)])
            for exception_id in exception_ids:
                if exception_id and exception_id.exception_type == 'exclude':
                    return False
            if self.special and not exception_ids:
                return False

        if self.condition_select == 'none':
            return True
        elif self.condition_select == 'range':
            try:
                result = safe_eval(self.condition_range, localdict)
                return self.condition_range_min <= result and result <= self.condition_range_max or False
            except:
                raise UserError(_('Wrong range condition defined for salary rule %s (%s).') % (self.name, self.code))
        else:  # python code
            try:
                safe_eval(self.condition_python, localdict, mode='exec', nocopy=True)
                return 'result' in localdict and localdict['result'] or False
            except:
                raise UserError(_('Wrong python condition defined for salary rule %s (%s).') % (self.name, self.code))


class SalaryAmount(models.Model):
    _name = 'hr.salary.amount'
    _description = 'Salary Amount'

    structure_id = fields.Many2one('hr.payroll.structure')
    degree_id = fields.Many2one('hr.payroll.structure')
    amount=fields.Float(string='Amount/Percentage', required=True)
    salary_rule_id=fields.Many2one('hr.salary.rule')
    department_id = fields.Many2one('hr.department', 'Department')
    job_id = fields.Many2one('hr.job', 'Job Position')
    company_id = fields.Many2one('res.company', string='Company')
    select_linked = fields.Selection(string='Type', index=True, required=False, related='salary_rule_id.select_linked', store=True)
    
    @api.onchange('structure_id')
    def _onchange_salary_amount_line(self):
        domain = {}
        positions = self.salary_rule_id.salary_amount_ids.mapped('structure_id').ids
        domain = {'structure_id': [('id', 'not in', positions), ]}
        return {'domain': domain}
        
    @api.onchange('department_id')
    def _onchange_salary_amount_line(self):
        domain = {}
        positions = self.salary_rule_id.salary_amount_ids.mapped('department_id').ids
        domain = {'department_id': [('id', 'not in', positions), ]}
        return {'domain': domain}
        
    @api.onchange('job_id')
    def _onchange_salary_amount_line(self):
        domain = {}
        positions = self.salary_rule_id.salary_amount_ids.mapped('job_id').ids
        domain = {'job_id': [('id', 'not in', positions), ]}
        return {'domain': domain}
        
