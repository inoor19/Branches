# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'HR Mission',
    'version': '1.0',
    'category': 'Human Resources/Mission',
    'sequence': 2,
    'description':
        """
        Manage Employee Mission
        """,
    'author': "NCTR",
    'website': 'http://www.nctr.sd',
    'depends': ['hr_payroll'],
    'data': [
        'security/hr_mission_security.xml',
        'security/ir.model.access.csv',
        'data/hr_mission_seq.xml',
        'views/hr_mission_view.xml',
        'views/partner_view.xml',
        'views/services.xml',
    ],
    'license': 'LGPL-3',
    'application': True,
}
