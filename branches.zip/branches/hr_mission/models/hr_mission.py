# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from odoo.addons import decimal_precision as dp
from datetime import datetime


class HrMissionCategory(models.Model):
    _name = "hr.mission.category"
    _description = 'Mission Category'

    name = fields.Char(string="Category Name", required=True)
    mission_type = fields.Selection([
        ('internal', 'Internal'),
        ('external', 'External')], string='Mission Type', default='external')
    partner_ids = fields.Many2many('res.partner', string="Destination")
    journal_id = fields.Many2one('account.journal', string='Journal', company_dependent=True, domain=[('type', '=', 'purchase')])
    max_days = fields.Integer(string='Max Days')
    allowance_id = fields.Many2one('hr.salary.rule', string="Allowance", domain="[('rule_type', '=', 'bonus')]")
    currency_id = fields.Many2one('res.currency', string="Currency", default=lambda x: x.env.company.currency_id)
    services_ids = fields.Many2many('product.product', 'category_res_service_rel', 'product_id', 'service_id', string="Services")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)
    account_id = fields.Many2one('account.account', string='Account', domain=[('deprecated', '=', False)], company_dependent=True)
    active = fields.Boolean(default=True)
    
    
class HrMission(models.Model):
    _name = "hr.mission"
    _description = 'Hr Mission'
    _inherit = ['mail.thread']
    _order = "date desc, id desc"
 
    @api.depends('employee_ids.amount','service_ids.amount')
    def _compute_totals(self):
        for mission in self:
            mission.total_amount = sum(mission.employee_ids.mapped('amount'))
            mission.mission_fees = sum(mission.employee_ids.mapped('mission_fees'))
            mission.total_service = sum(mission.service_ids.mapped('amount'))
            mission.total = mission.total_amount + mission.total_service + mission.mission_fees
 
    name = fields.Char(string="Reference")
    date = fields.Date(string="Date", copy=False, default=fields.Date.context_today, required=True)
    start_date = fields.Date(string="Start Date", required=True, tracking=True) 
    end_date = fields.Date(string="End Date", required=True, tracking=True)
    days = fields.Integer(string='Days', required=False, compute='_get_number_of_days', store=True, readonly=True)
    department_id = fields.Many2one('hr.department', string='Department', required=True)
    partner_ids = fields.Many2many('res.partner', string="Partner", required=True)
    account_analytic_id = fields.Many2one('account.analytic.account', string='Analytic Account')
    mission_categ_id = fields.Many2one('hr.mission.category', string='Mission Category', tracking=True)
    mission_objective = fields.Html(string='Mission Objective',required=True)
    notes = fields.Html(string='Note')
    total_amount = fields.Float(compute='_compute_totals', string='Total Amount', store=True, readonly=True)
    mission_fees = fields.Float(compute='_compute_totals', string='Total Mission Fees', store=True, readonly=True)
    total_service = fields.Float(compute='_compute_totals', string='Total Service', store=True, readonly=True)
    total = fields.Float(compute='_compute_totals', string='Total', store=True, readonly=True)
    employee_ids = fields.One2many('hr.mission.employee', 'mission_id', string="Mission Employees",copy=True)
    service_ids = fields.One2many('hr.mission.service', 'mission_id', string="Mission Services", copy=True)
    state = fields.Selection([
        ('draft', 'Daft'),
        ('confirm', 'To Confirm'),
        ('approve', 'To Approve'),
        ('done', 'Approved'),
        ('cancel', 'Cancel')
    ], 'Status', readonly=True, tracking=True, copy=False, default='draft')
    voucher_id = fields.Many2one('account.move', string='voucher' ,copy=False)
    company_id = fields.Many2one('res.company', string='Company', readonly=True,
        states={'draft': [('readonly', False)]}, default=lambda self: self.env.user.company_id)
    mission_type = fields.Selection(related='mission_categ_id.mission_type', string='Mission Type', readonly=True)
    currency_id = fields.Many2one('res.currency', string="Currency", tracking=True)
    active = fields.Boolean(string='Active', default=True)
    payment_state = fields.Selection(
        selection=[
            ('not_paid', 'Not Registered'),
            ('in_payment', 'In Payment'),
            ('paid', 'Paid'),
            ('reversed', 'Reversed'),
        ], string="Payment Status", compute='_compute_payment_state', store=True, readonly=True, copy=False, tracking=True)

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('hr.mission') or '/'
        return super(HrMission, self).create(vals)

    def unlink(self):
        for mission in self:
            if mission.state not in ('draft'):
                raise UserError(_('You cannot delete a record which is not draft!'))
        return super(HrMission, self).unlink()

    @api.onchange('mission_categ_id')
    def on_change_category(self):
        for mission in self:
            mission.currency_id = mission.mission_categ_id.currency_id.id
        
    @api.constrains('start_date', 'end_date')
    def _check_date_validity(self):
        """ verifies if start_date is earlier than end_date. """
        for mission in self:
            if mission.start_date and mission.end_date:
                if mission.end_date < mission.start_date:
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))

    @api.depends('voucher_id.payment_state')
    def _compute_payment_state(self):
        for mission in self:
            payment_state = 'not_paid'
            if mission.voucher_id:
               payment_state = 'in_payment'
               if mission.voucher_id.payment_state in ['paid','partial']:
                   payment_state = 'paid'
               if mission.voucher_id.payment_state in ['reversed','cancel']:
                   payment_state = 'reversed'
            mission.payment_state = payment_state
            
    def compute_lines(self):
        for mission in self:
            for line in mission.employee_ids:
                line.day_wage = 0.0
                if mission.mission_categ_id.allowance_id:
                    amount = mission.mission_categ_id.allowance_id.compute_allowed_deduct_amount(line.employee_id.contract_id)
                    line.day_wage = amount
                        
    @api.depends('start_date', 'end_date')
    def _get_number_of_days(self):
        for mission in self:
            if (mission.start_date and mission.end_date) and (mission.start_date <= mission.end_date):
                mission.days = (fields.Datetime.from_string(mission.end_date) - fields.Datetime.from_string(mission.start_date)).days +1
            else:
                mission.days = 0
                
    @api.onchange('start_date')
    def _update_line_start_date(self):
        for mission in self:
            if mission.employee_ids:
                for line in mission.employee_ids:
                    line.start_date = mission.start_date

    @api.onchange('end_date')
    def _update_line_end_date(self):
        for mission in self:
            if mission.employee_ids:
                for line in mission.employee_ids:
                    line.end_date = mission.end_date     
                    
    def action_confirm(self):
        self.write({'state': 'confirm'})

    def action_approve(self):
        for rec in self:
            for line in rec.employee_ids:
                line._create_resource_leave()
        self.write({'state': 'approve'})

    def action_to_edit(self):
        self.write({'state': 'draft'})

    def action_cancel(self):
        for rec in self:
            for line in rec.employee_ids:
                line._remove_resource_leave()
            if rec.voucher_id:
                if rec.voucher_id.state == 'posted':
                    rec.voucher_id.button_draft()
                rec.voucher_id.with_context(force_delete=True).unlink()
        self.write({'state': 'cancel'})

    def action_done(self):
        for mission in self:
            lines = []
            for emp in mission.employee_ids:
                if emp.amount > 0:
                    if not mission.mission_categ_id.allowance_id.account_id:
                            raise ValidationError(
                        _('Please Enter Accounting Journal Configration for Category %s.') % (mission.mission_categ_id.name))
                    dis_list = {mission.account_analytic_id.id}
                    distribution = dict.fromkeys(dis_list, 100)
                    line = {
		                'name': 'HR Mission/' + emp.employee_id.name,
		                'account_id': mission.mission_categ_id.allowance_id.account_id.id,
		                'quantity': 1,
		                'price_unit': emp.amount,
		                'analytic_distribution': mission.account_analytic_id and distribution or 0,
		                'tax_ids': []
		            }
                    lines.append(line)
                if emp.mission_fees > 0:
                    if not mission.mission_categ_id.account_id:
                        raise ValidationError(
                             _('Please Enter Accounting Configration for Category %s.') % (mission.mission_categ_id.name))
                    line_fees = {
		                'name': 'HR Mission Fees/' + emp.employee_id.name,
		                'account_id': mission.mission_categ_id.account_id.id,
		                'quantity': 1,
		                'price_unit': emp.mission_fees,
		                'tax_ids': []
		            }
                    lines.append(line_fees)
            if not mission.voucher_id:
                if not mission.mission_categ_id.journal_id:
                    raise ValidationError(
                        _('Please Enter Accounting Journal Configration for Category %s.') % (mission.mission_categ_id.name))
                        
                voucher_id = self.env['account.move'].sudo().create({
                    'ref': mission.name,
                    'narration': mission.mission_objective,
                    'move_type': 'in_invoice',
                    'journal_id': mission.mission_categ_id.journal_id.id,
                    'company_id': mission.company_id.id,
                    'invoice_date': mission.date,
                    'currency_id': mission.currency_id.id,
                    'source_document': self._name + ',' + str(mission.id),
                    'source_document_state': mission.state,
                    'invoice_line_ids': [(0, 0, x) for x in lines],
                })
                mission.write({'voucher_id': voucher_id.id})
            else:
                mission.voucher_id.invoice_line_ids.sudo().unlink()
                mission.voucher_id.sudo().write({'invoice_line_ids': [(0, 0, x) for x in lines]})

            mission.write({'state': 'done'})
                   
                        
class HrMissionEmployee(models.Model):
    _name = "hr.mission.employee"
    _description = 'Hr Mission Employee'

    mission_id = fields.Many2one('hr.mission', string="Mission")
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    supervisor = fields.Boolean('Supervisor')
    start_date = fields.Date('Start Date', required=True)
    end_date = fields.Date('End Date', required=True)
    day = fields.Integer(string='Days', required=False, compute='_get_number_of_days', store=True, readonly=True,)
    mission_fees = fields.Float(string='Mission Fees', required=True)
    day_wage = fields.Float(string='Days Wage')
    department_id = fields.Many2one('hr.department', string='Department', related='mission_id.department_id',store=True)
    mission_categ_id = fields.Many2one('hr.mission.category', string='Mission Category',
        related='mission_id.mission_categ_id', store=True)
    amount = fields.Float(string='Amount', compute='compute_amount', store=True)

    def _create_resource_leave(self):
        """ This method will create entry in resource calendar leave object at the time of mission validated """
        for mission in self:
            mission_type = mission.mission_id.mission_categ_id.mission_type == 'internal' and 'in_mission' or 'out_mission'

            self.env['resource.calendar.leaves'].create({
                'name': mission.mission_id.name,
                'time_type': 'other',
                'date_from': mission.start_date,
                'date_to': mission.end_date,
                'resource_id': mission.employee_id.resource_id.id,
            })
        return True

    def _remove_resource_leave(self):
        """ This methodate_tod will create entry in resource calendar leave object at the time of holidays cancel/removed """
        'model.name,id'
        return self.env['resource.calendar.leaves'].search(
            [('name', '=', self.mission_id.name)]).unlink()

    @api.depends('day', 'day_wage')
    def compute_amount(self):
        for line in self:
            line.amount = line.day * line.day_wage

    @api.constrains('start_date', 'end_date')
    def _date_check(self):
        for line in self:
            if line.start_date < line.mission_id.start_date or line.end_date > line.mission_id.end_date:
                raise ValidationError(_("The period of lines must be within the period of Mission"))

    @api.depends('start_date', 'end_date')
    def _get_number_of_days(self):
        for line in self:
            if (line.start_date and line.end_date) and (line.start_date <= line.end_date):
                line.day = (fields.Datetime.from_string(line.end_date) - fields.Datetime.from_string(line.start_date)).days+1
            else:
                line.day = 0

    @api.constrains('supervisor')
    def check_supervisor(self):
        for mission in self:
            supervisor = mission.mission_id.employee_ids.filtered(lambda s: s.supervisor == True)
            if mission.supervisor == True and len(supervisor) > 1:
                raise ValidationError(_("You Can't Choose more than one Supervisor"))

    @api.constrains('day')
    def check_max(self):
        for mission in self:
            if mission.mission_id.mission_categ_id.max_days > 0 and mission.day > mission.mission_id.mission_categ_id.max_days:
                raise ValidationError(_("You Can't Exceed Max Days in mission Category"))

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        amount = 0.0
        values = {'day_wage': 0.0}
        if self.mission_id.mission_categ_id.allowance_id:
            if self.employee_id.contract_id:
                amount = self.mission_id.mission_categ_id.allowance_id.compute_allowed_deduct_amount(self.employee_id.contract_id)
                values['day_wage'] = amount
        return {'value': values}

    @api.constrains('employee_id')
    def check_emplyee_mission(self):
        for emp in self:
            employee = self.env['hr.mission.employee'].search([
                ('start_date', '<=', emp.start_date),
                ('end_date', '>=', emp.start_date),
                ('id', '!=', emp.id),
                ('employee_id', '=', emp.employee_id.id),
                ('mission_id.state', '!=', 'cancel')])
            if employee:
                raise ValidationError(_("There is an employee on a mission at this time"))

    @api.onchange('employee_id')
    def _onchange_mission_line(self):
        if not self.mission_id.department_id:
            return {'domain': {'employee_id': [('id', 'in', [])]}}
        domain = {}
        employees = self.mission_id.employee_ids.mapped('employee_id').ids
        domain = {'employee_id': [('id', 'not in', employees), ('department_id', 'child_of', [self.mission_id.department_id.id]), ('state','=','approved')]}
        return {'domain': domain}
        
        
class HrMissionService(models.Model):
    _name = "hr.mission.service"
    _description = 'Hr Mission Services'

    mission_id = fields.Many2one('hr.mission', string="Mission")
    name = fields.Char('Name', required=True)
    product_id = fields.Many2one('product.product', string='Service',
                                 domain="[('detailed_type', '=', 'service')]")
    amount = fields.Float(string='Amount', digits=dp.get_precision('Account'))
    partner_id = fields.Many2one('res.partner', string="Partner")
    property_account_expense_id = fields.Many2one('account.account', string="Expense Account",
        related='product_id.property_account_expense_id')
    voucher_id = fields.Many2one('account.move', string='voucher' ,copy=False)

    @api.onchange('product_id')
    def product_id_change(self):
        values = {}
        if self.product_id:
            values['name'] = self.product_id.name
            values['amount'] = self.product_id.standard_price
        return {'value': values}

    @api.onchange('product_id')
    def set_service_domain(self):
        if self.mission_id.mission_categ_id:
            return {'domain': {'product_id': [('detailed_type', '=', 'service'),('id', 'not in', self.mission_id.mission_categ_id.services_ids.ids)]}}
            
            
    def action_done(self):
        for service in self:
            lines = []
            if service.amount <= 0:
                continue
            dis_list = {mission.account_analytic_id.id}
            distribution = dict.fromkeys(dis_list, 100)
            if not service.property_account_expense_id:
               raise ValidationError(
                    _('Please Enter Accounting Journal Configration for service %s.') % (service.product_id.name))
            line = {
                'name': 'HR Mission/' +service.name,
                'account_id': service.property_account_expense_id.id,
                'product_id': service.product_id and service.product_id.id or False,
                'quantity': 1,
                'price_unit': service.amount,
                'tax_ids': [],
                'analytic_distribution': service.mission_id.account_analytic_id and distribution or 0 }
            lines.append(line)

            if not service.voucher_id:
                if not service.mission_id.mission_categ_id.journal_id:
                    raise ValidationError(
                        _('Please Enter Accounting Journal Configration for Category %s.') % (mission.mission_categ_id.name))
                voucher_id = self.env['account.move'].sudo().create({
                    'partner_id': service.partner_id and service.partner_id.id or False,
                    'ref': service.mission_id.name,
                    'narration': 'HR Mission/' +service.name,
                    'move_type': 'in_invoice',
                    'journal_id': service.mission_id.mission_categ_id.journal_id.id,
                    'company_id': service.mission_id.company_id.id,
                    'invoice_date': service.mission_id.date,
                    'currency_id': service.mission_id.currency_id.id,
                    'source_document': self._name + ',' + str(service.id),
                    'invoice_line_ids': [(0, 0, x) for x in lines],
                })
                service.write({'voucher_id': voucher_id.id})
            else:
                service.voucher_id.invoice_line_ids.sudo().unlink()
                service.voucher_id.sudo().write({'invoice_line_ids': [(0, 0, x) for x in lines]})

        
