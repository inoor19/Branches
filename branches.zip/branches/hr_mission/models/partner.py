# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _


class ResPartner(models.Model):
    _inherit = "res.partner"

    destination = fields.Boolean(string='Destination')
    mission_type = fields.Selection([
        ('internal', 'Internal'),
        ('external', 'External')
    ], string='Mission Type', default='external')
