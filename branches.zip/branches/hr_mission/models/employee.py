# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _


class HrEmployee(models.Model):
    _inherit = "hr.employee"

    missions_ids = fields.One2many('hr.mission.employee', 'employee_id', string="Employee Missions")
    mission_count = fields.Integer(compute='_compute_missions_count', string='Missions')

    def _compute_missions_count(self):
        for employee in self:
            employee.mission_count = len(employee.missions_ids)

    def show_missions(self):
        missions = self.missions_ids.mapped('id')
        return {
            'name': _('Missions'),
            'view_mode': 'tree,form',
            'res_model': 'hr.mission',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', missions),],

        }


