from odoo import models, fields, api, _, exceptions, tools
import random, collections


class Assetcustudoycategory(models.Model):
    _inherit = 'account.asset.category'
    Technique_catogry = fields.Boolean()

class AccountAssetAsset(models.Model):
    _inherit='account.asset.asset'

    do_Manage = fields.Boolean(string="To be Managed",default=True)

    Serial_Number = fields.Char("Serial Number")

    Assigned_to = fields.Many2one('hr.employee', string="Assigned To")

    Description=fields.Text()


    custody_count = fields.Integer(string="Custody Count", compute="_custody_count")

   

    def _custody_count(self):
        for custody in self:
            custody_count = self.env['custoday.request'].search_count(
                [('Custoday_Name', '=', custody.id), ('state', '=', 'request')])
            custody.custody_count = custody_count

    def custody_requests_count(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Custdy Requests',
            'res_model':'custoday.request',
            'domain': [('Custoday_Name', '=', self.id)],
            'view_mode': 'tree,form',
            'target': 'current',
            }

   
    











       
