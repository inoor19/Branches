
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

class CustodayRequest(models.Model):
    _name = 'custoday.request'
    _description = 'custoday Request'
    _rec_name='Custoday_Name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    Custoday_Name = fields.Many2one('account.asset.asset',string="Custoday",required=True)

    Sequence = fields.Integer("Sequence")
  
    Department_id= fields.Many2one('hr.department',"Department",related='Employee_id.department_id',store=True)

    Employee_id = fields.Many2one('hr.employee',"Employee",required=True)

    Request_Date=fields.Date('Request Date',required=True,default=fields.Date.today())

    Receipt_Date=fields.Date('Receipt Date')

    Request_Reason=fields.Html('Request Reason')

    Request_Type=fields.Selection([('permanent','Permanent'),
        ('temporary', 'Temporary'),
        ],default='permanent',string="Request Type")

    Custoday_Type = fields.Selection([
        ('employee', 'for employee'),
        ('department','for department')],default='employee',string="Custoday Type")

    Return_Date=fields.Date('Return date')

    Return_Reason=fields.Html('Return Reason')

    Custoday_State=fields.Html("Custoday State")

    Lost_Date=fields.Date('Lost Date')

    Lost_Location=fields.Char('Lost location')

    state = fields.Selection([('draft', "Draft"),
                              ('request', "Request"),
                              ('approved', "Approved"),('received',"Received"),('returned',"Returned"),('losted',"Losted"),('cansel','Cansel')],default='draft')

    Evidence = fields.Binary(string="Evidence of Loss")


    def action_request_draft(self):
        self.write({'state':'draft'})

    def action_request_request(self):
        self.write({'state':'request'})

    def action_request_approved(self):
        self.write({'state':'approved'})

    def action_request_received(self):
        self.write({'state':'received'})

    def action_returned(self):
        self.Custoday_Name.Assigned_to = False
        self.write({'state':'returned'})

    def action_losted(self):
        self.write({'state':'losted'})

    def action_cansel(self):
        self.write({'state':'cansel'})

    def action_set_to_draft(self):
        self.write({'state':'draft'})    



    @api.onchange('Employee_id')
    def _getprevious(self):
       if self.Employee_id:
           self.Custoday_Name.Assigned_to = self.Employee_id
