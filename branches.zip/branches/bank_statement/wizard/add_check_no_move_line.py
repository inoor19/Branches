# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models


class AddCheckNo(models.TransientModel):
    _name = 'add.check.no'
    _description = 'Check No to move line'

    journal_id = fields.Many2one('account.journal', string='Journal', required=True)
    

    def add_check_number(self):
        cr = self.env.cr
        sql = 'select id from account_move_line where account_id = %s and payment_id is not null'
        cr.execute(sql,[self.journal_id.default_debit_account_id.id])
        ids = [item[0] for item in cr.fetchall()]
        lines = self.env['account.move.line'].browse(ids)
        for line in lines:
            line.check_number = line.payment_id.check_number
        sql_payment = 'select id from account_payment where journal_id = %s'
        cr.execute(sql_payment,[self.journal_id.id])
        result =  cr.fetchall()
        ids = [item[0] for item in result]
        payment_ids = self.env['account.payment'].browse(ids)
        for payment in payment_ids:
            for voucher in payment.voucher_ids:
                lines = voucher.move_id.line_ids.filtered(lambda x: x.account_id == self.journal_id.default_debit_account_id)
                for line in lines:
                    line.check_number = payment.check_number
                    line.move_id.check_number = payment.check_number
