# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models


class FirstReconcile(models.Model):
    _name = 'first.reconcile'
    _description = 'New Description'

    name = fields.Char(string='Name',required=True)
    date = fields.Date(string='Date',required=True)
    check_number = fields.Integer(string='Check No')
    amount = fields.Float(string='Amount',required=True)
    presented = fields.Boolean(string='Presented',required=True)
    active = fields.Boolean(string='Active')



class FirstRecWizard(models.TransientModel):
    _name = 'first.reconcile.wizard'
    _description = 'New Description'

    date = fields.Date(string='Date',required=True)
    started_date_move = fields.Date(string='Move Date',required=True)
    
    journal_id = fields.Many2one('account.journal', string='Journal',required=True)

    def action_go(self):
        cr = self.env.cr
        sql = 'update account_move_line set statement_line_id = null, statement_id = null, reconciled = true, account_id = %s where date < %s'
        cr.execute(sql,[self.started_date_move,str(self.journal_id.default_debit_account_id.id)])
        lines = self.env['first.reconcile'].browse(self._context.get('active_ids',False))
        if len(lines) > 0:
            # statement_id = self.env[''].create({
            #     'journal_id':self.journal_id.id,
            #     'date':self.date
            # })
            not_presented = lines.filtered(lambda line: line.presented ==False)
            presented = lines.filtered(lambda line: line.presented ==True)
            payment_not_presented = self.env['account.payment'].search([('check_number','in',[not_p.check_number for not_p in not_presented ])])
            for payment in payment_not_presented:
                if not payment.move_line_ids:
                    payment.post()

                for move_line in payment.move_line_ids.filtered(lambda x: x.account_id == self.journal_id.default_debit_account_id.id):
                    # move_line.not_presented = True
                    move_line.check_number = payment.check_number
            payment_presented = self.env['account.payment'].search([('check_number','in',[p.check_number for p in presented ])])
            for payment in payment_presented:
                if not payment.move_line_ids:
                    payment.post()

                for move_line in payment.move_line_ids.filtered(lambda x: x.account_id == self.journal_id.default_debit_account_id.id):
                    move_line.not_presented = False
                    move_line.check_number = payment.check_number
                    move_line.reconciled = True
                
                    
                

    

    
    


   
    
    
