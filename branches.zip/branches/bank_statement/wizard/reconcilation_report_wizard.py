# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models


class ReconReport(models.TransientModel):
    _name = 'reconcilation.report.wizard'
    _description = 'New Description'

    def print_report(self, data):
        b_statement = self.env['account.bank.statement'].browse(data.get('active_id',False))

        data={
            'form':data,
            'docs':b_statement,
            'model':'account.bank.statement',
            'ids': data.get('active_ids', False)
        
        }
        print(data)
        self.env.ref('bank_statement.report_reconcilation').report_action(data=data)


        

