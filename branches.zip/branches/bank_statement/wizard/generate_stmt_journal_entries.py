# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class GenerateStmtJournalEntries(models.TransientModel):

	_name = "generate.stmt.journal.entries"

	analytic_account_id = fields.Many2one('account.analytic.account',
	                                      string="Analytic account", domain=[('type', '=', 'normal')])
	account_id = fields.Many2one('account.account', string="Account", domain=[('deprecated', '=', False)])
	stmt_line_ids = fields.Many2many('account.bank.statement.line', string='Stmt Lines')
	move = fields.Selection([
            ('one', 'One move'),
            ('multi', 'Multi move'),
        ], 'Move', default='one')

	def generate_journal_entries(self):
		move_obj = self.env["account.move"]
		aml_obj = self.env["account.move.line"]
		res = []
		lines=[]
		move_line=[]
		bnk_stmt_id = self.env.context.get('active_id', False)
		if bnk_stmt_id:
			bnk_stmt = self.env['account.bank.statement'].browse(bnk_stmt_id)
			
			for line in self.stmt_line_ids:
				account=line.account_id or self.account_id or False
				if not account:
					raise ValidationError(_('There is no Account define to create move line for statment line %s.')% (line.name))
				analytic_account_id = self.analytic_account_id and self.analytic_account_id.id or False
				analytic=account.budget_account and analytic_account_id or False
				lines = [(0, 0, {
	            'name': line.name,
	            'partner_id': line.partner_id and line.partner_id.id or False,
	            'account_id': account.id,
	            'credit': line.amount > 0 and line.amount or 0.0,
	            'debit': line.amount < 0 and (-1 * line.amount) or 0.0,
	            'statement_line_id': False,
	            'analytic_account_id': analytic,
	            'date_maturity':line.date,
	            }), (0, 0, {
	            'name': line.name,
	            'partner_id': line.partner_id and line.partner_id.id or False,
	            'account_id': line.amount >= 0 \
                and line.statement_id.journal_id.default_credit_account_id.id \
                or line.statement_id.journal_id.default_debit_account_id.id,
	            'credit': line.amount < 0 and (-1 * line.amount) or 0.0,
	            'debit': line.amount > 0 and line.amount or 0.0,
	            'statement_line_id': line.id,
	            'date_maturity':line.date, 
	            })]
				if self.move == 'multi':
					move = move_obj.create({
						'journal_id': bnk_stmt.journal_id.id,
						'date': bnk_stmt.date,
						'ref': bnk_stmt.name,
						'line_ids':lines
					})
					res.append(move.id)
					move.post()
				else:
					move_line.extend(lines)
			if self.move == 'one':
				move = move_obj.create({
					'journal_id': bnk_stmt.journal_id.id,
					'date': bnk_stmt.date,
					'ref': bnk_stmt.name,
					'line_ids':move_line
				}) 
				res.append(move.id)
				move.post()
			if res:
				return {
	                'name': _('Generate Stmt Journal Entries'),
	                'type': 'ir.actions.act_window',
	                'view_type': 'form',
	                'view_mode': 'tree,form',
	                'res_model': 'account.move',
	                'domain': [('id', 'in', res)],
	            }
		return {'type': 'ir.actions.act_window_close'}

	
