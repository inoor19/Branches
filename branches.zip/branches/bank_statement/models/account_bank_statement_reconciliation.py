# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models,_
from odoo.exceptions import ValidationError,UserError
import time
from odoo.tools.misc import formatLang, format_date
from dateutil.relativedelta import relativedelta
from datetime import datetime


#----------------------------------------------------------
# Entries Inherit
#----------------------------------------------------------
class AccountBankStatement(models.Model):
    _inherit = "account.bank.statement"

    @api.model
    def _default_opening_journal_balance(self):
        #Search last bank statement and set current opening journal balance as closing journal balance of previous one
        journal_id = self._context.get('default_journal_id', False) or self._context.get('journal_id', False)
        if journal_id:
            return self._get_opening_journal_balance(journal_id)
        return 0

    def _get_opening_balance(self, journal_id):
        last_bnk_stmt = self.search([('journal_id', '=', journal_id),('id', '!=', self._origin.id),('state', '=', 'confirm')], limit=1)
        if last_bnk_stmt:
            return last_bnk_stmt.balance_end
        return 0

    @api.model
    def _default_journal(self):
        journal_type = self.env.context.get('journal_type', False)
        company_id = self.env['res.company']._company_default_get('account.bank.statement').id
        if journal_type:
            journals = self.env['account.journal'].search([('type', '=', journal_type), ('company_id', '=', company_id)])
            if journals:
                return journals[0]
        return self.env['account.journal']

    balance_Journal_end = fields.Float('Journal Ending Balance',compute="get_journal_end",readonly=True)
    balance_Journal_start = fields.Float('Journal Start Balance',readonly=False, default=_default_opening_journal_balance)
    bank_total_of_debit= fields.Monetary('Journal Start Balance',compute='_balance_end_real')
    bank_total_of_credit= fields.Monetary('Journal Start Balance',compute='_balance_end_real')
    total_of_debit= fields.Monetary('Journal Start Balance',compute='_Journal_end_balance') # اجمالي التغذيات
    total_of_credit= fields.Monetary('Journal Start Balance',compute='_Journal_end_balance')
    move_line_to_reconcile_ids = fields.One2many('account.move.line', 'statement_to_reconcile_id', string='Entry lines To Reconcile', states={'confirm': [('readonly', True)]},domain=[('not_presented', '!=', True),('statement_line_id', '=', False)])
    journal_debit_account_id=fields.Many2one('account.account', related='journal_id.default_debit_account_id',readonly=True)
    journal_credit_account_id=fields.Many2one('account.account', related='journal_id.default_credit_account_id',readonly=True)
    balance_end = fields.Monetary('Computed Balance', compute='_end_balance_compute', store=True, help='Balance as calculated based on Reconciled transaction')
    journal_id = fields.Many2one('account.journal', string='Journal', required=True, states={'confirm': [('readonly', True)]}, default=_default_journal)
    canceled_checks = fields.Monetary('Canceled checks',compute='_get_canceled_checks')
    not_presented_ids = fields.One2many('account.move.line', 'statement_to_reconcile_id', string='Not Reconciled',domain=[('not_presented', '=', True)],
                                        states={'confirm': [('readonly', True)]})
    not_presented_statement_ids = fields.One2many('account.not.presented.statement.line', 'statement_id', string='Not Presented')
    deposit = fields.Float(string='Deposit', compute='_Journal_end_balance')
    cancel_check_ids = fields.One2many('account.cancel.check', 'statement_id', string="Cancel Check")
    not_journal_ids = fields.One2many('bank.no.journal', 'statement_id', string="Not in Journal")
    balance_nobank = fields.Float("Balance No Bank",compute="compute_no_jou")


    def compute_no_jou(self):
        for rec in self:
            debit = sum([float(x.debit)
                for x in rec.not_journal_ids])
            credit = sum([float(x.credit)
                for x in rec.not_journal_ids])
            rec.balance_nobank = debit - credit

    
    

    @api.depends('not_presented_ids','balance_Journal_start','state')
    def get_journal_end(self):
        end_month = datetime.strptime(self.date,'%Y-%m-%d').date()
        begin_day = end_month.replace(day=1)
        begin_day = begin_day.strftime('%Y-%m-%d')
        print("********** not_presented**** arc not_presented**************")
        print(len(self.not_presented_ids))
        print(len(self.not_presented_statement_ids))

        # debit_rec = sum(self.move_line_ids.filtered(lambda x: x.move_id.date >= begin_day).mapped('debit'))
        # credit_rec = sum(self.move_line_ids.filtered(lambda x: x.move_id.date >= begin_day).mapped('credit'))
        # if self.state == 'open':
        #     debit_typical = sum(self.move_line_to_reconcile_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))
        #     credit_typical = sum(self.move_line_to_reconcile_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))
        # elif self.state=='confirm':
        #     debit_typical = 0
        #     credit_typical = 0
        # if self.state == 'open':
        #     credit_not_presented = sum(self.not_presented_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))
        #     debit_not_presented = sum(self.not_presented_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))
        # elif self.state=='confirm':
        #     credit_not_presented = sum(self.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))
        #     debit_not_presented = sum(self.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))


        debit_rec = sum(self.move_line_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))
        credit_rec = sum(self.move_line_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))
        
        debit_typical = sum(self.move_line_to_reconcile_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))


        credit_not_presented = sum(self.not_presented_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))
        debit_not_presented = sum(self.not_presented_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))

        credit_not_presentedar = sum(self.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))
        debit_not_presentedar = sum(self.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))


        debit_cancel_check = sum(self.cancel_check_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))
        
        credit_typical = sum(self.move_line_to_reconcile_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))




            
        debit_cancel_check = sum(self.cancel_check_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))
        
        print(">> opening>>>",self.balance_Journal_start ,">>>r de>>",debit_rec,">> to re de>>>", debit_typical ,">>cr not>>>", credit_not_presented ,">> r cr>>>", credit_rec ,">>de not>>>", debit_not_presented ,">>to re cr>>>", credit_typical ,">>ar not cr>>>",credit_not_presentedar,">>ar not de>>>>>",debit_not_presentedar)
        self.balance_Journal_end = self.balance_Journal_start +debit_rec+ debit_typical - credit_not_presented - credit_rec + debit_not_presented - credit_typical +debit_cancel_check -credit_not_presentedar + debit_not_presentedar

    @api.depends('journal_id')
    def _get_canceled_checks(self):
        canceled_checks = 0.0
        check_log=self.env['check.log']
        last_bnk_stmt = self.search([('journal_id', '=', self.journal_id.id),('id','!=',self.id)],order="date desc",limit=1)
        last_date = fields.Date.today()
        if last_bnk_stmt:
            last_date = last_bnk_stmt.date
        checks = check_log.search([('journal_id', '=', self.journal_id.id),('date_due','>=',last_date),('date_due','<=',self.date),('status','=','canceled')])
        canceled_checks=sum(checks.mapped('name.amount'))
        self.canceled_checks = canceled_checks

    def button_confirm_bank(self):
        """
        inherit to prevent create move in case of find account_id in statement line
        """
        self._balance_check()
        statements = self.filtered(lambda r: r.state == 'open')
        for statement in statements:
            moves = self.env['account.move']
            for st_line in statement.line_ids:
                # if st_line.account_id and not st_line.journal_entry_ids.ids:
                #     st_line.fast_counterpart_creation()
                if not st_line.journal_entry_ids.ids and not statement.currency_id.is_zero(st_line.amount):
                    raise UserError(_('All the account entries lines must be processed in order to close the statement.'))
                for aml in st_line.journal_entry_ids:
                    moves |= aml.move_id
            if moves:
                moves.filtered(lambda m: m.state != 'posted').post()
            statement.message_post(body=_('Statement %s confirmed, journal items were created.') % (statement.name,))
        statements.link_bank_to_partner()
        statements.write({'state': 'confirm', 'date_done': time.strftime("%Y-%m-%d %H:%M:%S")})

    def _get_opening_journal_balance(self, journal_id):
        last_bnk_stmt = self.search([('journal_id', '=', journal_id),('id', '!=', self._origin.id),('state', '=', 'confirm')], limit=1)
        if last_bnk_stmt:
            return last_bnk_stmt.balance_Journal_end
        return 0

    def button_draft(self):
        for rec in self:
            for not_prt_st in rec.not_presented_statement_ids:
                for line in not_prt_st.not_presented_move_ids:
                    line.not_presented = True
                not_prt_st.unlink()
            rec.state = 'open'

    def check_confirm_bank(self):
        if len(self.move_line_to_reconcile_ids) !=0:
            raise UserError(_("You must process all bank move lines"))
        super(AccountBankStatement,self).check_confirm_bank()
        for rec in self:
            rec._end_balance()
            check_set = list(set(rec.not_presented_ids))
            
            for check in check_set:

                self.env['account.not.presented.statement.line'].create({
                        'statement_id':self.id,
                        'date':check.date,
                        'debit':check.debit,
                        'credit':check.credit,
                        'description':check.name,
                        'check_number':check.check_number,
                        # 'not_presented_move_ids':not_prt_moves
                    })
                check.write({
                    'not_presented':False,
                    'statement_to_reconcile_id':None
                    })


                # sum_c = 0.0
                # sum_d = 0.0
                # lable = ""
                # not_prt_moves =[]
                # for not_prt in rec.not_presented_ids.filtered(lambda x: x.check_number == check):
                #     if not_prt.partner_id:
                #         lable += str(not_prt.partner_id.name) +' '
                #     else:
                #         lable += str(not_prt.name) +' '
                #     sum_d += not_prt.debit
                #     sum_c += not_prt.credit
                #     not_prt_moves.append((4,not_prt.id))
                #     not_prt.write({
                #     'not_presented':False,
                #     'statement_to_reconcile_id':None
                #     })
                # statement = self.env['account.not.presented.statement.line'].search([('check_number','=',check),('statement_id','=',self.id)])
                # if not statement:
                #     self.env['account.not.presented.statement.line'].create({
                #         'statement_id':self.id,
                #         'date':not_prt.date,
                #         'debit':sum_d,
                #         'credit':sum_c,
                #         'description':lable,
                #         'check_number':check,
                #         'not_presented_move_ids':not_prt_moves
                #     })
                # else:
                #     statement.write({
                #         'date':not_prt.date,
                #         'debit':sum_d,
                #         'credit':sum_c,
                #         'description':lable,
                #         'check_number':check,
                #         'not_presented_move_ids':not_prt_moves
                #     })
            rec.get_journal_end()

    @api.depends('move_line_to_reconcile_ids','move_line_ids', 'balance_start','line_ids')
    def _end_balance_compute(self):
        self.balance_end = self.balance_start + sum([line.debit for line in self.move_line_ids]) - sum([line.credit for line in self.move_line_ids])
        # self.balance_end = self.balance_Journal_start + (sum([line.debit for line in self.move_line_to_reconcile_ids]) - sum([line.credit for line in self.move_line_to_reconcile_ids])) + sum([line.amount for line in self.line_ids if len(line.journal_entry_ids) == 0]) - (sum([line.debit for line in self.not_presented_ids]) - sum([line.credit for line in self.not_presented_ids]))

    def _set_opening_balance(self, journal_id):
        self.balance_Journal_start = self._get_opening_journal_balance(journal_id)
        return super(AccountBankStatement, self)._set_opening_balance(journal_id)


    # @api.multi
    # def account_statement_line_refresh(self):
    #     if self.line_ids:
    #         for line in self.line_ids :
    #             if line.ref:
    #                 if not line.partner_id:
    #                     payment=self.env['account.payment']
    #                     payment_part=payment.search([('communication','=', line.ref)])
    #                     for par in payment_part:
    #                         line.partner_id=par.partner_id

    def get_to_reconcile_lines(self):

        #to reset move_line_to_reconcile_ids
        self.move_line_to_reconcile_ids.write({'statement_to_reconcile_id':False})

        domin=[]
        reconciliation_aml_accounts = [self.journal_id.default_credit_account_id.id, self.journal_id.default_debit_account_id.id]
        domin = [('reconciled', '=', False),('statement_line_id', '=', None),
         ('account_id', 'in', reconciliation_aml_accounts),
          ('date','<=',self.date),('move_id.state','=','posted'),]


        #('payment_id','<>', False),
        line_ids = self.env['account.move.line'].search(domin,order="date asc, id desc")
        line_ids.write({'statement_to_reconcile_id':self.id})


        not_jou_ids = self.env['bank.no.journal'].search([('state', '=', 'open'),('not_journal', '=', True),('journal_id', '=', self.journal_id.id)],order="id desc", limit=1)
        if not_jou_ids :
            not_jou_ids.write({'state':'closed'})

            for record in not_jou_ids:
                not_journal_ids= self.env['bank.no.journal'].create({
                            'statement_id':self.id,
                            'description':record.description,
                            'date':record.date,
                            'debit':record.debit,
                            'credit':record.credit,
                            'check_number':record.check_number,
                            'journal_id':record.journal_id.id,
                            'state':'',
                            'not_journal': False,
                            })



    @api.depends('journal_id','move_line_ids','balance_Journal_start','not_presented_ids')
    def _Journal_end_balance(self):
        default_debit_account,default_credit_account=False,False

        if self.journal_id and self.journal_id.default_debit_account_id and self.journal_id.default_credit_account_id:
            default_debit_account=self.journal_id.default_debit_account_id.id
            default_credit_account=self.journal_id.default_credit_account_id.id
        self.env.cr.execute("SELECT sum(aml.debit) as debit FROM account_move_line aml join account_move m on (aml.move_id = m.id) \
            WHERE m.state = 'posted' AND aml.account_id =%s AND aml.date <= %s" ,(default_debit_account,self.date))
        debit=self.env.cr.dictfetchall()[0]['debit'] or 0.0
        self.env.cr.execute("SELECT sum(aml.credit) as credit FROM account_move_line aml join account_move m on (aml.move_id = m.id) \
            WHERE m.state = 'posted' AND aml.account_id =%s AND aml.date <= %s" ,(default_credit_account,self.date))
        credit=self.env.cr.dictfetchall()[0]['credit'] or 0.0
        end_month = datetime.strptime(self.date,'%Y-%m-%d').date()
        begin_day = end_month.replace(day=1)
        begin_day = begin_day.strftime('%Y-%m-%d')
        self.deposit = sum(self.cancel_check_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))+sum(self.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))+sum(self.not_presented_ids.filtered(lambda x: x.date >= begin_day).mapped('debit')) + sum(self.move_line_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))
        self.total_of_debit = sum(self.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))+sum(self.not_presented_ids.mapped('debit'))+sum(self.cancel_check_ids.filtered(lambda x: x.date >= begin_day).mapped('debit')) + sum(self.move_line_ids.filtered(lambda x: x.date >= begin_day).mapped('debit'))+ self.balance_Journal_start
        self.total_of_credit = sum(self.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))+sum(self.not_presented_ids.filtered(lambda x: x.date >= begin_day).mapped('credit')) + sum(self.move_line_ids.filtered(lambda x: x.date >= begin_day).mapped('credit'))


    @api.depends('line_ids.journal_entry_ids','balance_Journal_end',)
    def _balance_end_real(self):
        lists = []
        params = {'account_id': self.journal_id.default_debit_account_id.id,}
        sql_query="SELECT aml.balance ,aml.id FROM account_move_line aml WHERE aml.reconciled = false AND aml.account_id =%(account_id)s"
        self.env.cr.execute(sql_query, params)
        results = self.env.cr.dictfetchall()
        for line in results:
            if line['balance'] > 0:
                self.bank_total_of_debit+=line['balance']
            else:
                self.bank_total_of_credit+=line['balance']
        self.bank_total_of_credit=abs(self.bank_total_of_credit)

    @api.depends('line_ids', 'balance_start', 'line_ids.amount',"line_ids.journal_entry_ids", 'balance_end_real')
    def _end_balance(self):
        self.total_entry_encoding = sum([line.amount for line in self.line_ids])
        self.difference = round(self.balance_end_real,2) - round(self.balance_end,2) + round(self.balance_nobank,2)
        
        # self.difference = self.balance_end_real - self.balance_end

    def _balance_check(self):
        for stmt in self:
            stmt.difference= round(stmt.balance_end_real,2) - round(stmt.balance_end,2)
            if not stmt.currency_id.is_zero(stmt.difference):
                if stmt.journal_type == 'cash':
                    if stmt.difference < 0.0:
                        account = stmt.journal_id.loss_account_id
                        name = _('Loss')
                    else:
                        # statement.difference > 0.0
                        account = stmt.journal_id.profit_account_id
                        name = _('Profit')
                    if not account:
                        raise UserError(_('There is no account defined on the journal %s for %s involved in a cash difference.') % (stmt.journal_id.name, name))

                    values = {
                        'statement_id': stmt.id,
                        'account_id': account.id,
                        'amount': stmt.difference,
                        'name': _("Cash difference observed during the counting (%s)") % name,
                    }
                    self.env['account.bank.statement.line'].create(values)
                else:
                    balance_end_real = formatLang(self.env, stmt.balance_end_real, currency_obj=stmt.currency_id)
                    balance_end = formatLang(self.env, stmt.balance_end, currency_obj=stmt.currency_id)
                    raise UserError(_('The ending balance is incorrect !\nThe expected balance (%s) is different from the computed one. (%s)')
                        % (balance_end_real, balance_end))
        return True


class AccountBankStatementLine(models.Model):
    _inherit = "account.bank.statement.line"

    debit = fields.Monetary(default=0.0, currency_field='journal_currency_id')
    credit = fields.Monetary(default=0.0, currency_field='journal_currency_id')

    @api.onchange('debit','credit')
    def onchange_amount(self):
        self.amount = self.credit - self.debit

    def button_cancel_reconciliation(self):
        aml_to_unbind = self.env['account.move.line']
        aml_to_cancel = self.env['account.move.line']
        payment_to_unreconcile = self.env['account.payment']
        payment_to_cancel = self.env['account.payment']
        for st_line in self:
            aml_to_unbind |= st_line.journal_entry_ids
            for line in st_line.journal_entry_ids:
                payment_to_unreconcile |= line.payment_id
                if st_line.move_name and line.payment_id.payment_reference == st_line.move_name:
                    #there can be several moves linked to a statement line but maximum one created by the line itself
                    aml_to_cancel |= line
                    payment_to_cancel |= line.payment_id
        aml_to_unbind = aml_to_unbind - aml_to_cancel

        if aml_to_unbind:
            aml_to_unbind.write({'statement_line_id': False})

        payment_to_unreconcile = payment_to_unreconcile - payment_to_cancel
        if payment_to_unreconcile:
            payment_to_unreconcile.unreconcile()

        if aml_to_cancel:
            aml_to_cancel.remove_move_reconcile()
            moves_to_cancel = aml_to_cancel.mapped('move_id')
            moves_to_cancel.button_cancel()
            moves_to_cancel.unlink()
        if payment_to_cancel:
            payment_to_cancel.unlink()

    @api.model
    def create(self, vals):
        #statement_id = self.env['account.bank.statement'].browse(vals.get('statement_id',False))
        #vals.update({
         #   'name': statement_id.name or vals.get('sequence','/')
        #})
        
        # if vals.get('name',False):
        #     accounts = self.env['account.account'].search([('liquidity','=',True)])
        #     for account in accounts:
        #         if account.bank_acc_number:
        #             if account.bank_acc_number in vals['name']:
        #                 vals['account_id']=account.id
        #                 break
        return super(AccountBankStatementLine, self).create(vals)


    def unlink(self):
        for line in self:
            if line.journal_entry_ids.ids:
                line.button_cancel_reconciliation()
        return super(AccountBankStatementLine, self).unlink()

class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    statement_to_reconcile_id = fields.Many2one('account.bank.statement', index=True, string='Bank statement line To be reconciled with this entry', copy=False, readonly=True)
    not_presented = fields.Boolean('Not Presented')


    def do_not_presented(self):
        self.not_presented = True
        self.statement_to_reconcile_id.get_journal_end()
        self.statement_to_reconcile_id._end_balance_compute()

    def do_roll_back(self):
        self.not_presented = False
        if len(self.statement_line_id.journal_entry_ids) == 1:
            self.statement_line_id.unlink()

        else:
            self.statement_line_id = None
        self.statement_to_reconcile_id.get_journal_end()
        self.statement_to_reconcile_id._end_balance_compute()

    def cancel_check(self):
        for line in self:
            line.reconciled = True
            line.statement_id = None
            
            if line.debit > 0.0:
                if len(self.env['account.cancel.check'].search([('check_number','=',line.check_number)])) == 0:
                    self.env['account.cancel.check'].create({
                        'statement_id':line.statement_to_reconcile_id.id,
                        'date':line.date,
                        'debit':line.debit,
                        'credit':line.credit,
                        'description':line.name,
                        'check_number':line.check_number,
                    })
                else:
                    for cancel in self.env['account.cancel.check'].search(['check_number','=',line.check_number]):
                        cancel.statement_id = line.statement_to_reconcile_id
            line.statement_to_reconcile_id = None

    def do_reconcile_lines(self):
        for line in self:
            flag=False
            if line.not_presented:
                line.not_presented = False
                

                line.statement_to_reconcile_id.balance_Journal_end += (abs(line.debit)-abs(line.credit))

            if line.statement_to_reconcile_id.line_ids:
                for stm_line in line.statement_to_reconcile_id.line_ids:
                    if (stm_line.amount < 0 and abs(stm_line.amount) == line.debit) and line.ref == stm_line.ref:
                        if stm_line.partner_id:
                            if stm_line.partner_id == line.partner_id:
                                flag=True
                                line.write({'statement_id':line.statement_to_reconcile_id.id})
                                line.write({'statement_line_id':stm_line.id})
                        else:
                            flag=True
                            line.write({'statement_id':line.statement_to_reconcile_id.id})
                            line.write({'statement_line_id':stm_line.id})
                    elif (stm_line.amount > 0 and stm_line.amount == line.credit) and line.ref == stm_line.ref:
                        if stm_line.partner_id:
                            if stm_line.partner_id == line.partner_id:
                                flag=True
                                line.write({'statement_id':line.statement_to_reconcile_id.id})
                                line.write({'statement_line_id':stm_line.id})
                        else:
                            flag=True
                            line.write({'statement_id':line.statement_to_reconcile_id.id})
                            line.write({'statement_line_id':stm_line.id})
                if not flag:
                    line.write({'statement_id':line.statement_to_reconcile_id.id})
                    new_stm_line=self.env['account.bank.statement.line'].create(
                                                                    {'statement_id':line.statement_to_reconcile_id.id,
                                                                    'name':'/',
                                                                    'amount':line.debit and abs(line.debit) or abs(line.credit),
                                                                    'date':line.date,'ref':line.ref,'name':line.name,'partner_id':line.partner_id and line.partner_id.id or False,
                                                                    })
                    line.write({'statement_line_id':new_stm_line.id})
            else:
                line.write({'statement_id':line.statement_to_reconcile_id.id})
                new_stm_line=self.env['account.bank.statement.line'].create({'statement_id':line.statement_to_reconcile_id.id,
                                                                'amount':line.debit and abs(line.debit) or line.credit * -1,
                                                                'name':'/',
                                                                'date':line.date,'ref':line.ref,'name':line.name,'partner_id':line.partner_id and line.partner_id.id or False,
                                                                })
                line.write({'statement_line_id':new_stm_line.id})




class AccountStatementNotPresented(models.Model):
    _name = "account.not.presented.statement.line"

    statement_id = fields.Many2one('account.bank.statement', string='Bank Statement')

    description = fields.Char(string='Description',translated=True,required=True)
    date = fields.Date(string='Date', translated=True,required=True)
    debit = fields.Float(string='Debit', translated=True,required=True)
    credit = fields.Float(string='Credit', translated=True,required=True)
    check_number = fields.Integer(string='check_number', translated=True,required=True)
    not_presented_move_ids = fields.Many2many('account.move.line', string='Not presented',required=True)

class AccountStatementCancel_check(models.Model):
    _name = "account.cancel.check"

    statement_id = fields.Many2one('account.bank.statement', string='Bank Statement')

    description = fields.Char(string='Description',translated=True,required=True)
    date = fields.Date(string='Date', translated=True,required=True)
    debit = fields.Float(string='Debit', translated=True,required=True)
    credit = fields.Float(string='Credit', translated=True,required=True)
    check_number = fields.Integer(string='check_number', translated=True,required=True)



class AccountBankNoJournal(models.Model):
    _name = "bank.no.journal"

    statement_id = fields.Many2one('account.bank.statement', string='Bank Statement')

    description = fields.Char(string='Description',translated=True,required=True)
    date = fields.Date(string='Date', translated=True,required=True,default=datetime.now())
    debit = fields.Float(string='Debit', translated=True,required=True)
    credit = fields.Float(string='Credit', translated=True,required=True)
    check_number = fields.Integer(string='Check Number')
    journal_id = fields.Many2one('account.journal', string='Journal')

    state = fields.Selection([('open', 'Open'), ('closed', 'Closed')])

    not_journal = fields.Boolean('Not in Journal')

    def do_not_journal(self):
        for rec in self:
            rec.not_journal = True
            rec.state = 'open'
            if rec.debit > 0 and rec.credit == 0:
                rec.statement_id.balance_end = rec.statement_id.balance_end + rec.debit
            elif rec.credit > 0 and rec.debit == 0:
                rec.statement_id.balance_end = rec.statement_id.balance_end - rec.credit


    def close_not_journal(self):
        for rec in self:
            rec.state = 'closed'
            # rec.not_journal = 


    def back_not_journal(self):
        for rec in self:
            rec.not_journal = False
            rec.state = ''
            if rec.debit > 0 and rec.credit == 0:
                rec.statement_id.balance_end = rec.statement_id.balance_end - rec.debit
            elif rec.credit > 0 and rec.debit == 0:
                rec.statement_id.balance_end = rec.statement_id.balance_end + rec.credit

    
    
    
    
    
    

