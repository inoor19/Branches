# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    "name" : "Account Bank Statement Reconciliation",
    "author" : "NCTR",
    "category": "Accounting",
    "description": """
   Bank Statement Reconciliations
    """,
    "website": "http://www.nctr.sd",
    "depends" : ['account_custom','account_cancel','account_check_printing_custom'],
    "data": [
        'security/ir.model.access.csv',
        'views/account_bank_statement_reconciliation.xml',
        'report/headers_templates.xml',
        'report/account_bank_report.xml',
        'wizard/generate_stmt_journal_entries.xml',
        'wizard/add_check_no_move_line.xml',
        'wizard/prepair_first_recon.xml',
        'wizard/reconcilation_report_wizard.xml',

    ],
    "installable": True,
}
