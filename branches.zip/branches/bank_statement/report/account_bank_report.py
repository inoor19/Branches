# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models
from datetime import datetime


class ModuleName(models.Model):
    _name = 'report.bank_statement.account_bank_report'
   
    @api.model
    def get_report_values(self, docids, data=None):

        self.model = 'account.bank.statement'
        docs = self.env[self.model].browse(docids)
        data ={}
        doc = docs[0]
        end_month = datetime.strptime(docs.date,'%Y-%m-%d').date()
        begin_day = end_month.replace(day=1)
        begin_day = begin_day.strftime('%Y-%m-%d')
        expenses =[]
        deposits = []
        for l in doc.not_presented_statement_ids.filtered(lambda x: x.date >= begin_day):
            if l.credit >0.0:
                expenses.append({
                    'date': l.date,
                    'check_number':l.check_number,
                    'dec':  l.description,
                    'credit': l.credit,
                })
            else:
                deposits.append({
                    'date': l.date,
                    'check_number':l.check_number,
                    'dec': l.description,
                    'debit': l.debit,
                })
        for l in doc.not_presented_ids.filtered(lambda x: x.date >= begin_day):
            if l.credit >0.0:
                expenses.append({
                    'date': l.date,
                    'check_number':l.check_number,
                    'dec': l.partner_id.name if l.partner_id else l.name,
                    'credit': l.credit,
                })
            else:
                deposits.append({
                    'date': l.date,
                    'check_number':l.check_number,
                    'dec': l.name,
                    'debit': l.debit,
                })
        for l in doc.move_line_ids.filtered(lambda x: x.date >= begin_day):
            if l.credit >0.0:
                expenses.append({
                    'date': l.date,
                    'check_number':l.check_number,
                    'dec': l.partner_id.name if l.partner_id else l.name,
                    'credit': l.credit,
                })
            else:
                deposits.append({
                    'date': l.date,
                    'check_number':l.check_number,
                    'dec': l.name,
                    'debit': l.debit,
                })
        for l in doc.cancel_check_ids.filtered(lambda x: x.date >= begin_day):
            if l.debit>0.0:
                deposits.append({
                    'date': l.date,
                    'check_number':l.check_number,
                    'dec': l.description,
                    'debit': l.debit,
                })
        data.update({
            'expenses':sorted(expenses, key=lambda x: x['check_number']),
            'deposits':sorted(deposits, key=lambda x: x['check_number'])
        })

        return {
            'doc_ids': docids,
            'doc_model': self.model,
            'data':data,
            'docs': docs,
            'company':self.env['res.users'].browse(self._context.get('uid')).company_id
            
        }
