# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from datetime import date, datetime, timedelta
from odoo.exceptions import UserError, ValidationError
from dateutil import relativedelta


class ViolationClasification(models.Model):
    _name = "hr.violation.clasification"
    _description = "Violations Clasification"

    name = fields.Char(string='Violation Clasification', required=True, copy=False)
    code = fields.Char(string='Code')

    _sql_constraints = [
       ('code_uniq', 'unique (code)', 'The code of the Violation clasification must be unique !'),
       ('name_uniqe', 'unique (name)', 'The name of the Violation clasification must be unique !'),
    ]

class Violation(models.Model):
    _name = "hr.violation"
    _description = "Violations"

    name = fields.Char(string='Violation Name', copy=False, required=True)
    violation_clasification_id = fields.Many2one('hr.violation.clasification', string='Violation Clasification', required=True, ondelete='restrict')
    active = fields.Boolean(default=True)
    violation_punishment_ids = fields.One2many('hr.violation.punishment', 'violation_id')

    _sql_constraints = [
       ('name_uniqe', 'unique (name)', 'The name of the Violation clasification must be unique !'),
    ]

class ViolationPunishment(models.Model):
    _name = "hr.violation.punishment"
    _description = "Violation Punishments"
    _order = "sequence"
    _rec_name = "sequence"

    violation_id = fields.Many2one('hr.violation')
    sequence = fields.Integer('Sequence',required=True)
    punishment_ids = fields.Many2many('hr.punishment')
    
    @api.constrains('sequence','violation_id')
    def _check_sequence(self):
        for rec in self :
            if self.env["hr.violation.punishment"].search([('sequence','=',rec.sequence),('id','!=',rec.id),('violation_id','=',rec.violation_id.id)]) :
                raise UserError('You Can Not Add The Same Sequence Moe Than Once.')


