# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from contextlib import nullcontext
from odoo import api, fields, models, _
from datetime import date, datetime, timedelta
from odoo.exceptions import UserError, ValidationError
from dateutil import relativedelta


class EmployeeViolation(models.Model):
    _name = "hr.employee.violation"
    _description = "Employee Violations"
    _inherit = ['mail.thread']
    _rec_name = "employee_id"
    _order = "violation_date Desc"

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, domain=[('state', '=', 'approved')])
    violation_id = fields.Many2one('hr.violation', string="Violation", required=True,ondelete='restrict')
    violation_date = fields.Date('Violation Date', required=True)
    violation_descr = fields.Html(string='Violation Description')
    decision_descr = fields.Html(string="Decision Description")
    decision_date = fields.Date(string='Decision Date')
    deduction_method = fields.Selection([
        ('salary', 'Salary'), 
        ('out_salary', 'Out Salary')],
        default='salary', string="Deduction Method", required=True,)
    penalty_amount = fields.Float(compute='_compute_penalty_amount',string="Penalty Amount")
    punishment_ids = fields.Many2many('hr.punishment', 'violation_punishment_rel',  
       string='Punishments')
    employee_ids = fields.Many2many('hr.employee',string='Employees',domain=[('state', '=', 'approved')])
    exception_id = fields.Many2one('hr.salary.exception', string="Expectation Ref.", ondelete='restrict')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirm', 'Waiting for Committee Decision'),
        ('innocence', 'Innocence'),
        ('conviction', 'In Penalty'),
        ('close', 'Close'),
        ('implement', 'Implement Punishment')
    ], string='Status', readonly=True, tracking=True, copy=False, default='draft')
    violation_punishment_id = fields.Many2one('hr.violation.punishment',string='Time')
    employee_company_id = fields.Many2one(related='employee_id.company_id', readonly=True, store=True)
    payment_out_salary = fields.Many2one('account.move', string='Journal Entry', readonly=True)






    @api.depends('punishment_ids')
    def _compute_penalty_amount(self):
        penalty_amount = 0.0
        for rec in self:
            if rec.employee_id.contract_id:
                for pun in rec.punishment_ids:
                    if pun.type == 'penalty':
                        if pun.penalty_type == 'fixed':
                            penalty_amount += pun.amount
                        else:
                            amount = pun.allow_deduct.compute_allowed_deduct_amount(rec.employee_id.contract_id)
                            if pun.penalty_amount_type == 'percent':
                                penalty_amount += amount * pun.percentage / 100
                            else:
                                penalty_amount += (amount / 30) * pun.days

            rec.penalty_amount = penalty_amount





    @api.onchange('employee_id','violation_id','violation_date')
    def onchange_punishment(self):

        self.punishment_ids=False
        if self.employee_id and self.violation_id and self.violation_date:
            employee_violation_ids=self.search([
                ('employee_id','=',self.employee_id.id),
                ('violation_id','=',self.violation_id.id),
                ('violation_date','<=',self.violation_date),
                ('state','!=','innocence'),
                ('id','!=',self._origin.id)
            ])

            employees_violations = self.env["hr.violation.punishment"].search([('violation_id','=',self.violation_id.id),
                                                    ])
            max_sequence=0
            tmp = []
            for rec in employees_violations :
                tmp.append(rec.sequence)
            max_sequence = max(tmp)
            max_employee_seq=0
            for rec in employee_violation_ids :
                if max_employee_seq < rec.violation_punishment_id.sequence :
                    max_employee_seq = rec.violation_punishment_id.sequence
            if max_employee_seq < max_sequence :
                violation_punishment = self.env["hr.violation.punishment"].search([('violation_id','=',self.violation_id.id),
                                                        ("sequence","=",max_employee_seq + 1)
                                                        ])
                print (violation_punishment, "zzzzzzzzzzz")
            else :
                violation_punishment = self.env["hr.violation.punishment"].search([('violation_id','=',self.violation_id.id),
                                                        ("sequence","=",max_sequence)
                                                        ])
            self.violation_punishment_id = violation_punishment.id
            self.punishment_ids = violation_punishment.punishment_ids


    @api.constrains('employee_violation_id')
    def _check_punishment_time(self):
        for rec in self:
            employee_violation_ids=self.search([
                ('employee_id','=',rec.employee_id.id),
                ('violation_id','=',rec.violation_id.id),
                ('violation_date','<=',rec.violation_date)
            ])
            if int(rec.violation_punishment_id.sequence) > len(employee_violation_ids):
                raise UserError(_('Times an advanced system violation.'))

    # @api.constrains('violation_date', 'decision_date')
    # def _check_date_validity(self):
    #     for rec in self:
    #             if rec.decision_date < rec.violation_date :
    #                 raise ValidationError(_('decision_date cannot be earlier than violation_date'))

    @api.constrains('violation_date')
    def _compviolationdate(self):
        if self.violation_date > fields.Datetime.now().date():
            raise ValidationError('violation date cannot be after this date')
    def unlink(self):
        for punishment in self:
            if punishment.state != 'draft':
                raise UserError(_('Cannot delete record(s) which are not in draft state.'))
        return super(EmployeeViolation, self).unlink()

    def action_draft(self):
        self.write({'state': 'draft'})

    def action_confirm(self):
        self.write({'state': 'confirm'})

    def action_conviction(self):
        self.write({'state': 'conviction'})
        
    def action_innocence(self):
        self.write({'state': 'innocence'})
        
    def action_close(self):
        self.write({'state': 'close'})
        
    def action_rollback(self):
        for rec in self:
            if rec.exception_id:
                 exception = rec.exception_id
                 rec.exception_id = False
                 exception.unlink()
        self.write({'state': 'close'})

    def action_implement(self):
        for punishment in self.punishment_ids:
            if self.penalty_amount > 0.0:
                if punishment.type == 'penalty' and punishment.deduct_id:
                    if self.deduction_method == 'salary' :
                        exception_id = self.env['hr.salary.exception'].create({
                                'employee_id': self.employee_id.id,
                                'contract_id':self.employee_id.contract_id.id,
                                'exception_type': 'allocation',
                                'salary_rule_id': punishment.deduct_id.id,
                                'date_from':self.decision_date,
                                'date_to':fields.Date.from_string(self.decision_date) + relativedelta.relativedelta(months=+1),
                                'amount':self.penalty_amount,
                            })
                        self.write({'exception_id': exception_id})
                    elif self.deduction_method == 'out_salary' :
                            payment_out_salary = self.env['account.move'].create({
                                    'partner_id': self.employee_id.address_home_id.id,
                                    'invoice_date':self.decision_date,
                                    'move_type': 'out_invoice',
                                    'invoice_date_due':fields.Date.from_string(self.decision_date) + relativedelta.relativedelta(months=+1),
                                    'invoice_line_ids': [(0, 0, {
                                        'price_unit':self.penalty_amount,
                                        'account_id': punishment.deduct_id.id or False,
                                        'quantity': 1,
                                        'tax_ids': []})],
                                })
                            print("payment_out_salary:",self.employee_id.id)
                            self.write({'payment_out_salary': payment_out_salary})

        self.write({'state': 'implement'})


    def action_pay(self):
        if self.admission_fees_move:
            raise ValidationError('The payment is already registerd you can edite it from the journal entry')
        else:
            debit_vals = {
                'name' : self.student_id,
                'debit' : abs(self.admission_fees),
                'credit': 0.0,
                'account_id': self.account_receivable_id.id,
            }
            credit_vals = {
                'name': self.student_id,
                'credit': abs(self.admission_fees),
                'debit': 0.0,
                'account_id': self.account_payable_id.id,
            }
            vals = {
                'journal_id':self.journal_id.id,
                'state': 'draft',
                'line_ids': [(0,0, debit_vals), (0,0, credit_vals)]
            }

            move = self.env['account.move'].create(vals)
            self.admission_fees_move = move.id


    # def action_implement(self):
    #     for punishment in self.punishment_ids:
    #         if self.penalty_amount > 0.0:
    #             if punishment.type == 'penalty' and punishment.deduct_id:
    #                 exception_id = self.env['hr.salary.exception'].create({
    #                         'employee_id': self.employee_id.id,
    #                         'contract_id':self.employee_id.contract_id.id,
    #                         'exception_type': 'allocation',
    #                         'salary_rule_id': punishment.deduct_id.id,
    #                         'date_from':self.decision_date,
    #                         'date_to':fields.Date.from_string(self.decision_date) + relativedelta.relativedelta(months=+1),
    #                         'amount':self.penalty_amount,
    #                     })
    #                 self.write({'exception_id': exception_id})
    #     self.write({'state': 'implement'})
