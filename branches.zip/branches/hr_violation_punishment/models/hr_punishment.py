# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from datetime import date, datetime, timedelta
from odoo.exceptions import UserError, ValidationError
from dateutil import relativedelta


class Punishment(models.Model):
    _name = "hr.punishment"
    _description = "Punishments"

    name = fields.Char(string='Name', required=True, copy=False)
    type = fields.Selection([
        ('warning','Warning'),
        ('penalty','Penalty'),
        ('dismiss','Dismiss'),
        ('deprivation','Deprivation')
        ], string='Punishment Type')
    reward = fields.Selection([
        ('with_reward','With Reward'),
        ('without_reward','Without Reward')
        ], string='Reward')
    dismiss_classification = fields.Many2one('hr.departure.reason', string='Dismiss Classification',ondelete='restrict')
    active = fields.Boolean(default=True)
    penalty_type = fields.Selection([
        ('fixed','Fixed Amount'),
        ('salary','Based on Salary')
        ], required=False, string='Penalty Type')
    penalty_amount_type = fields.Selection( string="Penalty Amount Computation", required=False,
        selection=[('days', 'Days'), ('percent', 'Percentage')], default='days')
    amount = fields.Float(string='Amount')
    days = fields.Integer(string='Days')
    percentage = fields.Float(string='Percentage')
    allow_deduct = fields.Many2one('hr.salary.rule', string='Allowance', domain=[('rule_type','=','allowance')],ondelete='restrict')  
    deduct_id = fields.Many2one('hr.salary.rule', string='Deduction', domain=[('rule_type','=','deduction')],ondelete='restrict')

    _sql_constraints = [
       ('name_uniqe', 'unique (name)', 'The name of the punishment must be unique !'),
    ] 

