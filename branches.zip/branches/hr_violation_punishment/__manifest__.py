# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'Violation & Punishment',
    'version': '1.0',
    'author': 'NCTR',
    'category': 'Human Resources',
    'website': 'http://www.nctr.sd',
    'summary': 'Employee Violation and Punishment',
    'description': "Employee Violation & Punishment",
    'depends': ['hr_payroll',
                'account',
                                ],
    'data': [
            'security/hr_violation_punishment_security.xml',
            'security/ir.model.access.csv',
            'views/menuitem.xml',
            'views/hr_punishment_view.xml',
            'views/hr_violation_view.xml',
            'views/hr_employee_violation_view.xml',
            'views/punishment_config.xml',
            'report/emp_violations_punishments_temp.xml',
            'report/report_menu.xml',
        ],
    'demo': [],
    
    'application': True,
    'license': 'LGPL-3',
}
