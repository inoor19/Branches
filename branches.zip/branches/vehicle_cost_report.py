from odoo import fields, models, api
from datetime import datetime, date
import pdb


class VehicleCost(models.TransientModel):
    _name = 'vehicle.cost.report.wizard'
    _description = 'Vehicle Cost Report Wizard'

    type = fields.Selection(string='Type', selection=[(
        'sumation', 'Sumation'), ('details', 'Details')], default="sumation", translate=True)
    date_from = fields.Date(string='From', required=True)
    date_to = fields.Date(string='To', required=True)
    vehicle_ids = fields.Many2many(
        comodel_name='fleet.vehicle', string='Vehicles')
    service_ids = fields.Many2many(
        comodel_name='fleet.service.type', string='Services')
    vehicle_id = fields.Many2one(
        comodel_name='fleet.vehicle', string='Vehicle')

    @api.model
    def default_get(self, fields):
        res = super(VehicleCost, self).default_get(fields)
        date_from = date.today().replace(month=1, day=1)
        date_to = date.today().replace(month=12, day=31)
        res.update({
            'date_from': date_from,
            'date_to': date_to
        })
        return res

    def print_report(self):
        final = {}
        data = {}

        if self.type == 'sumation':

            vehicles = None
            services = None
            if not self.vehicle_ids:
                vehicles = self.env['fleet.vehicle'].search([])
            else:
                vehicles = self.vehicle_ids
            if not self.service_ids:
                services = self.env['fleet.service.type'].search([])
            else:
                services = self.service_ids
            sql = " select id, vehicle_id, cost_subtype_id, amount from fleet_vehicle_cost where date between '"+self.date_from+"' and '" +\
                self.date_to + "' and ((parent_id is not null and cost_type ='services') or (parent_id is null and cost_type ='fuel')) and state = 'open' and amount !=0.0 and vehicle_id in " +\
                str(tuple([x.id for x in vehicles])) + " and cost_subtype_id in  " + \
                str(tuple([x.id for x in services])) + " order by date asc"
            self.env.cr.execute(sql)
            result = self.env.cr.dictfetchall()

            for res in result:
                vehicle = self.env['fleet.vehicle'].browse(res['vehicle_id'])
                v_key = vehicle.model_id.name+'/'+vehicle.license_plate
                service = self.env['fleet.service.type'].browse(
                    res['cost_subtype_id']).name
                # print('adsaskasflasfaslfaskflsafl', final)
                # pdb.set_trace()

                if final.get(v_key, False):

                    if final[v_key].get(service, False):
                        final[v_key][service] += res.get('amount', 0.0)
                    else:
                        final[v_key][service] = res.get('amount', 0.0)

                else:
                    final.update({
                        v_key: {
                            service: res.get('amount', 0.0)
                        }
                    })
                # print('wwww', final)

            data.update({
                'docs': final
            })
            return self.env.ref('sehc_service.report_vehicle_cost_summary').report_action(
                self, data=data)
        else:
            services = None
            if not self.service_ids:
                services = self.env['fleet.service.type'].search([])
            else:
                services = self.service_ids
            sql = "select id, date, cost_subtype_id, description, amount from fleet_vehicle_cost where date between '"+self.date_from+"' and '" +\
                self.date_to + "' and ((parent_id is not null and cost_type ='services') or (parent_id is null and cost_type ='fuel')) and  state = 'open' and vehicle_id = "+str(self.vehicle_id.id)+"  and amount !=0.0 and cost_subtype_id in " +\
                str(tuple([x.id for x in services]))+" order by date asc"
            self.env.cr.execute(sql)
            result = self.env.cr.dictfetchall()
            for res in result:
                cost_subtype = self.env['fleet.service.type'].browse(
                    res['cost_subtype_id'])
                ref = '/'
                if cost_subtype.category == 'maintenance':
                    ref = self.env['fleet.vehicle.cost'].browse(
                        res['id']).request_id.name
                elif cost_subtype.category == 'maintenance':
                    ref = self.env['fleet.vehicle.cost'].browse(
                        res['id']).fuel_ticket_id.ticket_no
                if final.get(res['cost_subtype_id'], False):
                    final[res['cost_subtype_id']].append(
                        [res['date'], ref, res['description'], res['amount']])
                else:
                    final.update({
                        res['cost_subtype_id']: [
                            [res['date'], ref, res['description'], res['amount']]]
                    }
                    )
            data.update({
                'docs': final,
                'vehicle': self.vehicle_id.model_id.name + '/'+self.vehicle_id.license_plate
            })
            return self.env.ref('sehc_service.report_vehicle_cost_details').report_action(
                self, config=False, data=data)
