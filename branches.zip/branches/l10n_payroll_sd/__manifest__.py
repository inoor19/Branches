# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


{
    'name': 'Sudan Payroll',
    'category': 'Human Resources',
    'version': '16.0.1.0.0',
    'author': 'NCTR',
    'company': 'NCTR',
    'website': 'http://www.nctr.sd',
    'summary': 'Sudan salary structer',
    'description': "Sudan salary structer",
    'depends': [
        'hr_payroll',
        'hr'
    ],
    'data': [
        'data/salary_structure_data.xml',
        'views/hr_salary_rule_views.xml',
        'views/hr_employee_view.xml',
    ],
    'license': 'LGPL-3',
    'application': True,
}
