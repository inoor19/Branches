# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools.safe_eval import safe_eval
from odoo.addons import decimal_precision as dp


class HrPayrollStructure(models.Model):
    _inherit = 'hr.payroll.structure'

    is_bonus = fields.Boolean()
    bonus_ids = fields.One2many(string="Bonuse", comodel_name='hr.payroll.structure', inverse_name='parent_id')
    min_limit = fields.Float('Minimum Limit')
    max_limit = fields.Float('Maximum Limit')
    parent_id = fields.Many2one('hr.payroll.structure', string='Parent',domain=[('parent_id', '=', False)])
    

    @api.onchange('bonus_ids')
    def _onchange_bonus_ids(self):
        if not self.parent_id:
            return
        bonuses=[]
        for line in self.bonus_ids:
            bonuses.append(line.max_limit)
        self.min_limit=min(bonuses)
        self.max_limit=max(bonuses)

    