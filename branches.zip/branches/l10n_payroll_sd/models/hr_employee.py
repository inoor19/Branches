# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api , fields, models,_
from odoo.exceptions import ValidationError


class Employee(models.Model):
    _inherit = "hr.employee"

    @api.onchange('struct_id')
    def get_wage(self):
            for rec in self :
                rec.wage = self.struct_id.max_limit
