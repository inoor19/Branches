# -*- coding: utf-8 -*-
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).


{
    'name': 'Purchase Extra Features',
    "summary": """ Customization of Purchase views""",
    "author": "NCTR",
    "website": "http://www.nctr.sd",
    'category': 'Purchases',
    'version': '1.0',
    "description": """
This module customize the purchase module with the ability to archive purchase orders and vendor evaluation
""",
    'depends': [
        'purchase',
    ],
    'data': [
        'views/purchase_order_archive.xml',
        'views/vendor_evaluation.xml',
        'report/purchase_order_templates.xml',
        'report/purchase_quotation_templates.xml',

    ],
    'installable': True,
    'license': 'LGPL-3',
}
