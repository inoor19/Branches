# -*- coding: utf-8 -*-

from odoo import fields, models

AVAILABLE_PRIORITIES = [
    ('0', 'Normal'),
    ('1', 'Good'),
    ('2', 'Very Good'),
    ('3', 'Excellent')
]


class VendorEvaluation(models.Model):
    _inherit = "res.partner"
    priority = fields.Selection(AVAILABLE_PRIORITIES, "Evaluation", default='0')


