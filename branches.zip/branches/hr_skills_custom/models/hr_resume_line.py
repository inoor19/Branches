# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from datetime import datetime

from dateutil.relativedelta import relativedelta
from odoo import fields, models, api


class ResumeLine(models.Model):
    _inherit = 'hr.resume.line'
    _description = 'Resume Line'

    qualification_id = fields.Many2one('hr.qualification', "Qualification", ondelete="restrict")
    specialization_id = fields.Many2one('hr.specialization', "Specialization", ondelete="restrict")
    institute_id = fields.Many2one('hr.institute', string='Institute', ondelete="restrict")
    qualification = fields.Char("Qualification")
    specialization = fields.Char("Specialization")
    date_start = fields.Date(required=True)
    date_end = fields.Date()
    year = fields.Integer(string='Year')
    month = fields.Integer(string='Month')

    @api.onchange('institute_id', 'qualification_id', 'specialization_id')
    def onchange_institute_id(self):
        if self.institute_id:
            self.name = self.institute_id.name
        if self.qualification_id:
            self.qualification = self.qualification_id.name
        if self.specialization_id:
            self.specialization = self.specialization_id.name

    @api.onchange('date_start', 'date_end')
    def compute_resume_duration(self):
        for resume_line in self:
            if resume_line.date_start:
                date_start = datetime.strptime(str(resume_line.date_start), "%Y-%m-%d")
                if resume_line.date_end:
                    date_end = datetime.strptime(str(resume_line.date_end), "%Y-%m-%d")
                    resume_line.year = relativedelta(date_end, date_start).years
                    resume_line.month = relativedelta(date_end, date_start).months
                else:
                    resume_line.year = relativedelta(datetime.now().date(), date_start).years
                    resume_line.month = relativedelta(datetime.now().date(), date_start).months
