# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from datetime import datetime
from odoo.exceptions import UserError, ValidationError


class Qualification(models.Model):
    _name = "hr.qualification"
    _description = "Qualification"
    _inherit = ['mail.thread']
    _order = "code"

    name = fields.Char("Qualification", required=True, translate=True, tracking=True)
    code = fields.Char("Code", help="Gives the Code order when displaying a list of qualifications.")

    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The name of the Qualification must be unique!'),
        ('seq_uniq', 'unique (code)', "Code name must be unique!")
    ]

    def write(self, vals):
        if vals.get('name'):
            qualification_id = self.env['hr.qualification'].search([('name', '=', vals.get('name'))])
            if qualification_id.name == vals.get('name'):
                raise UserError(_('The name of the qualification must be unique!'))
        res = super(Qualification, self).write(vals)


class Specialization(models.Model):
    _name = "hr.specialization"
    _inherit = ['mail.thread']
    _description = "Specialization"
    _order = "code"

    name = fields.Char("Specialization", required=True, translate=True, tracking=True)
    code = fields.Char("Code")

    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The name of the Specialization  must be unique!'),
    ]

    def write(self, vals):
        if vals.get('name'):
            specialization_id = self.env['hr.specialization'].search([('name', '=', vals.get('name'))])
            if specialization_id:
                raise UserError(_('The name of the Specialization  must be unique!'))
        res = super(Specialization, self).write(vals)
        return res


class Institute(models.Model):
    _name = "hr.institute"
    _inherit = ['mail.thread']
    _description = "Institutes"

    name = fields.Char("Institute", required=True, translate=True, tracking=True)

    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The name of the Institute  must be unique!'),
    ]

    def write(self, vals):
        if vals.get('name'):
            institute_id = self.env['hr.institute'].search([('name', '=', vals.get('name'))])
            if institute_id.name == vals.get('name'):
                raise UserError(_('The name of the Institute  must be unique!'))
        res = super(Institute, self).write(vals)
        return res
