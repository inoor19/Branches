##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _


class User(models.Model):
    _inherit = 'res.users'

    certificate = fields.Many2one(related='employee_id.certificate', readonly=False, related_sudo=False)
