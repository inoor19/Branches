##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from datetime import datetime, date
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta


class Employee(models.Model):
    _inherit = "hr.employee"

    certificate = fields.Many2one('hr.qualification', string='Certificate Level', compute='_get_high_qualification',
                                  groups="hr.group_hr_user", tracking=True)
    total_years = fields.Integer(compute="total_duration_computation", string="Total Years")
    total_months = fields.Integer(compute="total_duration_computation", string="Total Months")

    def _get_high_qualification(self):
        for emp in self:
            emp_qualification_id = self.env['hr.resume.line'].search(
                [('employee_id', '=', emp.id)]).sorted(
                key=lambda x: x.qualification_id.code,
                reverse=True)
            emp_qualification_id = emp_qualification_id and emp_qualification_id[0].qualification_id.id or False
            emp.certificate = emp_qualification_id

    def total_duration_computation(self):
        for emp in self:
            for emp_resume in emp.resume_line_ids:
                emp.total_years += emp_resume.year
                emp.total_months += emp_resume.month
                if emp.total_months >= 12:
                    emp.total_years += 1
                    emp.total_months -= 12
