/** @odoo-module **/

import tour from 'web_tour.tour';

tour.register('hr_skills_custom.hr_skills_tour', {
    test: true,
    url: '/web',
},  [{
        content: "Give some Qualification",
        trigger: ".o_field_widget[name='qualification'] textarea",
        run: "text Sang some songs and played some music",
    },
    {
        content: "Give some Specialization",
        trigger: ".o_field_widget[name='specialization'] textarea",
        run: "text Sang some songs and played some music",
    },
]);
