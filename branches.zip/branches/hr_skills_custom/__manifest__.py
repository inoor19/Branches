# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'HR Skills',
    'version': '1.1',
    'category': 'Human Resources',
    'description': """ Manage Employee Skills , knowledge and resumé of your employees""",
    'author': 'NCTR',
    'website': 'http://www.nctr.sd',
    'depends': ['hr_skills'],
    'data': [
        'security/ir.model.access.csv',
        'views/hr_qualification_views.xml',
        'views/hr_views.xml',

    ],

    'assets': {
        'web.assets_backend': [
            'hr_skills_custom/static/src/fields/*',
            'hr_skills_custom/static/src/xml/**/*',
        ],

        'web.assets_tests': [
            'hr_skills_custom/static/tests/tours/*',
        ],
    },

    'license': 'LGPL-3',
}
