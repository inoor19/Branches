# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'IT Asset Management',
    'author': 'Herlabytes',
    'category': 'Asset',
    'sequence': -1,
    'summary': 'Manages the IT Assets Owned by any Company and this done with ease',
    'depends': ['base', 'om_account_asset', 'hr', 'mail'],
    'images': ['images/main.png', 'images/main_screenshot.png'],

    'website': 'https://herlabytes.com',
    # 'description': """
    #         ITttt Assets management
    #         =================
    #         Manages IT assets owned by a company or a person.
    #         Keeps track of depreciation, and creates corresponding journal entries.
    #         """,
    'data': [
       # ,
       'security/ir.model.access.csv',
        'views/main_asset_view.xml',
        'views/custoday_request.xml',
       
    ],
     'application': True,
    'license': 'LGPL-3',
}