
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

class CustodayRequest(models.Model):
    _name = 'custoday.request'
    _description = 'custoday Request'
    _rec_name='custoday_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    custoday_name = fields.Many2one('account.asset.asset',string="Custoday",required=True)

    sequence = fields.Integer("Sequence")
  
    department_id= fields.Many2one('hr.department',"Department",related='employee_id.department_id',store=True)

    employee_id = fields.Many2one('hr.employee',"Employee",required=True)

    request_date=fields.Date('Request Date',required=True,default=fields.Date.today())

    receipt_date=fields.Date('Receipt Date')

    request_reason=fields.Html('Request Reason')

    request_type=fields.Selection([('permanent','Permanent'),
        ('temporary', 'Temporary'),
        ],default='permanent',string="Request Type")

    custoday_type = fields.Selection([
        ('employee', 'For Employee'),
        ('department','For Department')],default='employee',string="Custoday Type")

    return_date=fields.Date('Return date')

    return_reason=fields.Html('Return Reason')

    custoday_state=fields.Html("Custoday State")

    lost_date=fields.Date('Lost Date')

    lost_location=fields.Char('Lost location')

    state = fields.Selection([('draft', "Draft"),
                              ('request', "Request"),
                              ('approved', "Approved"),('received',"Received"),('returned',"Returned"),('losted',"Losted"),('cansel','Cansel')],default='draft')

    evidence = fields.Binary(string="Evidence of Loss")


    def action_request_draft(self):
        self.write({'state':'draft'})

    def action_request_request(self):
        self.write({'state':'request'})

    def action_request_approved(self):
        self.write({'state':'approved'})

    def action_request_received(self):
        self.custoday_name.assigned_to = self.employee_id
        self.write({'state':'received'})

    def action_returned(self):
        self.custoday_name.assigned_to = False
        self.write({'state':'returned'})

    def action_losted(self):
        self.write({'state':'losted'})

    def action_cansel(self):
        self.write({'state':'cansel'})

    def action_set_to_draft(self):
        self.write({'state':'draft'})    



