# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
###############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, date
import calendar


class HrOvertime(models.Model):
    _description = 'Hr Overtime'
    _inherit = ['mail.thread']
    _name = "hr.overtime"
    _order = "date_from desc, id desc"

    @api.depends('employee_ids.amount','service_ids.amount')
    def _compute_totals(self):
        for overtime in self:
            overtime.total_amount = sum(overtime.employee_ids.mapped('amount'))
            overtime.total_service = sum(overtime.service_ids.mapped('amount'))
            overtime.total = overtime.total_amount + overtime.total_service
            
    name = fields.Char('Reference', copy=False, readonly=True, states={'draft': [('readonly', False)]})
    date = fields.Date(string="Date", copy=False, default=fields.Date.context_today, required=True)
    date_from = fields.Date('Date from', copy=False, readonly=True, states={'draft': [('readonly', False)]}, default=fields.Date.context_today, tracking=True)
    date_to = fields.Date('Date To', copy=False, readonly=True, states={'draft': [('readonly', False)]}, tracking=True)
    department_id = fields.Many2one('hr.department', string='Department', readonly=True, states={'draft': [('readonly', False)]})
    account_analytic_id = fields.Many2one('account.analytic.account', string='Analytic Account')
    overtime_objective = fields.Html(string='Overtime Objective')
    overtime_reasons = fields.Html(string='Overtime Reasons')
    notes = fields.Html(string='Notes')
    total_amount = fields.Float(compute='_compute_totals', string='Total Amount', store=True, readonly=True)
    total_service = fields.Float(compute='_compute_totals', string='Total Service', store=True, readonly=True)
    total = fields.Float(compute='_compute_totals', string='Total', store=True, readonly=True)
    employee_ids = fields.One2many('hr.overtime.employee', 'overtime_id', string="Overtime Employees", copy=True)
    service_ids = fields.One2many('hr.overtime.service', 'overtime_id', string="Overtime Services",  copy=True)
    state = fields.Selection([
        ('draft', 'Daft'),
        ('confirm', 'To Confirm'),
        ('validate', 'To Validate'),
        ('approve', 'To Approve'),
        ('done', 'Approved'),
        ('cancel', 'Cancel')
    ], 'Status', readonly=True, tracking=True, copy=False, default='draft')
    voucher_id = fields.Many2one('account.move', string='voucher', copy=False)
    company_id = fields.Many2one('res.company', string='Company', readonly=True, states={'draft': [('readonly', False)]}, 
        default=lambda self: self.env.user.company_id)
    payment_state = fields.Selection(
        selection=[
            ('not_paid', 'Not Registered'),
            ('in_payment', 'In Payment'),
            ('paid', 'Paid'),
            ('reversed', 'Reversed'),
        ], string="Payment Status", compute='_compute_payment_state', store=True, readonly=True, copy=False, tracking=True)

    @api.constrains('date_from', 'date_to')
    def _check_date_validity(self):
        """ verifies if date_from is earlier than date_to. """
        for rec in self:
            if rec.date_to < rec.date_from:
                raise ValidationError(_('End Date cannot be earlier than Start Date.'))


    @api.depends('voucher_id.payment_state')
    def _compute_payment_state(self):
        for overtime in self:
            payment_state = 'not_paid'
            if overtime.voucher_id:
               payment_state = 'in_payment'
               if overtime.voucher_id.payment_state in ['paid','partial']:
                   payment_state = 'paid'
               if overtime.voucher_id.payment_state in ['reversed','cancel']:
                   payment_state = 'reversed'
            overtime.payment_state = payment_state
            
    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('hr.overtime') or '/'
        return super(HrOvertime, self).create(vals)

    def unlink(self):
        for overtime in self:
            if overtime.state not in ('draft'):
                raise UserError(_('You cannot delete an Overtime which is not draft state.'))
        return super(HrOvertime, self).unlink()

    def action_request(self):
        for rec in self:
            for emp in rec.employee_ids:
                policy = emp._get_policy(emp.employee_id)
                if policy and policy.max_hour_month < (emp.day_overtime + emp.holiday_overtime):
                    raise ValidationError(
                        _("Employee %s Exeed the Max hour for overtime in month") % (emp.employee_id.name))
        self.write({'state': 'confirm'})
        
    def action_confirm(self):
        self.write({'state': 'validate'})

    def action_validate(self):
        self.write({'state': 'approve'})

    def action_cancel(self):
        self.write({'state': 'cancel'})

    def action_draft(self):
        self.write({'state': 'draft'})
        
    def action_done(self):
        for rec in self:
            lines = []
            for emp in rec.employee_ids:
                if emp.amount > 0:
                    policy = emp._get_policy(emp.employee_id)
                    if not policy.account_id:
                            raise ValidationError(
                        _('Please Enter Accounting Configration for policy %s.') % (policy.name))
                        
                    dis_list = {rec.account_analytic_id.id}
                    distribution = dict.fromkeys(dis_list, 100)
                    line = {
		                'name':'HR Overtime /' + emp.employee_id.name,
		                'analytic_distribution': rec.account_analytic_id and distribution or 0,
		                'account_id': policy.account_id.id or False,
		                'quantity': 1,
		                'price_unit': emp.amount,
		                'tax_ids': []
                    }
                    lines.append(line)
            if not rec.voucher_id:
                voucher_id = self.env['account.move'].sudo().create({
                    'ref': rec.name,
                    'narration': rec.notes,
                    'move_type': 'in_invoice',
                    'journal_id': policy.journal_id.id or False,
                    'company_id': rec.company_id.id,
                    'source_document': self._name + ',' + str(rec.id),
                    'source_document_state': rec.state,
                    'invoice_date': fields.Date.context_today(self),
                    'invoice_line_ids': [(0, 0, x) for x in lines],
                })
                rec.voucher_id = voucher_id
            else:
                rec.voucher_id.invoice_line_ids.sudo().unlink()
                rec.voucher_id.sudo().write({'invoice_line_ids': [(0, 0, x) for x in lines]})
        self.write({'state': 'done'})

    def compute_lines(self):
        for rec in self:
            rec.employee_ids.compute_amount()
