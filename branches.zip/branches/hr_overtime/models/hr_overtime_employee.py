# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
###############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from odoo.addons import decimal_precision as dp


class HrOvertimeEmployee(models.Model):
    _description = 'Hr Employee Overtime'
    _inherit = ['mail.thread']
    _name = "hr.overtime.employee"
    _order = "id desc"

    overtime_id = fields.Many2one('hr.overtime', string="Overtime")
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    day_overtime = fields.Float('Work Overtime')
    holiday_overtime = fields.Float('Holiday Overtime')
    hour_wage = fields.Float(string='Hour Wage')
    amount = fields.Float(string='Amount', digits=dp.get_precision('Account'))

    # TO Review
    # @api.constrains('holiday_overtime','day_overtime')
    # def _check_overtime(self):
    #     max_hour=self.overtime_id.overtime_categ_id.max_hour_day
    #     for line in self:
    #         if line.overtime > max_hour:
    #             raise ValidationError(_("Max Overtime in Day is %s in this overtime Category")%(max_hour))

    @api.onchange('employee_id')
    def onchange_employee_id(self):
        hour_wage = 0.0
        values = {'hour_wage': 0.0}
        policy = self._get_policy(self.employee_id)
        if policy:
            wage = policy.allowance_id.compute_allowed_deduct_amount(self.employee_id.contract_id)
            hour_wage = round(wage / (30 * 8), 2)
        self.hour_wage = hour_wage


    def _get_policy(self, employee):
        policy_ids = self.env['hr.overtime.type'].search([])
        for policy in policy_ids:
            job = False
            category = False
            if employee.job_id.id in policy.job_ids.ids:
                job = True
            for cat in employee.category_ids:
                if cat.id in policy.category_ids.ids:
                    category = True

            if policy.job_ids and policy.category_ids:
                if job and category:
                    return policy
            elif not policy.job_ids and policy.category_ids:
                if category:
                    return policy
            elif policy.job_ids and not policy.category_ids:
                if job:
                    return policy
            else:
                return policy
        return False

    def compute_amount(self):
        for line in self:
            hour_wage = 0.0
            amount = 0.0
            policy = line._get_policy(line.employee_id)
            if policy:
                wage = policy.allowance_id.compute_allowed_deduct_amount(line.employee_id.contract_id)
                hour_wage = round(wage / (30 * 8), 2)
                holiday_overtime_amount = hour_wage * line.holiday_overtime * policy.holiday_rate
                day_overtime_amount = hour_wage * line.day_overtime * policy.day_rate
                amount = float(holiday_overtime_amount + day_overtime_amount)
            else:
                raise ValidationError(_("No Policy Found for Employee %s ") % (line.employee_id.name))
            line.hour_wage = hour_wage
            line.amount = amount

    @api.onchange('employee_id')
    def _onchange_overtime_line(self):
        if not self.overtime_id.department_id:
            return {'domain': {'employee_id': [('id', 'in', [])]}}
        domain = {}
        employees = self.overtime_id.employee_ids.mapped('employee_id').ids
        domain = {'employee_id': [('id', 'not in', employees), ('department_id', '=', self.overtime_id.department_id.id), ('state','=','approved')]}
        return {'domain': domain}
