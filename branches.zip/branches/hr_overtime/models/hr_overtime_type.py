# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
###############################################################################

from odoo import api, fields, models, _


class HrOvertimeType(models.Model):
    _description = 'Overtime Type'
    _name = "hr.overtime.type"

    name = fields.Char('Name',copy=False)
    job_ids = fields.Many2many('hr.job', string='Job Positions')
    category_ids = fields.Many2many('hr.employee.category',string='Tags')
    journal_id = fields.Many2one('account.journal', string='Journal', domain=[('type', '=', 'purchase')], company_dependent=True)
    account_id = fields.Many2one('account.account', string='Account',domain=[('deprecated', '=', False)], company_dependent=True)
    max_hour_day = fields.Float(string='Max Hours in Day', default=3.0)
    max_hour_month = fields.Float(string='Max Hours in Month', default=80.0)
    day_rate = fields.Float(string='Work Rate', default=1.5)
    holiday_rate = fields.Float(string='Holiday Rate', default=2.0)
    active = fields.Boolean('Active', default=True)
    allowance_id = fields.Many2one('hr.salary.rule', string="Allowance",domain="[('rule_type', '=', 'allowance')]")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)


    _sql_constraints = [
        ('name_uniq', 'unique (name)', _('The name of the overtime policy must be unique !'))]

