# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from . import hr_overtime_type
from . import hr_overtime
from . import hr_overtime_employee
from . import hr_overtime_service

