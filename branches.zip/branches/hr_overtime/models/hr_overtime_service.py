# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
###############################################################################

from odoo import api, fields, models, _
from odoo.addons import decimal_precision as dp


class HrOvertimeService(models.Model):
    _description = 'Overtime Service'
    _name = "hr.overtime.service"

    overtime_id = fields.Many2one('hr.overtime', string="Overtime")
    name = fields.Char('Name', required=True)
    product_id = fields.Many2one('product.product', string='Product/Service')
    amount = fields.Float(string='Amount', digits=dp.get_precision('Account'))
    partner_id = fields.Many2one('res.partner', string="Partner")

    @api.onchange('product_id')
    def onchange_product(self):
        values = {}
        if self.product_id:
            values['name'] = self.product_id.partner_ref
            values['amount'] = self.product_id.standard_price
            if self.product_id.description_purchase:
                values['name'] += '\n' + self.product_id.description_purchase
        return {'value': values}
