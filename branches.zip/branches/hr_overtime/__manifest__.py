# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'Overtime',
    'version': '1.0',
    'category': 'Human Resources/Overtime',
    'description': """
        Manage Employee Overtime
        """,
    'author': "NCTR",
    'website': "http://www.nctr.sd",
    'depends': ['hr_custom', 'hr_payroll'],
    'data': [
        'security/hr_overtime_security.xml',
        'security/ir.model.access.csv',

        'data/hr_overtime_seq.xml',

        'views/hr_overtime_type_views.xml',
        'views/service_views.xml',
        'views/hr_overtime_employee_view.xml',
        'views/hr_overtime_views.xml',
        'views/hr_views.xml',

        'views/overtime_views.xml'
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}
