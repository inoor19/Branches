# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
###############################################################################

{
    'name': "Crm Translation Module",
    'version': '1.0',
    'category': 'Sales/CRM',
    'summary': """
        Translation of CRM standard module and customization the crm team form""",
    'description': """
       This module translate the CRM standard module and customize the crm team form
    """,
    "author": "NCTR",
    "website": "http://www.nctr.sd",
    'depends': ['crm', 'crm_iap_mine'],
    'data': [
        'views/crm_team_views.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
