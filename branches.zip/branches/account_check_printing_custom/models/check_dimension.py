# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models, fields, api, _


class account_check_dimension(models.Model):
    _name = 'account.check.dimension'
    _description = "Check Dimension"
    _order = 'active desc'

    name = fields.Char(string='Name', required=True, translate=True)
    font_size = fields.Integer('Font Size', required=True)
    date = fields.Char('Date', size=54, required=True)
    beneficiary = fields.Char('Beneficiary', size=54, required=True)
    amount = fields.Char('Written Amount', size=54, required=True)
    number = fields.Char('Amount', size=54, required=True)
    preview = fields.Html('Report Preview', sanitize=False, strip_style=False, readonly=1)
    active = fields.Boolean(default=True, help="Set active to false to hide the check dimension without removing it.")
    
    @api.model_create_multi
    def create(self, vals_list):
        res = super(account_check_dimension, self).create(vals_list)
        for rec in res:
            rec.print_preview()
        return res

    def check_dimension_values(self, value):
        # if value is empty or value not x,y then default value 20,20 else x and y
        if value == False or len(value.split(',', 1)) != 2:
            return ['20', '20']
        else:
            # if value is 'x,y' then splited_value is ['x','y']
            splited_value = value.split(',', 1)
            return splited_value

    @api.onchange('font_size', 'date', 'beneficiary', 'amount', 'number')
    def print_preview(self):
        dimension_values = {'date': str(self.date),
                            'beneficiary': str(self.beneficiary),
                            'amount': str(self.amount),
                            'number': str(self.number),
                            }

        # using mapping to split string values from (x,y) form to ['x','y'] form to use x and y more easy
        splited_dimension_values = dict(map(lambda key_val: (
            key_val[0], self.check_dimension_values(key_val[1])), dimension_values.items()))
        font_size = self.font_size or 0

        html = """
                <body>
                    <html>

                        <center>
                            <h2>
                                View check form
                            </h2>
                        </center>
                        <br/>
                        <br/>
                        <hr/>
                        <svg height="1000" width="1000" style="font-size: %spx;">
                            <text x="%s" y="%s">
                                       Beneficiary
                            </text>
                            <text x="%s" y="%s">
                                      Written amount
                            </text>
                            <text x="%s" y="%s">
                                        Amount
                            </text>
                            <text x="%s" y="%s">
                                        Date
                            </text>
                        </svg>

                    </html>
                </body>
                """ % (str(font_size),
                       splited_dimension_values['beneficiary'][0],
                       splited_dimension_values['beneficiary'][1],
                       splited_dimension_values['amount'][0],
                       splited_dimension_values['amount'][1],
                       splited_dimension_values['number'][0],
                       splited_dimension_values['number'][1],
                       splited_dimension_values['date'][0],
                       splited_dimension_values['date'][1])

        self.preview = html
