# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models


class AccountMove(models.Model):
    _inherit = "account.move"
    
    def button_draft(self):
        payments = self.mapped('payment_id')
        if any(payment.check_number for payment in payments):
            payments.check_if_check_log_active()
        return super(AccountMove, self).button_draft()
