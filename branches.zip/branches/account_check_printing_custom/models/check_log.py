# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class CheckLog(models.Model):
    _name = 'check.log'
    _description = 'Check Log'
    _order = "date_due desc, check_no desc, id desc"

    name = fields.Char('Partner Name', required=True, readonly=True)
    payment_ids = fields.Many2many('account.payment', 'account_payment_check_rel', 'check_id', 'payment_id',
                    string="Payments", readonly=True)
    check_no = fields.Char('Check Number', size=128, readonly=True)
    date_due = fields.Date(string='Date', readonly=True)
    journal_id = fields.Many2one('account.journal', string='Bank', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Partner', readonly=True)
    company_id = fields.Many2one(related='journal_id.company_id', string='Company', store=True, readonly=True)
    amount = fields.Monetary(string="Amount", readonly=True)
    check_amount_in_words = fields.Char(string="Amount in Words", required=True, readonly=True)
    currency_id = fields.Many2one('res.currency', string="Currency", readonly=True)
    description = fields.Text(string="Description")
    signed = fields.Boolean(string='Signed')
    delivery_date = fields.Date(string='Delivery Date')
    active = fields.Boolean(default=True)
    reason = fields.Selection([
        ('void', 'Void'),
        ('loss', 'Loss'), 
        ('cancelation', 'Cancelation'),
        ('unk', 'Unknown')], string="Reason")
    status = fields.Selection([
        ('active', 'Active'),
        ('canceled', 'Canceled'),
        ('deleted', 'Deleted')], string="Check Status")
    payment_reversed = fields.Boolean(default=True, compute="set_payment_reversed")

    @api.depends('payment_ids.state')
    def set_payment_reversed(self):
        for check in self:
            check.payment_reversed = False
            if any(payment.state == 'reversed' for payment in check.payment_ids):
                check.payment_reversed = True
    
    @api.constrains('journal_id', 'check_no')
    def _check_no(self):
        for check in self:
            checks = self.search([('journal_id', '=', check.journal_id.id),
                                  ('check_no', '=', check.check_no), ('status', '!=', 'deleted')])
            if len(checks) > 1:
                raise ValidationError(
                    _('This check no.(%s) is already exist!') % check.check_no)

    def button_payment_ids(self):
        return {
            'name': _('Payment'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.payment',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', self.payment_ids.ids)],
        }

    def action_delete(self):
        for check in self:
            check.payment_ids.write({'check_number': None, 'is_move_sent': False})
        self.write({'status':'deleted'})
        
    def action_cancel(self,reason='unk'):
        for check in self:
            check.payment_ids.write({'check_number': None, 'is_move_sent': False})
        self.write({'status': 'canceled', 'reason': reason})

    def action_read_check_log(self):
        self.ensure_one()
        return {
            'name': self.display_name,
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'check.log',
            'res_id': self.id,
        }

