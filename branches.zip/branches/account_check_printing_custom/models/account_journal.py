# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models, fields, api, _


class AccountJournal(models.Model):
    _inherit = "account.journal"

    check_dimension = fields.Many2one('account.check.dimension', 'Check dimension')
