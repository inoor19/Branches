# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models, fields, api, _
from odoo.addons.account_check_printing_custom.models import amount_to_text_ar
from odoo.exceptions import UserError, ValidationError


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    partner_name = fields.Char('Partner Name', size=128)

    @api.onchange('amount')
    def _onchange_amount(self):
        context = self._context or {}
        if hasattr(super(AccountPayment, self), '_onchange_amount'):
            super(AccountPayment, self)._onchange_amount()
        if context.get('lang') == 'ar_001':
            units_name = self.currency_id.currency_unit_label
            cents_name = self.currency_id.currency_subunit_label
            self.check_amount_in_words = amount_to_text_ar.amount_to_text(
                self.amount, 'ar', units_name, cents_name)

    def check_if_check_log_active(self):
        for payment in self:
            self.env.cr.execute("""
                        SELECT payment_check_rel.check_id as check_id
                        FROM account_payment_check_rel as payment_check_rel
                        left join check_log on (payment_check_rel.check_id=check_log.id)
                        left join account_payment on (payment_check_rel.payment_id=account_payment.id)
                        WHERE payment_check_rel.payment_id = %(payment_id)s
                            AND check_log.status = 'active' 
                            And check_log.check_no = account_payment.check_number
                        LIMIT 1
                    """, {
                        'payment_id': payment.id,
                    })
            check_log = self.env['check.log'].browse(self.env.cr.fetchone())
            if check_log :
                raise ValidationError(_('Deleted check log frist'))

    def validate_payments_homogeneity(self):
        if any(payment.journal_id != self[0].journal_id for payment in self):
            raise UserError(
                _("In order to print multiple payments at one check, they must belong to the same bank journal."))
        if any(payment.partner_id != self[0].partner_id for payment in self):
            raise UserError(
                _("In order to print multiple payments at one check, they must belong to the same partner."))
        if any(payment.currency_id != self[0].currency_id for payment in self):
            raise UserError(
                _("In order to print multiple payments at one check, they must belong to the same Currency."))
        if any(payment.check_number != self[0].check_number for payment in self):
            raise UserError(
                _("In order to print multiple payments at one check, they must belong to the same Check."))


    def print_checks(self):
        context = self._context or {}
        self = self.filtered(lambda r: r.payment_method_line_id.code == 'check_printing' and r.state != 'reconciled')
        
        if len(self) == 0:
            raise UserError(_("Payments to print as a checks must have 'Check' selected as payment method and "
                              "not have already been reconciled"))
        self.validate_payments_homogeneity()

        is_printed = False
        if all(payment.is_move_sent for payment in self):
            is_printed = True
        
        next_check_number = self[0].check_number
        if not next_check_number :
            if self[0].journal_id.check_manual_sequencing :
                next_check_number = self[0].journal_id.check_sequence_id.number_next_actual
            elif not is_printed:
                self.env.cr.execute("""
                        SELECT id
                        FROM check_log 
                        WHERE journal_id = %(journal_id)s
                            AND status != 'deleted'
                        ORDER BY check_no::INTEGER DESC
                        LIMIT 1
                    """, {
                        'journal_id': self.journal_id.id,
                    })
                last_printed_check = self.env['check.log'].browse(self.env.cr.fetchone())
                next_check_number = last_printed_check and int(last_printed_check.check_no) + 1 or 1
            
        second_name = self[0].partner_id.name
        if self[0].partner_id.company_type == 'person':
            first_name = "Mr  "
        else:
            first_name = "Gentlemen /"
        partner_name = first_name + second_name
        amount = sum([payment.amount for payment in self])
        check_amount_in_words = self[0].currency_id.amount_to_text(amount)
        if context.get('lang') == 'ar_001':
            units_name = self[0].currency_id.currency_unit_label
            cents_name = self[0].currency_id.currency_subunit_label
            check_amount_in_words = amount_to_text_ar.amount_to_text(
                amount, 'ar', units_name, cents_name)

        return {
            'name': _('Print Check Report'),
            'type': 'ir.actions.act_window',
            'res_model': 'print.prenumbered.checks',
            'view_type': 'form',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'payment_ids': self.ids,
                'default_next_check_number': next_check_number,
                'default_preprinted': is_printed,
                'default_name': partner_name,
                'default_amount': amount,
                'default_check_amount_in_words': check_amount_in_words,
                'default_journal_id': self.journal_id.id,
                'default_partner_id': self.partner_id.id,
                'default_currency_id': self.currency_id.id,

            }
        }

    @api.constrains('check_number', 'journal_id')
    def _constrains_check_number(self):
        payment_checks = self.filtered('check_number')
        if not payment_checks:
            return
        for payment_check in payment_checks:
            if not payment_check.check_number.isdecimal():
                raise ValidationError(_('Check numbers can only consist of digits'))
        self.env.flush_all()
        
