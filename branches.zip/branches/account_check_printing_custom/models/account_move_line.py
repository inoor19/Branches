# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    check_number = fields.Char(string="Check Number", related='payment_id.check_number')
