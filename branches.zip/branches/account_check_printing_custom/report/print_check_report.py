# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api ,models
from odoo.exceptions import UserError


class print_check_report_custom(models.AbstractModel):
    _name = 'report.account_check_printing_custom.print_check_custom'
    _description = "Print Check Report"

    def func(self, form):
        date = str(form['date'])
        beneficiary = str(form['beneficiary'])
        amount = str(form['amount'])
        number = str(form['number'])
        font_size = form['font_size']
            
        date_dim = date.split(',')
        amount_dim = amount.split(',')
        number_dim = number.split(',')
        beneficiary_dim = beneficiary.split(',')

        result = []
        
        #fix wrapping amount text
        start_index = ""
        orig_check_amount_in_words = form['check_amount_in_words']
        form['check_amount_in_words_sec'] = ""
        if len(form['check_amount_in_words']) > 200:
            start_index = form['check_amount_in_words'].find(" ", 200)
            form['check_amount_in_words'] = orig_check_amount_in_words[0:start_index]
            form['check_amount_in_words_sec'] = orig_check_amount_in_words[start_index:]

        res = {
                'font': str(font_size)+"px",
                'date': form['payment_date'],
                'partner': form['partner_name'],
                'amount': form['check_amount_in_words'],
                'amount_wrap': form['check_amount_in_words_sec'],
                'number':form['amount_money'],
                'date_w': int(date_dim[0]), 
                'date_h': int(date_dim[1]), 
                'amount_w': int(amount_dim[0]), 
                'amount_h': int(amount_dim[1]), 
                'number_w': int(number_dim[0]),
                'number_h': int(number_dim[1]),
                'partner_w': int(beneficiary_dim[0]),
                'partner_h': int(beneficiary_dim[1]),
                     
        }
        result.append(res)
        return result

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get('form'):
            raise UserError(_("Form content is missing, this report cannot be printed."))
        print_report = self.env['ir.actions.report']._get_report_from_name(
            'account_check_printing_custom.print_check_custom')
        payments = self.env['account.payment'].browse(self.ids)

        return {
            'doc_ids': self.ids,
            'doc_model': print_report.model,
            'docs': payments,
            'func': self.func(data['form']),
        }

