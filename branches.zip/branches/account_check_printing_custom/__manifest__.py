# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'Check Printing Extra Features',
    'version': '1.0',
    'author': 'NCTR',
    'website': 'http://www.nctr.sd',
    "category": "Accounting",
    "description": """
    Customizing Check Printing To meet Sudanese companies/institutes need.
        By :
            - Allowing to Configure Check Dimension.
            - Adding Checks log.
            """,
    'depends': ['account_check_printing', 'account_custom'],
    'data': [
        'security/account_check_printing_security.xml',
        'security/ir.model.access.csv',
        'data/check_dimension_data.xml',
        'views/check_dimension.xml',
        'views/account_journal_view.xml',
        'views/account_move_view.xml',
        'views/account_payment_view.xml',
        'views/check_log.xml',
        'wizard/print_prenumbered_checks_view.xml',
        'wizard/account_move_reversal_view.xml',
        'report/print_check_report.xml',
        'report/reports_action.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
