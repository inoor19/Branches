# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import models, fields, api
from odoo.tools.translate import _


class AccountMoveReversal(models.TransientModel):
    _inherit = 'account.move.reversal'
    _description = 'Account Move Reversal'

    has_check = fields.Boolean('Has Check',default=False)
    check_cancelation = fields.Selection([('auto', 'Auto'),('manual', 'Manual')], string="Check cancelation", default="auto")

    @api.model
    def default_get(self, fields):
        res = super(AccountMoveReversal, self).default_get(fields)
        if 'move_ids' in fields:
            move_ids = self.env['account.move'].browse(self.env.context['active_ids']) if self.env.context.get('active_model') == 'account.move' else self.env['account.move']
            if any(payment.check_number for payment in move_ids.mapped('payment_id')):
                res['has_check'] = True
        return res
    
    @api.onchange('move_ids')
    def _set_has_check(self):
        for rec in self:
            rec.has_check = False
            if any(payment.check_number for payment in rec.move_ids.mapped('payment_id')):
                rec.has_check = True
            
    def prepar_for_reverse_moves(self):
        res = super(AccountMoveReversal, self).prepar_for_reverse_moves()
        if self.has_check and self.check_cancelation == 'auto':
            moves = self.env['account.move'].browse(self.env.context.get('active_ids'))
            payments = moves.mapped('payment_id')
            self.env.cr.execute("""
                        SELECT DISTINCT payment_check_rel.check_id 
                        FROM account_payment_check_rel as payment_check_rel
                        left join check_log on (payment_check_rel.check_id=check_log.id)
                        left join account_payment on (payment_check_rel.payment_id=account_payment.id)
                        WHERE payment_check_rel.payment_id in %(payment_ids)s
                            AND check_log.status = 'active' 
                            And check_log.check_no = account_payment.check_number
                    """, {
                        'payment_ids': tuple(payments.ids),
                    })
            check_log_ids = [rec[0] for rec in self.env.cr.fetchall()]
            check_logs = self.env['check.log'].browse(check_log_ids)
            check_logs.action_cancel('cancelation')
        return res

