# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class PrintPreNumberedChecks(models.TransientModel):
    _inherit = 'print.prenumbered.checks'

    name = fields.Char('Partner')
    action = fields.Selection([
        ('reprint', 'Reprint'),
        ('update', 'Update'),
        ('delete', 'Delete')], string='Process')
    reason = fields.Selection([
        ('void', 'Void'),
        ('loss', 'Loss'),
        ('cancelation', 'Cancelation'),
        ('unk', 'Unknown')], string='Reason')
    preprinted = fields.Boolean('Pre-printed')
    date_due = fields.Date(string='Date', default=fields.Date.context_today)
    journal_id = fields.Many2one('account.journal', string='Bank')
    currency_id = fields.Many2one('res.currency', string="Currency")
    partner_id = fields.Many2one('res.partner', string='Beneficiary')
    amount = fields.Monetary(string="Amount", required=True)
    check_amount_in_words = fields.Char(string="Amount in Words")

    def print_checks(self):
        check_number = self.next_check_number
        if self.env.context.get('payment_ids'):
            payments = self.env['account.payment'].browse(self.env.context['payment_ids'])
            description = ''
            for pay in payments:
                if pay.name:
                    if description:
                        description += '+' + pay.name
                    else:
                        description += pay.name
            check_log = {
                'payment_ids': [(6, 0, self.env.context['payment_ids'])],
                'status': 'active',
                'check_no': check_number,
                'journal_id': self.journal_id.id,
                'currency_id': self.currency_id.id,
                'partner_id': self.partner_id.id,
                'amount': self.amount,
                'date_due': self.date_due,
                'name': self.name,
                'check_amount_in_words': self.check_amount_in_words,
                'description': description,
            }
            if not self.preprinted:
                if payments[0].journal_id.check_manual_sequencing and not payments[0].check_number:
                    payments[0].journal_id.check_sequence_id.next_by_id()
                self.env['check.log'].create(check_log)
                payments.write({'check_number': check_number, 'is_move_sent': True})
                return self.do_print_checks()
            else:
                check_id = self.env['check.log'].search([
                    ('payment_ids', 'in', self.env.context['payment_ids']),
                    ('status', '=', 'active')], limit=1)
                if not check_id:
                    raise UserError(_("Selected check is not exist!"))
                if self.action == 'reprint':
                    if payments.ids != check_id.payment_ids.ids :
                        raise UserError(_("Please Select All Payments that belong to this check"))
                    return self.do_print_checks()
                if self.action == 'delete':
                    check_id.action_delete()
                if self.action == 'update':
                    check_id.action_cancel(self.reason)
                    payments.write({'check_number': check_number, 'is_move_sent': True})
                    check_id = self.env['check.log'].create(check_log)
                return check_id

    def do_print_checks(self):
        if self.journal_id.check_dimension.id != False:
            res = {
                'payment_date': self.date_due,
                'partner_name': self.name,
                'check_amount_in_words': self.check_amount_in_words,
                'amount_money': self.amount,
                'beneficiary': self.journal_id.check_dimension.beneficiary,
                'font_size': self.journal_id.check_dimension.font_size,
                'date': self.journal_id.check_dimension.date,
                'amount': self.journal_id.check_dimension.amount,
                'number': self.journal_id.check_dimension.number,
            }
            datas = {
                'ids': self._ids,
                'model': 'account.payment',
                'form': res,
            }
            dic = self.env.ref(
                'account_check_printing_custom.print_check_qweb_report').report_action(self, data=datas)
            return dic
        else:
            raise UserError(
                _("Please add check dimensions to the selected journal in order to print a check."))
