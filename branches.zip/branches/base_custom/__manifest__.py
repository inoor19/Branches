# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
{
    'name': "Base Extra Features",
    'version': '1.1',
    'category': 'Hidden',
    'description': """
        Customizing The kernel of Odoo, needed for all Custom Modules.
        Adding :
            - Custom Layout for pdf reports.
            - Code for Partners
            """,
    'author': "NCTR",
    'website': "http://www.nctr.sd",
    'depends': ['base','web'],
    'data': [
        'report/custom_layouts.xml'
    ],
    'installable': True,
    'license': 'LGPL-3',

}
