# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api , fields, exceptions, tools, models,_
from odoo.exceptions import UserError, Warning


class ResPartner(models.Model):
    _inherit = 'res.partner'

    @api.constrains('email')
    def _validate_email(self):
        for partner in self:
            if partner.email and not tools.single_email_re.match(partner.email):
                raise Warning(_("Please enter a valid email address."))
        return True

    def name_get(self):
        res = []
        for rec in self:
            name = rec.name
            if rec.ref :
                name = '[%s] %s' % (rec.ref,rec.name)
            res += [(rec.id, name)]
        return res

    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        super(ResPartner, self).name_search(name, args, operator, limit)
        if not args:
            args = []
        if name:
            partners = self.search([('ref', operator , name)] + args, limit=limit)
            if not partners :
                partners = self.search([('name', operator , name)] + args, limit=limit)
        else:
            partners = self.search(args, limit=limit)
        return partners.name_get()

    
