# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'Budget Management',
    'author': 'NCTR',
    'category': 'Accounting',
    'version': '1.0',
    'description': """
      - Use budgets to compare actual with expected Cost and revenue
      - Allow Operation(transfer , in transfer ,increase) on budgets
      - budget Confirmation
      - Analytic reports for Expense Budgets and Revenue Budgets
      """,
    'summary': 'Odoo 16 Budget Management',
    'sequence': 10,
    'website': 'http://www.nctr.sd',
    'depends': ['account'],
    'license': 'LGPL-3',
    'data': [
        'security/account_budget_security.xml',
        'security/ir_rules.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/account_views.xml',
        'views/analytic_line_views.xml',
        'views/account_analytic_account_views.xml',
        'views/account_budget_views.xml',
        'views/account_budget_position_views.xml',
        'views/res_config_settings_views.xml',
        'views/account_budget_operation_view.xml',
        'views/account_budget_confirmation_view.xml',
    ],
}
