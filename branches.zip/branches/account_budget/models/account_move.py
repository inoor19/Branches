# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError


class AccountMove(models.Model):
    _inherit = 'account.move'

    def check_budget(self):
        analytic = []
        for rec in self:
            for line in rec.invoice_line_ids:
                if line.analytic_distribution:
                    for account_id, distribution in line.analytic_distribution.items():
                        analytic.append(int(account_id))
                line.get_budget_line(analytic)

    def action_post(self):
        res = super(AccountMove, self).action_post()
        self.check_budget()
        return res


class AccountMoveline(models.Model):
    _inherit = 'account.move.line'

    @api.constrains('account_id')
    def _check_analytic_required(self):
        for rec in self:
            if rec.account_id.analytic_required and not rec.analytic_distribution:
                raise ValidationError(_('The %s must have Analytic Account ') % (rec.account_id.name))

    def get_budget_line(self,analytic):
        self.ensure_one()
        if self.account_id.budget_account:
            position = self.env['account.budget.post']._get_budget_position(self.account_id.id)
            if not position:
                raise UserError(_('No Budget Position for Account %s', self.account_id.code))

            if len(analytic) != 0:
                budget_id = self.env['crossovered.budget'].search([
                    ('analytic_account_id', 'in',
                     analytic), ('state', '=', 'open'), '|',
                    ('date_from', '<=', self.date), '&',
                    ('date_from', '<=', self.date),
                    ('date_to', '>=', self.date),
                ], limit=1)

            else:
                budget_id = self.env['crossovered.budget'].search([
                    ('state', '=', 'open'), '|',
                    ('date_from', '<=', self.date), '&',
                    ('date_from', '<=', self.date),
                    ('date_to', '>=', self.date),
                ], limit=1)


            if not budget_id:
                raise UserError('There is no Open budget')

            budget_line = self.env['crossovered.budget.lines'].search([
                ('crossovered_budget_id', '=', budget_id.id),
                ('general_budget_id', '=', position.id), ('state', '=', 'open')])

            if not budget_line:
                raise UserError(_('Budget Position is not found in budget'))

            if not budget_line.allow_budget_overdraw and budget_line.residual < self.price_subtotal:
                raise ValidationError(_('Budget can\'t go overdrow!'))
            return budget_line
