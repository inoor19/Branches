# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError


# ---------------------------------------------------------
# Budgets
# ---------------------------------------------------------


class AccountBudgetPost(models.Model):
    _name = "account.budget.post"
    _order = "code"
    _inherit = ['mail.thread']
    _description = "Budgetary Position"

    name = fields.Char('Name', required=True, copy=True, tracking=True)
    account_ids = fields.Many2many('account.account', 'account_budget_rel', 'budget_id', 'account_id', 'Accounts',
                                   domain=[('deprecated', '=', False), ('budget_account', '=', True)], required=True)
    budget_line = fields.One2many('crossovered.budget.lines', 'general_budget_id', 'Budget Lines')
    company_id = fields.Many2one('res.company', 'Company', required=True, default=lambda self: self.env.company)
    # customized fields
    code = fields.Char(string='Position Code', required=True, copy=True, tracking=True)
    active = fields.Boolean(string='Active', default=True,
                            help='Set active to false to hide the Account Budget Post without removing it')
    type = fields.Selection([('out', 'Expense'), ('in', 'Revenue')],
                            required=True, default='out', tracking=True)
    allow_budget_overdraw = fields.Boolean(string='Allow Overdraw',
                                           help='Allow to overdraw budget if residual of budget is less than the requested amount', )
    class_type = fields.Selection([('detailed', 'Detailed'), ('main', 'Main')],
                                  string='Position Type', default='detailed')
    parent_id = fields.Many2one('account.budget.post', string='Parent Position')
    child_ids = fields.One2many('account.budget.post', 'parent_id', string='Sub Budgetary Position')

    def _check_account_ids(self, vals):
        # Raise an error to prevent the account.budget.post to have not specified account_ids.
        # This check is done on create because require=True doesn't work on Many2many fields.
        if 'account_ids' in vals:
            account_ids = self.new({'account_ids': vals['account_ids']}, origin=self).account_ids
        else:
            account_ids = self.account_ids
        if not account_ids and self.class_type == 'detailed':
            raise ValidationError(_('The budget must have at least one account.'))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            self._check_account_ids(vals)
        return super(AccountBudgetPost, self).create(vals_list)

    def write(self, vals):
        self._check_account_ids(vals)
        return super(AccountBudgetPost, self).write(vals)

    def unlink(self):
        """
        overwrite unlink to check if there is budget lines with this budgetary position,
        if founded then prevent delete it
        """
        for budgetary_position in self:
            budgetary = self.env['crossovered.budget.lines'].search([('general_budget_id', '=', budgetary_position.id)])
            if budgetary:
                raise ValidationError(
                    _('Can not  delete (%s) budgetary position! , it has budget lines') % budgetary_position.name)
        return super(AccountBudgetPost, self).unlink()

    @api.constrains('account_ids')
    def _check_account_redundant(self):
        for rec in self:
            position = self.env['account.budget.post'].search(
                [('id', '!=', rec.id), ('account_ids', 'in', rec.account_ids.ids)])
            if position:
                raise ValidationError(_('there is accounts exist on another position'))

    @api.onchange('account_ids')
    def _onchange_account_redundant(self):
        for rec in self:
            position = self.env['account.budget.post'].search(
                [('id', '!=', rec._origin.id), ('account_ids', 'in', rec.account_ids._origin.ids)])
            if position:
                raise ValidationError(_('this accounts exist on another position'))

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'name' not in default:
            default['name'] = _("%s (copy)") % (self.name)
        if 'code' not in default:
            default['code'] = _("%s (copy)") % (self.code)
        return super(AccountBudgetPost, self).copy(default=default)

    def name_get(self):
        result = []
        for rec in self:
            name = '[' + str(rec.code) + ']' + ' ' + str(rec.name)
            result.append((rec.id, name))
        return result

    @api.onchange('class_type')
    def onchange_class_type(self):
        if self.class_type:
            self.parent_id = False

    def _get_budget_position(self, account_id):
        positions_ids = self.search([('class_type', '=', 'detailed')])
        for post in positions_ids:
            if account_id in post.account_ids.ids:
                return post
        return False

    def create_budgetary_positions(self):
        for account in self.account_ids:
            self.env['account.budget.post'].create(
                {
                    'type': self.type,
                    'class_type': 'detailed',
                    'code': account.code,
                    'name': account.name,
                    'parent_id': self.id,
                    'account_ids': [(6, 0, [account.id])]
                })
        return True

    def open_budget_lines(self):
        return {
            'name': _('Budgets'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'crossovered.budget.lines',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('crossovered_budget_id', '=', self.id)],
        }
