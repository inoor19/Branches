# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta
import time


# ---------------------------------------------------------
# Budgets
# ---------------------------------------------------------

class CrossoveredBudget(models.Model):
    _name = "crossovered.budget"
    _description = "Budget"
    _inherit = ['mail.thread']
    _order = "date_from desc, id desc"

    name = fields.Char('Budget Name', required=True, states={'done': [('readonly', True)]})
    user_id = fields.Many2one('res.users', 'Responsible', default=lambda self: self.env.user)
    date_from = fields.Date('Start Date', required=True, states={'done': [('readonly', True)]})
    date_to = fields.Date('End Date', required=True, states={'done': [('readonly', True)]})
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirm', 'Confirmed'),
        ('open', 'Opened'),
        ('close', 'Closed'),
    ], 'Status', default='draft', index=True, required=True, readonly=True, copy=False, tracking=True)
    crossovered_budget_line = fields.One2many('crossovered.budget.lines', 'crossovered_budget_id', 'Budget Lines',
                                              states={'done': [('readonly', True)]}, copy=True)
    company_id = fields.Many2one('res.company', 'Company', required=True, default=lambda self: self.env.company)
    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account', readonly=True,
                                          domain=[('budget', '=', True)],
                                          states={'draft': [('readonly', False)]})
    type = fields.Selection([
        ('in', 'Revenue'),
        ('out', 'Expense')],
        required=True, default='out', states={'draft': [('readonly', False)]})
    amount = fields.Float(compute='_compute_planned_amount', string='Planned Amount')
    practical_amount = fields.Float(compute='_compute_practical_amount', string='Actual')
    set_to_draft = fields.Boolean(compute='_compute_set_to_draft')
    active = fields.Boolean(string='Active', default=True)

    @api.constrains('name')
    def uniqu_budget_name(self):
        """
        this function makes constraint that the name of the budget
         must be uninque
        """
        crossovered_budget_ids = self.env['crossovered.budget'].search([('name', '=', self.name)])
        if len(crossovered_budget_ids) > 1:
            raise ValidationError(_("budget name must be unique ! "))

    @api.constrains('date_from', 'date_to', 'analytic_account_id')
    def _check_budget_overlap(self):
        if self.date_from and self.date_to:
            overlap_ids = self.search([('date_from', '<=', self.date_to), ('date_to', '>=', self.date_from),
                                       ('analytic_account_id', '=', self.analytic_account_id.id), ('id', '!=', self.id),
                                       ('type', '=', self.type)])
            if overlap_ids:
                raise ValidationError(_(" The budgets are overlapping ."))

    @api.constrains('date_from', 'date_to')
    def _check_date_validity(self):
        """ verifies if date_from is earlier than date_to. """
        for budget in self:
            if budget.date_from and budget.date_to:
                if budget.date_to < budget.date_from:
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'name' not in default:
            default['name'] = _("%s (copy)") % (self.name)

        date_from = datetime.strptime(str(self.date_to), "%Y-%m-%d").date() + timedelta(days=1)
        if 'date_from' not in default:
            default['date_from'] = date_from
        if 'date_to' not in default:
            default['date_to'] = date_from
        return super(CrossoveredBudget, self).copy(default=default)

    def write(self, vals):
        res = super(CrossoveredBudget, self).write(vals)
        for budget in self:
            line_vals = {}
            if vals.get('date_from'):
                line_vals.update({'date_from': budget.date_from})
            if vals.get('date_to'):
                line_vals.update({'date_to': budget.date_to})
            if vals.get('analytic_account_id'):
                line_vals.update({'analytic_account_id': budget.analytic_account_id.id})
            if vals.get('date_from') or vals.get('date_to') or vals.get('analytic_account_id'):
                budget.crossovered_budget_line.write(line_vals)
        return res

    def unlink(self):
        for rec in self:
            if rec.state != 'draft':
                raise ValidationError(_("You Can't Delete Record That are not Draft"))
        return super(CrossoveredBudget, self).unlink()

    def action_budget_draft(self):
        self.write({'state': 'draft'})

    def action_budget_confirm(self):
        self.write({'state': 'confirm'})

    def action_budget_open(self):
        self.write({'state': 'open'})

    def action_budget_close(self):
        self.write({'state': 'close'})

    @api.depends('crossovered_budget_line', 'crossovered_budget_line.reserve',
                 'crossovered_budget_line.transfer_amount', 'crossovered_budget_line.in_transfer_amount',
                 'crossovered_budget_line.practical_amount', 'crossovered_budget_line.confirm')
    def _compute_set_to_draft(self):
        for rec in self:
            set_to_draft = True
            for line in rec.crossovered_budget_line:
                if line.reserve != 0 or line.transfer_amount != 0 or \
                        line.in_transfer_amount != 0 or line.practical_amount != 0 or line.confirm != 0:
                    set_to_draft = False
            rec.set_to_draft = set_to_draft

    # customized methods
    @api.depends('crossovered_budget_line', 'crossovered_budget_line.planned_amount')
    def _compute_planned_amount(self):
        for rec in self:
            result = 0.0
            for line in rec.crossovered_budget_line:
                result += line.planned_amount
            rec.amount = result

    @api.depends('crossovered_budget_line', 'crossovered_budget_line.practical_amount')
    def _compute_practical_amount(self):
        for rec in self:
            result = 0.0
            for line in rec.crossovered_budget_line:
                result += line.practical_amount
            rec.practical_amount = result

    @api.onchange('date_from', 'date_to')
    def onchange_date(self):
        for rec in self:
            rec.crossovered_budget_line.sudo().write({'date_from': rec.date_from, 'date_to': rec.date_to})

    def button_open_operations(self):
        return {
            'name': _('Budget Operations'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.budget.operation.line',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'context': {'create': False, 'edit': False, 'delete': False},
            'domain': ['|', ('budget_line_id_from.crossovered_budget_id', 'in', self.ids),
                       ('budget_line_id_to.crossovered_budget_id', 'in', self.ids)],
        }

    _sql_constraints = [
        ('name_unique', 'unique (name,type)', _('Budget name must be unique.')),
    ]


class CrossoveredBudgetLines(models.Model):
    _name = "crossovered.budget.lines"
    _inherit = ['mail.thread']
    _description = "Budget Line"

    name = fields.Char(compute='_compute_line_name')
    crossovered_budget_id = fields.Many2one('crossovered.budget', 'Budget', ondelete='cascade', index=True,
                                            required=True)
    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account')
    analytic_plan_id = fields.Many2one('account.analytic.group', 'Analytic Plan', related='analytic_account_id.plan_id',
                                       readonly=True)
    general_budget_id = fields.Many2one('account.budget.post', 'Budgetary Position')
    date_from = fields.Date('Start Date', required=True)
    date_to = fields.Date('End Date', required=True)
    paid_date = fields.Date('Paid Date')
    currency_id = fields.Many2one('res.currency', related='company_id.currency_id', readonly=True)
    planned_amount = fields.Monetary(
        'Planned Amount', required=True,
        help="Amount you plan to earn/spend. Record a positive amount if it is a revenue and a negative amount if it is a cost.")
    practical_amount = fields.Monetary(
        compute='_compute_practical_amount', string='Practical Amount', help="Amount really earned/spent.")
    theoritical_amount = fields.Monetary(
        compute='_compute_theoritical_amount', string='Theoretical Amount',
        help="Amount you are supposed to have earned/spent at this date.")
    percentage = fields.Float(
        compute='_compute_percentage_deviation', string='Achievement',
        help="Comparison between practical and theoretical amount. This measure tells you if you are below or over budget.")
    company_id = fields.Many2one(related='crossovered_budget_id.company_id', comodel_name='res.company',
                                 string='Company', store=True, readonly=True)
    is_above_budget = fields.Boolean(compute='_is_above_budget')
    crossovered_budget_state = fields.Selection(related='crossovered_budget_id.state', string='Budget State',
                                                store=True, readonly=True)
    # customized fields
    name_position_analytic = fields.Char(compute='_budget_name_code', store=True, string='Budget Name', tracking=True)
    code = fields.Char(compute='_budget_name_code', store=True, string='Code', tracking=True)
    residual = fields.Float(compute='_compute_residual_balance', string='Residual Amount')
    transfer_amount = fields.Float(compute='_compute_operation_amount', string='Transfer Amount')
    reserve = fields.Float(compute='_compute_operation_amount', string='Increase Amount')
    type = fields.Selection([
        ('in', 'Revenue'),
        ('out', 'Expense')], related='crossovered_budget_id.type')
    in_transfer_amount = fields.Float(compute='_compute_operation_amount', string='In-Transfer Amount')
    confirmation_ids = fields.One2many('account.budget.confirmation', 'budget_line_id', 'Confirmations', copy=False)
    confirm = fields.Float(compute='_compute_confirm_amount', string='Confirm Amount')
    deviation = fields.Float(compute='_compute_percentage_deviation', string="deviation")
    operation_id_from = fields.One2many('account.budget.operation.line', 'budget_line_id_from',
                                        string='line operation history From', copy=False)
    operation_id_to = fields.One2many('account.budget.operation.line', 'budget_line_id_to',
                                      string='line operation history To', copy=False)
    allow_budget_overdraw = fields.Boolean(string='Allow Budget Overdraw',
                                           states={'draft': [('readonly', False)]}, copy=False, tracking=True)
    state = fields.Selection(related='crossovered_budget_id.state', string='State', store=True, readonly=True,
                             tracking=True)
    active = fields.Boolean(string='Active', default=True)

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        # overrides the default read_group in order to compute the computed fields manually for the group
        fields_list = {'practical_amount', 'theoritical_amount', 'percentage', 'transfer_amount', 'in_transfer_amount', 'reserve','residual', 'confirm'}
        fields = {field.split(':', 1)[0] if field.split(':', 1)[0] in fields_list else field for field in fields}
        result = super(CrossoveredBudgetLines, self).read_group(domain, fields, groupby, offset=offset, limit=limit,
                                                                orderby=orderby, lazy=lazy)
        if any(x in fields for x in fields_list):
            for group_line in result:

                # initialise fields to compute to 0 if they are requested
                if 'practical_amount' in fields:
                    group_line['practical_amount'] = 0
                if 'theoritical_amount' in fields:
                    group_line['theoritical_amount'] = 0
                if 'transfer_amount' in fields:
                    group_line['transfer_amount'] = 0
                if 'in_transfer_amount' in fields:
                    group_line['in_transfer_amount'] = 0
                if 'reserve' in fields:
                    group_line['reserve'] = 0
                if 'residual' in fields:
                    group_line['residual'] = 0
                if 'confirm' in fields:
                    group_line['confirm'] = 0
                if 'percentage' in fields:
                    group_line['percentage'] = 0
                    group_line['practical_amount'] = 0
                    group_line['theoritical_amount'] = 0
                    group_line['transfer_amount'] = 0
                    group_line['in_transfer_amount'] = 0
                    group_line['reserve'] = 0
                    group_line['residual'] = 0
                    group_line['confirm'] = 0

                if group_line.get('__domain'):
                    all_budget_lines_that_compose_group = self.search(group_line['__domain'])
                else:
                    all_budget_lines_that_compose_group = self.search([])
                for budget_line_of_group in all_budget_lines_that_compose_group:
                    if 'practical_amount' in fields or 'percentage' in fields:
                        group_line['practical_amount'] += budget_line_of_group.practical_amount

                    if 'theoritical_amount' in fields or 'percentage' in fields:
                        group_line['theoritical_amount'] += budget_line_of_group.theoritical_amount

                    if 'transfer_amount' in fields:
                        group_line['transfer_amount'] += budget_line_of_group.transfer_amount

                    if 'in_transfer_amount' in fields:
                        group_line['in_transfer_amount'] += budget_line_of_group.in_transfer_amount

                    if 'reserve' in fields:
                        group_line['reserve'] += budget_line_of_group.reserve

                    if 'residual' in fields:
                        group_line['residual'] += budget_line_of_group.residual


                    if 'confirm' in fields:
                        group_line['confirm'] += budget_line_of_group.confirm

                    if 'percentage' in fields:
                        group_line['percentage'] += budget_line_of_group.percentage



        return result

    def _is_above_budget(self):
        for line in self:
            if line.theoritical_amount >= 0:
                line.is_above_budget = line.practical_amount > line.theoritical_amount
            else:
                line.is_above_budget = line.practical_amount < line.theoritical_amount

    def _compute_line_name(self):
        # just in case someone opens the budget line in form view
        for line in self:
            computed_name = line.crossovered_budget_id.name
            if line.general_budget_id:
                computed_name += ' - ' + line.general_budget_id.name
            if line.analytic_account_id:
                computed_name += ' - ' + line.analytic_account_id.name
            line.name = computed_name

    def _compute_practical_amount(self):
        for line in self:
            acc_ids = line.general_budget_id.account_ids.ids
            date_to = line.date_to
            date_from = line.date_from
            if line.analytic_account_id.id:
                analytic_line_obj = self.env['account.analytic.line']
                domain = [('account_id', '=', line.analytic_account_id.id),
                          ('date', '>=', date_from),
                          ('date', '<=', date_to),
                          ]
                if acc_ids:
                    domain += [('general_account_id', 'in', acc_ids)]

                where_query = analytic_line_obj._where_calc(domain)
                analytic_line_obj._apply_ir_rules(where_query, 'read')
                from_clause, where_clause, where_clause_params = where_query.get_sql()
                select = "SELECT SUM(amount) from " + from_clause + " where " + where_clause

            else:
                aml_obj = self.env['account.move.line']
                domain = [('account_id', 'in',
                           line.general_budget_id.account_ids.ids),
                          ('date', '>=', date_from),
                          ('date', '<=', date_to),
                          ('move_id.state', '=', 'posted')
                          ]
                where_query = aml_obj._where_calc(domain)
                aml_obj._apply_ir_rules(where_query, 'read')
                from_clause, where_clause, where_clause_params = where_query.get_sql()
                select = "SELECT sum(credit)-sum(debit) from " + from_clause + " where " + where_clause

            self.env.cr.execute(select, where_clause_params)
            practical_amount = self.env.cr.fetchone()[0] or 0.0
            line.practical_amount = abs(practical_amount)

    def _compute_theoritical_amount(self):
        # beware: 'today' variable is mocked in the python tests and thus, its implementation matter
        today = fields.Date.today()
        for line in self:
            theo_amt = 0.00
            if line.paid_date:
                if today <= line.paid_date:
                    theo_amt = 0.00
                else:
                    theo_amt = line.planned_amount
            else:
                line_timedelta = line.date_to - line.date_from
                elapsed_timedelta = today - line.date_from

                if elapsed_timedelta.days < 0:
                    # If the budget line has not started yet, theoretical amount should be zero
                    theo_amt = 0.00
                elif line_timedelta.days > 0 and today < line.date_to:
                    # If today is between the budget line date_from and date_to
                    theo_amt = (
                                       elapsed_timedelta.total_seconds() / line_timedelta.total_seconds()) * line.planned_amount
                else:
                    theo_amt = line.planned_amount
            line.theoritical_amount = theo_amt

    @api.constrains('general_budget_id', 'analytic_account_id')
    def _must_have_analytical_or_budgetary_or_both(self):
        if not self.analytic_account_id and not self.general_budget_id:
            raise ValidationError(
                _("You have to enter at least a budgetary position or analytic account on a budget line."))

    def action_open_budget_entries(self):
        if self.analytic_account_id:
            # if there is an analytic account, then the analytic items are loaded
            action = self.env['ir.actions.act_window']._for_xml_id('analytic.account_analytic_line_action_entries')
            action['domain'] = [('account_id', '=', self.analytic_account_id.id),
                                ('date', '>=', self.date_from),
                                ('date', '<=', self.date_to)
                                ]
            if self.general_budget_id:
                action['domain'] += [('general_account_id', 'in', self.general_budget_id.account_ids.ids)]
        else:
            # otherwise the journal entries booked on the accounts of the budgetary postition are opened
            action = self.env['ir.actions.act_window']._for_xml_id('account.action_account_moves_all_a')
            action['domain'] = [('account_id', 'in',
                                 self.general_budget_id.account_ids.ids),
                                ('date', '>=', self.date_from),
                                ('date', '<=', self.date_to)
                                ]
        return action

    @api.constrains('date_from', 'date_to')
    def _line_dates_between_budget_dates(self):
        for rec in self:
            budget_date_from = rec.crossovered_budget_id.date_from
            budget_date_to = rec.crossovered_budget_id.date_to
            if rec.date_from:
                date_from = rec.date_from
                if date_from < budget_date_from or date_from > budget_date_to:
                    raise ValidationError(
                        _('"Start Date" of the budget line should be included in the Period of the budget'))
            if rec.date_to:
                date_to = rec.date_to
                if date_to < budget_date_from or date_to > budget_date_to:
                    raise ValidationError(
                        _('"End Date" of the budget line should be included in the Period of the budget'))

    # customized_method
    @api.depends('analytic_account_id', 'general_budget_id')
    def _budget_name_code(self):
        for line in self:
            analytic = line.analytic_account_id
            account = line.general_budget_id
            line.name_position_analytic = str(account.name) + '/' + str(analytic.name)
            line.code = str(account.code) or '' + '/ ' + str(analytic.code) or ''

    def _compute_operation_amount(self):
        for line in self:
            transfer = 0.0
            in_transfer = 0.0
            reserve = 0.0
            if line.date_from and line.date_to and not isinstance(line.id, models.NewId):
                self.env.cr.execute("""
                   SELECT name ,
                          COALESCE(SUM((CASE WHEN  budget_line_id_from = %s
                          THEN - amount
                           ELSE amount
                           END  )),0) AS amount
                     FROM  account_budget_operation_line h
                       where  state='done' and (budget_line_id_from = %s or budget_line_id_to = %s)
                     group by name""", (line.id, line.id, line.id))
                result = self.env.cr.dictfetchall()
                for r in result:
                    if r['name'] == 'transfer':
                        transfer += r['amount']
                    elif r['name'] == 'increase':
                        reserve += r['amount']
                    else:
                        in_transfer += r['amount']
            else:
                transfer = 0.0
                in_transfer = 0.0
                reserve = 0.0

            line.transfer_amount = transfer
            line.in_transfer_amount = in_transfer
            line.reserve = reserve

    def _compute_residual_balance(self):
        for line in self:
            line.residual = line.planned_amount + line.transfer_amount + line.in_transfer_amount + line.reserve - \
                            (line.practical_amount + line.confirm)

    def _compute_percentage_deviation(self):
        for line in self:
            total_amount = line.planned_amount + line.transfer_amount + line.in_transfer_amount + line.reserve
            deviation = total_amount != 0 and line.residual / (total_amount) or 1
            percentage = 1 - deviation
            line.deviation = deviation
            line.percentage = percentage

    def _compute_confirm_amount(self):
        for line in self:
            result = 0.0
            if self.env.user.has_group('account_budget.group_budget_confirm'):
                acc_ids = line.general_budget_id.account_ids.ids
                date_to = line.date_to
                date_from = line.date_from
                if line.analytic_account_id.id and line.date_from and line.date_to:
                    self.env.cr.execute("""
                        SELECT SUM(residual_amount)
                        FROM account_budget_confirmation
                        WHERE state ='valid' and analytic_account_id=%s
                            AND (date BETWEEN %s AND  %s)
                            AND account_id=ANY(%s)""",
                                        (line.analytic_account_id.id, date_from, date_to, acc_ids))
                if not line.analytic_account_id.id and line.date_from and line.date_to:
                    self.env.cr.execute("""
                        SELECT SUM(residual_amount)
                        FROM account_budget_confirmation
                        WHERE state ='valid'
                            AND (date BETWEEN %s AND  %s)
                            AND account_id=ANY(%s)""",
                                        (date_from, date_to, acc_ids))


                    result = self.env.cr.fetchone()[0] or 0.0
            line.confirm = result

    @api.depends('analytic_account_id', 'general_budget_id', 'date_from', 'date_to')
    def name_get(self):
        result = []
        for line in self:
            analytic = line.analytic_account_id
            account = line.general_budget_id
            name = str(account.name) + '/' + str(analytic.name) + \
                   ' / ' + str(line.date_from or '') + ' - ' + str(line.date_to or '') + _(' / residual:') + str(
                line.residual)
            result.append((line.id, name))
        return result

    @api.constrains('planned_amount')
    def _check_amount(self):
        for rec in self:
            if rec.type == 'in' and rec.planned_amount < 0:
                raise ValidationError(_('The Budget amount must be greater than zero.'))

    @api.constrains('date_from', 'date_to', 'analytic_account_id', 'general_budget_id')
    def _check_budget_overlap(self):
        for line in self:
            if line.date_from and line.date_to:
                overlap_ids = line.search([('date_from', '<=', line.date_to), ('date_to', '>=', line.date_from),
                                           ('analytic_account_id', '=', line.analytic_account_id.id),
                                           ('id', '!=', line.id),
                                           ('general_budget_id', '=', line.general_budget_id.id)])
                if overlap_ids:
                    raise ValidationError(_("The budget is invalid. The budgets are overlapping ."))

    @api.constrains('date_from', 'date_to')
    def _date_check(self):
        for line in self:
            if line.date_from < line.crossovered_budget_id.date_from or line.date_to > line.crossovered_budget_id.date_to:
                raise ValidationError(_("The period of lines must be within the period of budget"))

    @api.constrains('general_budget_id', 'residual')
    def _check_budget_overdraw(self):
        for line in self:
            allow_budget_overdraw = line.allow_budget_overdraw
            if not allow_budget_overdraw and (line.residual < 0) and line.type == 'out':
                raise ValidationError(_('Budget can\'t go overdraw!'))

    @api.onchange('general_budget_id')
    def _onchange_crossovered_budget_line(self):
        self.allow_budget_overdraw = self.general_budget_id.allow_budget_overdraw
        domain = {}
        positions = self.crossovered_budget_id.crossovered_budget_line.mapped('general_budget_id').ids
        domain = {'general_budget_id': [('id', 'not in', positions), ('type', '=', self.crossovered_budget_id.type)]}
        return {'domain': domain}
