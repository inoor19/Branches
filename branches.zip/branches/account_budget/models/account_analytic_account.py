# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models,_


class AccountAnalyticAccount(models.Model):
    _inherit = "account.analytic.account"
    _order = "code"

    budget = fields.Boolean('Budget')
    crossovered_budget_line = fields.One2many('crossovered.budget.lines', 'analytic_account_id', 'Budget Lines')
    root_id = fields.Many2one('analytic.root', compute='_compute_account_root', store=True)

    @api.depends('code')
    def _compute_account_root(self):
        # this computes the first 2 digits of the account.
        # This field should have been a char, but the aim is to use it in a side panel view with hierarchy, and it's only supported by many2one fields so far.
        # So instead, we make it a many2one to a psql view with what we need as records.
        for record in self:
            record.root_id = (ord(record.code[0]) * 1000 + ord(record.code[1:2] or '\x00')) if record.code else False

    def action_read_analytic(self):
        self.ensure_one()
        return {
            'name': self.name,
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'account.analytic.account',
            'res_id': self.id,
        }


    def open_budget_position(self):
        return {
            'name': _('Budget Lines'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'crossovered.budget.lines',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('analytic_account_id', '=', self.id)],
        }
