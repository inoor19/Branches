# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
import time
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class AccountBudgetConfirmation(models.Model):
    _name = "account.budget.confirmation"
    _description = "Budget Confirmation"
    _inherit = ['mail.thread']
    _order = 'id desc'

    name = fields.Char(readonly=True, copy=False)
    reference = fields.Char('Reference', size=64, readonly=True, copy=False)
    account_id = fields.Many2one('account.account', 'Account', readonly=True,
                                 states={'draft': [('readonly', False)]})
    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account', readonly=True,
                                          domain=[('budget', '=', True)],
                                          states={'draft': [('readonly', False)]})
    partner_id = fields.Many2one('res.partner', 'Partner', readonly=True,
                                 states={'draft': [('readonly', False)]})
    residual_amount = fields.Float(compute='_residual_amount', string='Residual Amount', store=True)
    amount = fields.Float('Amount', required=True, readonly=True, states={'draft': [('readonly', False)]})
    state = fields.Selection([('draft', 'Draft'), ('complete', 'Waiting For Approve'),
                              ('check', 'Waiting Check'), ('valid', 'Approved'), ('waiting_valid', 'Waiting Valid'),
                              ('unvalid', 'Not Approved'), ('cancel', 'Cancelled')],
                             'Status', required=True, readonly=True, default='draft')
    type = fields.Selection([('stock_in', 'Stock IN'), ('stock_out', 'Stock OUT'),
                             ('purchase', 'Purchase'), ('other', 'Others')], 'type', default='other')
    date = fields.Date('Date', readonly=True, states={'draft': [('readonly', False)]},
                       default=lambda *args: time.strftime('%Y-%m-%d'))
    creating_user_id = fields.Many2one('res.users', 'Responsible User', default=lambda self: self.env.user)
    validating_user_id = fields.Many2one('res.users', 'Validate User', readonly=True)
    line_id = fields.One2many('account.move.line', 'budget_confirm_id', 'Entries')
    note = fields.Html('Note', required=True, readonly=True, states={'draft': [('readonly', False)]})
    company_id = fields.Many2one('res.company', 'Company', required=True, readonly=True,
                                 states={'draft': [('readonly', False)]}, default=lambda self: self.env.user.company_id)
    budget_residual = fields.Float('Budget Residual', required=True, readonly=True, default=0.0)
    budget_line_id = fields.Many2one('crossovered.budget.lines', 'Budget Line')
    doc_count = fields.Integer(compute='_compute_attached_docs_count', string="Number of documents attached")
    active = fields.Boolean(string='Active', default=True)

    def _check_company(self):
        for budget_confirm in self:
            companies = []
            companies += budget_confirm.account_id and [budget_confirm.account_id.company_id] or []
            companies += budget_confirm.analytic_account_id and [budget_confirm.analytic_account_id.company_id] or []
            if len(set(companies)) > 1:
                return False
        return True

    @api.constrains('amount')
    def _check_amount(self):
        for obj in self:
            if obj.amount < 0:
                raise ValidationError(_('The amount must be greater than zero.'))

    @api.depends('amount', 'account_id', 'analytic_account_id', 'line_id', 'line_id.debit', 'line_id.credit')
    def _residual_amount(self):
        for budget_confirm in self:
            lines = 0.0
            for line in budget_confirm.line_id:
                lines += line.debit - line.credit or 0.0
            budget_confirm.residual_amount = budget_confirm.amount - lines

    @api.model_create_multi
    def create(self, vals):
        res = super(AccountBudgetConfirmation, self).create(vals)
        res.name = self.env['ir.sequence'].next_by_code('account.budget.confirmation')
        if not self._check_company():
            raise ValidationError(_('Account, Period and Cost Center must be belong to same Company!'))
        return res

    def write(self, vals):
        budget_line_pool = self.env['crossovered.budget.lines']
        for confirmation in self:
            conf_date = confirmation.date
            budget_line_vals = {'budget_line_id': False}
            position = self.env['account.budget.post']._get_budget_position(confirmation.account_id.id)
            if position:
                line_ids = budget_line_pool.search([('analytic_account_id', '=', confirmation.analytic_account_id.id),
                                                    ('general_budget_id', '=', position.id),
                                                    ('date_from', '<=', conf_date), ('date_to', '>=', conf_date),
                                                    ('state', '=', 'open')])
                if vals.get('state', '') in ['valid'] and line_ids:
                    vals.update({'budget_line_id': line_ids.ids[0]})
                line_obj = budget_line_pool.browse(line_ids.ids)
                vals.update({'budget_residual': line_obj and line_obj[0].residual or 0.0})
        if not self._check_company():
            raise ValidationError(_('Account, Period and Cost Center must be belong to same Company!'))
        res = super(AccountBudgetConfirmation, self).write(vals)
        return res

    def unlink(self):
        if any(rec.state != 'draft' for rec in self):
            raise UserError(_('It is not allowed to delete a confirmtion not in draft state.'))
        return super(AccountBudgetConfirmation, self).unlink()

    def check_budget(self):
        """
        This method check whether the budget line residual allow to validate this confirmation or not
        @return: boolean True if budget line residual more that confirm amount, or False
        """
        budget_line = []
        line_obj = self.env['crossovered.budget.lines']
        for confirmation in self:
            position = self.env['account.budget.post']._get_budget_position(confirmation.account_id.id)

            if not position:
                self.budget_valid()

            else:
                budget_line = line_obj.search([('analytic_account_id', '=', confirmation.analytic_account_id.id),
                                               ('date_from', '<=', confirmation.date),
                                               ('date_to', '>=', confirmation.date),
                                               ('general_budget_id', '=', position.id), ('state', '=', 'open')])

            if budget_line:
                allow_budget_overdraw = budget_line.allow_budget_overdraw
                if allow_budget_overdraw or confirmation.residual_amount <= budget_line.residual:
                    self.budget_valid()

                else:
                    self.budget_unvalid()
            else:
                raise ValidationError(_('There is no Budget'))

        return True

    def action_cancel_draft(self):
        self.write({'state': 'draft'})
        if self.line_id and not self._context.get('cus_inv', False):
            raise ValidationError(_('This confirmation already have posted moves'))
        elif self.budget_line_id:
            self.write({'budget_line_id': False})

    def budget_complete(self):
        self.write({'state': 'complete'})

    def budget_valid(self):
        self.write({'state': 'valid', 'validating_user_id': self.env.user.id})

    def budget_unvalid(self):
        self.write({'state': 'unvalid'})

    def budget_cancel(self):
        self.write({'state': 'cancel'})
        if self.line_id:
            raise ValidationError(_('This confirmation already have posted moves'))
        elif self.budget_line_id:
            self.write({'budget_line_id': False})

    def _compute_attached_docs_count(self):
        attachment = self.env['ir.attachment']
        for rec in self:
            rec.doc_count = attachment.search_count([('res_model', '=', self._name), ('res_id', '=', rec.id)])

    def attachment_tree_view(self):
        domain = ['&', ('res_model', '=', self._name), ('res_id', 'in', self.ids)]
        res_id = self.ids and self.ids[0] or False
        return {
            'name': _('Attachments'),
            'domain': domain,
            'res_model': 'ir.attachment',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'kanban,tree,form',
            'view_type': 'form',
            'help': _('''<p class="oe_view_nocontent_create">

                                           Attach
       documents of %s .</p>''' % (self._description)),
            'limit': 80,
            'context': "{'default_res_model': '%s','default_res_id': %d}"
                       % (self._name, res_id)
        }

    def button_journal_entries(self):
        return {
            'name': _('Journal Items'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'account.move.line',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('budget_confirm_id', 'in', self.ids)],
        }


# ---------------------------------------------------------
# Account move Line
# --------------------------------------------------------
class AccountMoveLine(models.Model):
    """Inherit account move line object to add budject confirmation field and
        to check the constrains on the created move line with the confirmation line"""
    _inherit = 'account.move.line'

    budget_confirm_id = fields.Many2one('account.budget.confirmation', 'Confirmation')
