# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _


class AccountAccount(models.Model):
    _inherit = 'account.account'

    analytic_required = fields.Boolean(string="Analytic Required")
    budget_account = fields.Boolean(string="Budget Account")
