# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    "name": "HR Extra Features",
    "version": "1.1",
    "category": "Human Resources/Employees",
    "description": """Manage employee profile and HR process""",
    "author": "NCTR",
    "website": "http://www.nctr.sd",
    "depends": ["hr", "base_custom"],
    "data": [
             'security/hr_security.xml',
             'security/ir.model.access.csv',
             'views/menu.xml',
             'views/hr_department_view.xml',
             'views/hr_job_view.xml',
             'views/hr_views.xml',
             'views/hr_employee_transfer.xml',
             'views/hr_employee_view.xml',
             ],

    'license': 'LGPL-3',
}
