# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from datetime import datetime
from odoo.exceptions import UserError, ValidationError


class HrEmployeeFamily(models.Model):
    _name = 'hr.employee.family'
    _description = "Employee Family"
    _inherit = ['mail.thread']
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, 
        states={'approve': [('readonly', True)]},domain=[('state', '=', 'approved')],
        help='Select corresponding Employee',)
    name = fields.Char(string='Name of Sponsor', required=True,
        states={'approve': [('readonly', True)]}, tracking=True)
    relation = fields.Selection([
        ('father', 'Father'),('mother', 'Mother'),
        ('daughter', 'Daughter'),('son', 'Son'), 
        ('husband', 'husband'),('wife', 'Wife')
        ], string='Relationship', required=True, help='Relation with employee', states={'approve': [('readonly', True)]}, tracking=True)
    birthday = fields.Date('Date of Birth', states={'approve': [('readonly', True)]}, required=True, tracking=True)
    start_date = fields.Date("Start Date", states={'approve': [('readonly', True)]}, required=True, tracking=True)
    end_date = fields.Date("End Date", states={'approve': [('readonly', True)]}, tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('approve', 'Approved')], default="draft", required=True, readonly=True, tracking=True)
    active = fields.Boolean('Active', default=True)
    employee_company_id = fields.Many2one(related='employee_id.company_id', readonly=True, store=True)

    def action_approve(self):
        return self.write({'state': 'approve'})

    def set_to_draft(self):
        return self.write({'state': 'draft'})

    def unlink(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_('You cannot delete a record which is not draft!'))
        return super(HrEmployeeFamily, self).unlink()
