##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from datetime import datetime, date
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta


class Employee(models.Model):
    _inherit = "hr.employee"
    _order = "emp_code"

    @api.model
    def get_gender_selection(self):
        return [('male', _('Male')), ('female', _('Female'))]

    @api.model
    def get_marital_selection(self):
        return [('single', _('Single')),
                ('married', _('Married')),
                ('widower', _('Widower')),
                ('divorced', _('Divorced'))]

    emp_code = fields.Char('Employee Code', copy=False)
    english_name = fields.Char('Name In English')
    department_id = fields.Many2one('hr.department', 'Department',
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",tracking=True)
    job_id = fields.Many2one('hr.job', 'Job Position',
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]", tracking=True)
    start_date = fields.Date('Employment Date', default=fields.Date.today())
    job_join_date = fields.Date('Job Join Date')
    transfer_date = fields.Date("Department Join Date", readonly=True, states={'draft': [('readonly', False)]})
    sinid_date = fields.Date('SIN Date', help='Social Insurance Date')
    currency_id = fields.Many2one(string="Currency", related='company_id.currency_id', readonly=True)
    family_count = fields.Integer(compute="_compute_family_count", string="Family")
    children = fields.Integer(compute="_compute_family_count", string='Number of Dependent Children', groups="hr.group_hr_user")
    wifes = fields.Integer(compute="_compute_family_count", string='Number of Wifes', groups="hr.group_hr_user")
    gender = fields.Selection(get_gender_selection)
    marital = fields.Selection(get_marital_selection, string='Marital Status', default='single', tracking=True)
    birth_cer_no = fields.Integer("Birth Certificate NO")
    work_phone = fields.Char('Work Phone', compute="_compute_phones", store=True, readonly=False)
    blood_type = fields.Selection([
        ('1', 'O+'),('2', 'O-'),('3', 'A+'),('4', 'A-'),
        ('5', 'B+'),('6', 'B-'),('7', 'AB+'),('8', 'AB-')], 
        string='Blood Type', readonly=True, states={'draft': [('readonly', False)]})
    religion = fields.Selection([
        ('muslim', 'Muslim'),('christian', 'Christian'),('other', 'Other')], 
        default="muslim", readonly=True, states={'draft': [('readonly', False)]})
    state = fields.Selection([
        ('draft', 'Candidate'),('experiment', 'In Experiment'),
        ('approved', 'In Service'),('refuse', 'Out of Service')], string='State', default='draft', tracking=True)
    address_home_id = fields.Many2one(
        'res.partner', 'Address', compute="_compute_address_home", help='Enter here the private address of the employee, not the one linked to your company.',
        groups="hr.group_hr_user", tracking=True,
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
        
    _sql_constraints = [
        ('emp_code_uniq', 'unique (emp_code)', 'Employee Code must be unique!'),
    ]

    def unlink(self):
        for record in self:
            if record.state != 'draft':
                raise ValidationError(_('You cannot delete a record which is not draft!'))
            else:
                if record.user_id:
                    record.user_id.unlink()
        return super(Employee, self).unlink()

    def action_draft(self):
        return self.write({'state': 'draft'})

    def action_approved(self):
        #overlap_ids = self.search([('struct_id', '=', 6)])
        #overlap_ids.write({'state': 'approved'})
        #overlap_ids = self.search([('struct_id', '=', 11)])
        #overlap_ids.write({'state': 'approved'})
        return self.write({'state': 'approved'})

    def action_refuse(self):
        return self.write({'state': 'refuse'})

    def _compute_family_count(self):
       for employee in self:
            family_count = wifes = children =0
            family_ids = self.env['hr.employee.family'].search([
                ('employee_id', '=', employee.id),('state', '=','approve')])
            for family in family_ids:
               family_count += 1
               if employee.marital =='married' and family.relation == 'wife':
                   wifes += 1
               if family.relation in ['daughter','son']:
                   children += 1
            employee.family_count = family_count
            employee.wifes = wifes
            employee.children = children

    @api.depends('work_contact_id')
    def _compute_address_home(self):
        for employee in self:
            employee.address_home_id = employee.work_contact_id
                            
    def action_create_user(self):
        self.ensure_one()
        if self.user_id:
            raise ValidationError(_("This employee already has an user."))
        return {
            'name': _('Create User'),
            'type': 'ir.actions.act_window',
            'res_model': 'res.users',
            'view_mode': 'form',
            'view_id': self.env.ref('hr.view_users_simple_form').id,
            'target': 'new',
            'context': {
                'default_create_employee_id': self.id,
                'default_name': self.name,
                'default_phone': self.work_phone,
                'default_mobile': self.mobile_phone,
                'default_login': self.work_email and self.work_email or self.emp_code,
                'default_partner_id': self.address_home_id.id,
            }
        }
                    
    @api.depends('address_id')
    def _compute_phones(self):
        for employee in self:
            employee.work_phone = False
