##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from email.policy import default

class HrEmployeeJobTransfer(models.Model):
    _name = 'hr.employee.job.transfer'
    _description = "Job Transfer"
    _inherit = ['mail.thread']
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', string='Employee', required=True, domain=[('state', '=', 'approved')])
    date = fields.Date(string='Date', required=True, default=fields.Date.today())
    current_job_id = fields.Many2one('hr.job', string='Current Job',required=True, tracking=True)
    new_job_id = fields.Many2one('hr.job', string='New Job', required=True, tracking=True)
    state = fields.Selection([('draft', 'draft'), ('approve', 'approved')], 'State', default='draft', tracking=True)
    note = fields.Html("Note")
    employee_company_id = fields.Many2one(related='employee_id.company_id', readonly=True, store=True)

    @api.onchange('employee_id')
    def get_previous_job(self):
        if self.employee_id:
            self.current_job_id = self.employee_id.job_id

    def approve(self):
        self.employee_id.job_id = self.new_job_id
        self.write({'state': 'approve'})

    def set_to_draft(self):
        self.employee_id.job_id = self.current_job_id
        self.write({'state': 'draft'})

    def unlink(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_('You cannot delete a record which is not draft!'))
        return super(HrEmployeeJobTransfer, self).unlink()


class HrEmployeeDepartmentTransfer(models.Model):
    _name = 'hr.employee.department.transfer'
    _description = "Department Transfer"
    _inherit = ['mail.thread']
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', string='Employee', required=True, domain=[('state','=','approved')])
    date = fields.Date(string='Date', required=True, default=fields.Date.today())
    current_department_id = fields.Many2one('hr.department', string='Current Department',required=True, tracking=True)
    new_department_id = fields.Many2one('hr.department', string='New Department', required=True, tracking=True)
    change_job = fields.Boolean("Change Job", default=True)
    current_job_id = fields.Many2one("hr.job", string="Current Job Position", tracking=True)
    new_job_id = fields.Many2one('hr.job', 'New Job Position', tracking=True)
    job_transfer_id = fields.Many2one("hr.employee.job.transfer")
    state = fields.Selection([('draft', 'draft'), ('approve', 'approved')], 'State', default='draft', tracking=True)
    note = fields.Html("Note")
    employee_company_id = fields.Many2one(related='employee_id.company_id', readonly=True, store=True)

    @api.onchange('employee_id')
    def get_previous_department(self):
        if self.employee_id:
            self.current_department_id = self.employee_id.department_id
            self.current_job_id = self.employee_id.job_id.id

    def approve(self):
        self.employee_id.department_id = self.new_department_id
        self.write({'state': 'approve'})

        if self.change_job and not self.job_transfer_id:
            job_transfer_id = self.env['hr.employee.job.transfer'].create({
            	'employee_id': self.employee_id.id,
                'date': self.date,
                'current_job_id': self.current_job_id.id,
                'new_job_id': self.new_job_id.id,
                'state': self.state
            })
            self.employee_id.job_id = self.new_job_id.id
            self.job_transfer_id = job_transfer_id
        elif self.change_job and self.job_transfer_id:
            self.job_transfer_id.write({
            	'employee_id': self.employee_id.id,
                'date': self.date,
                'current_job_id': self.current_job_id.id,
                'new_job_id': self.new_job_id.id,
                'state': self.state
            })
            self.employee_id.job_id = self.new_job_id.id

    def set_to_draft(self):
        self.employee_id.department_id = self.current_department_id
        self.employee_id.job_id = self.current_job_id
        self.write({'state': 'draft'})

    def unlink(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_('You cannot delete a record which is not draft!'))
        return super(HrEmployeeDepartmentTransfer, self).unlink()
