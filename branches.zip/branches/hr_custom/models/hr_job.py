# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
import string
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class JobCategory(models.Model):
    _name = "hr.job.category"
    _description = "Job Category"

    name = fields.Char(string='Name', required=True, index=True, translate=True)
    section = fields.Selection([('management', 'Management'), ('technical', 'Technical')], string="Section")

    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The name of Job Category must be unique!'),
    ]


class Job(models.Model):
    _inherit = 'hr.job'
    _order = 'code'

    code = fields.Char(string='Code')
    category_id = fields.Many2one('hr.job.category', string='Job Category', ondelete='restrict')

    def show_employees(self):
        return {
            'name': 'Employees',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'hr.employee',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('job_id', '=', self.id)],
        }
