##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################


from odoo import api, fields, models, _
from odoo.exceptions import UserError


class DepartmentCategory(models.Model):
    _name = "hr.department.category"
    _description = "Department Category"

    name = fields.Char(string='Name', translate=True, required=True)

    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The name of Department Category must be unique!'),
    ]


class Department(models.Model):
    _inherit = "hr.department"
    _order = "code"

    code = fields.Char(string='Code')
    category_id = fields.Many2one('hr.department.category', string='Category', ondelete='restrict')
    _sql_constraints = [
        ('name_uniq', 'unique (complete_name)', 'The name of Department must be unique!'),
    ]

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'name' not in default:
            default['name'] = _("%s (copy)") % self.name
        return super(Department, self).copy(default=default)

    def show_employees(self):
        return {
            'name': 'Employees',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'hr.employee',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('department_id', '=', self.id)],
        }

