# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from . import hr_employee
from . import hr
from . import hr_department
from . import hr_job
from . import hr_employee_transfer

