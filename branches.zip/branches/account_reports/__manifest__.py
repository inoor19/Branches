# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'Accounting Financial Reports',
    'version': '1.0.',
    'category': 'Accounting',
    'description': """
       * Following Accounting Reports(pdf ,Excel) For Odoo 16 :
      - Journal Entry
      - General Ledger
      - Trail Balance
      - Account Statement
      - Partner Ledger
      - Partner Balance
      """,
    'summary': 'Accounting Reports For Odoo 16',
    'sequence': '3',
    'author': 'NCTR',
    'license': 'LGPL-3',
    'company': 'NCTR',
    'website': 'http://www.nctr.sd',
    'depends': ['account_custom','report_xlsx'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/account_report_common_account.xml',
        'wizard/account_report_common_partner.xml',
        'wizard/journal_entry.xml',
        'report/report.xml',
        'report/report_general_ledger.xml',
        'report/report_trial_balance.xml',
        'report/report_account_statement.xml',
        'report/report_partner_ledger.xml',
        'report/report_partner_balance.xml',
        'report/report_journal_entries.xml',
    ],
    'installable': True,

}
