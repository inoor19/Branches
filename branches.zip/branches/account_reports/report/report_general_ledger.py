# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

import time
from odoo import api, models, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta


class ReportGeneralLedger(models.AbstractModel):
    _name = 'report.account_reports.report_general_ledger'
    _inherit = 'report.report_xlsx.abstract'
    _description = 'General Ledger Report'

    def _get_account_move_entry(self, accounts, analytic_account_ids,
                                partner_ids, init_balance, display_account):
        """
        :param:
                accounts: the recordset of accounts
                analytic_account_ids: the recordset of analytic accounts
                init_balance: boolean value of initial_balance
                sortby: sorting by date or partner and journal
                display_account: type of account(receivable, payable and both)

        Returns a dictionary of accounts with following key and value {
                'code': account code,
                'name': account name,
                'debit': sum of total debit amount,
                'credit': sum of total credit amount,
                'balance': total balance,
                'amount_currency': sum of amount_currency,
                'move_lines': list of move line
        }
        """
        cr = self.env.cr
        move_lines = {x: [] for x in accounts.ids}
        wizard = self.env['account.common.account.report'].browse(self.env.context.get('active_ids'))
        analytic_clu = " "
        if analytic_account_ids:
            analytic_clu = " l.analytic_distribution AS analytic_distribution""" + ','

        # Prepare initial sql query and Get the initial move lines
        if init_balance:
            date_from = datetime.strptime(wizard.date_from, '%Y-%m-%d').date()
            year = date_from.year
            first_year_date = datetime.strptime('%s-01-01' % (year), '%Y-%m-%d')
            context = dict(self.env.context)
            context['date_from'] = first_year_date
            context['date_to'] = date_from - timedelta(days=1)
            context['initial_bal'] = True
            if partner_ids:
                context['partner_ids'] = partner_ids
            domain = wizard.with_context(context)._query_get()
            init_tables, init_where_clause, init_where_params = self.env['account.move.line']._where_calc(
                domain).get_sql()
            init_wheres = [""]
            if init_where_clause.strip():
                init_wheres.append(init_where_clause.strip())
            init_filters = " AND ".join(init_wheres)
            filters = init_filters.replace('account_move_line__move_id', 'm').replace('account_move_line', 'l')
            sql = ("""SELECT """ + analytic_clu + """0 AS lid, l.account_id AS account_id, '' AS ldate,
                '' AS lcode, 0.0 AS amount_currency, '' AS lref, 
                'Initial Balance' AS lname, COALESCE(SUM(l.debit),0.0) AS debit, 
                COALESCE(SUM(l.credit),0.0) AS credit, 
                COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit), 0) as balance, 
                '' AS lpartner_id,\
                '' AS move_name, '' AS mmove_id, '' AS currency_code,\
                NULL AS currency_id,\
                '' AS invoice_id, '' AS invoice_type, '' AS invoice_number,\
                '' AS partner_name\
                FROM account_move_line l\
                LEFT JOIN account_move m ON (l.move_id=m.id)\
                LEFT JOIN res_currency c ON (l.currency_id=c.id)\
                LEFT JOIN res_partner p ON (l.partner_id=p.id)\
                JOIN account_journal j ON (l.journal_id=j.id)\
                WHERE l.account_id IN %s""" + filters + ' GROUP BY l.account_id')
            params = (tuple(accounts.ids),) + tuple(init_where_params)
            cr.execute(sql, params)
            for row in cr.dictfetchall():
                move_lines[row.pop('account_id')].append(row)

        # Prepare sql query base on selected parameters from wizard
        context = dict(self.env.context)
        if partner_ids:
            context['partner_ids'] = partner_ids
        domain = wizard.with_context(context)._query_get()
        tables, where_clause, where_params = self.env['account.move.line']._where_calc(domain).get_sql()
        wheres = [""]
        if where_clause.strip():
            wheres.append(where_clause.strip())
        filters = " AND ".join(wheres)
        filters = filters.replace('account_move_line__move_id', 'm').replace('account_move_line', 'l')

        # Get move lines base on sql query and Calculate the total balance of move lines
        sql = ('''SELECT ''' + analytic_clu + ''' l.id AS lid, l.account_id AS account_id, 
            l.date AS ldate, j.code AS lcode, l.currency_id, 
            l.amount_currency,
            l.ref AS lref, l.name AS lname, COALESCE(l.debit,0) AS debit, 
            COALESCE(l.credit,0) AS credit, 
            COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit), 0) AS balance,\
            m.name AS move_name, c.symbol AS currency_code, 
            p.name AS partner_name\
            FROM account_move_line l\
            JOIN account_move m ON (l.move_id=m.id)\
            LEFT JOIN res_currency c ON (l.currency_id=c.id)\
            LEFT JOIN res_partner p ON (l.partner_id=p.id)\
            JOIN account_journal j ON (l.journal_id=j.id)\
            JOIN account_account acc ON (l.account_id = acc.id) \
            WHERE l.account_id IN %s ''' + filters + ''' GROUP BY l.id, 
            l.account_id, l.date, j.code, l.currency_id, l.amount_currency, 
            l.ref, l.name, m.name, c.symbol, p.name''')
        params = (tuple(accounts.ids),) + tuple(where_params)
        cr.execute(sql, params)
        for row in cr.dictfetchall():
            if analytic_account_ids:
                if row['analytic_distribution']:
                    for acc, perc in row['analytic_distribution'].items():
                        if acc in analytic_account_ids:
                            balance = 0
                            for line in move_lines.get(row['account_id']):
                                balance += ((line['debit'] * perc) / 100) - ((line['credit'] * perc) / 100)
                            row['debit'] = (row['debit'] * perc) / 100
                            row['credit'] = (row['credit'] * perc) / 100
                            row['balance'] += balance
                            move_lines[row.pop('account_id')].append(row)

            else:
                balance = 0
                for line in move_lines.get(row['account_id']):
                    balance += line['debit'] - line['credit']
                row['balance'] += balance
                move_lines[row.pop('account_id')].append(row)

        # Calculate the debit, credit and balance for Accounts
        account_res = []
        for account in accounts:
            currency = account.currency_id and account.currency_id or account.company_id.currency_id
            res = dict((fn, 0.0) for fn in ['credit', 'debit', 'balance'])
            res['code'] = account.code
            res['name'] = account.name
            res['move_lines'] = move_lines[account.id]
            for line in res.get('move_lines'):
                res['debit'] += line['debit']
                res['credit'] += line['credit']
                res['balance'] = line['balance']
            if display_account == 'all':
                account_res.append(res)
            if display_account == 'movement' and res.get('move_lines'):
                account_res.append(res)
            if display_account == 'not_zero' and not currency.is_zero(res['balance']):
                account_res.append(res)

        return account_res

    def _get_account_type_move_entry(self, accounts_type, accounts, partner_ids, init_balance, display_account,
                                     analytic_account_ids):
        """
        :param:
                accounts: the recordset of accounts
                init_balance: boolean value of initial_balance
                sortby: sorting by date or partner and journal
                display_account: type of account(receivable, payable and both)

        Returns a dictionary of accounts with following key and value {
                'code': account code,
                'name': account name,
                'debit': sum of total debit amount,
                'credit': sum of total credit amount,
                'balance': total balance,
                'amount_currency': sum of amount_currency,
                'move_lines': list of move line
        }
        """
        cr = self.env.cr
        move_lines = {x: [] for x in accounts_type.keys()}
        wizard = self.env['account.common.account.report'].browse(self.env.context.get('active_ids'))

        analytic_clu = " "
        if analytic_account_ids:
            analytic_clu = " l.analytic_distribution AS analytic_distribution""" + ','

        # Prepare initial sql query and Get the initial move lines
        if init_balance:
            date_from = datetime.strptime(wizard.date_from, '%Y-%m-%d').date()
            year = date_from.year
            first_year_date = datetime.strptime('%s-01-01' % (year), '%Y-%m-%d')
            context = dict(self.env.context)
            context['date_from'] = first_year_date
            context['date_to'] = date_from
            context['initial_bal'] = True
            if partner_ids:
                context['partner_ids'] = partner_ids
            domain = wizard.with_context(context)._query_get()
            init_tables, init_where_clause, init_where_params = self.env['account.move.line']._where_calc(
                domain).get_sql()

            init_wheres = [""]
            if init_where_clause.strip():
                init_wheres.append(init_where_clause.strip())
            init_filters = " AND ".join(init_wheres)
            filters = init_filters.replace('account_move_line__move_id', 'm').replace('account_move_line', 'l')
            sql = ("""SELECT """ + analytic_clu + """0 AS lid, l.account_type AS user_type_id, l.account_id AS account_id, acc.name AS account_name '' AS ldate, '' AS lcode, NULL AS amount_currency, '' AS lref, 'Initial Balance' AS lname, COALESCE(SUM(l.debit),0.0) AS debit, COALESCE(SUM(l.credit),0.0) AS credit, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit), 0) as balance, '' AS lpartner_id,\
                '' AS move_name, '' AS mmove_id, '' AS currency_code,\
                NULL AS currency_id,\
                '' AS invoice_id, '' AS invoice_type, '' AS invoice_number,\
                '' AS partner_name\
                FROM account_move_line l\
                LEFT JOIN account_move m ON (l.move_id=m.id)\
                LEFT JOIN res_currency c ON (l.currency_id=c.id)\
                LEFT JOIN res_partner p ON (l.partner_id=p.id)\
                JOIN account_journal j ON (l.journal_id=j.id)\
                WHERE l.account_id IN %s""" + filters + ' GROUP BY l.account_type')
            params = (tuple(accounts.ids),) + tuple(init_where_params)
            cr.execute(sql, params)
            for row in cr.dictfetchall():
                move_lines[row.pop('user_type_id')].append(row)

        # Prepare sql query base on selected parameters from wizard
        context = dict(self.env.context)
        # if analytic_account_ids:
        #     context['analytic_account_ids'] = analytic_account_ids
        if partner_ids:
            context['partner_ids'] = partner_ids
        domain = wizard.with_context(context)._query_get()
        tables, where_clause, where_params = self.env['account.move.line']._where_calc(domain).get_sql()
        wheres = [""]
        if where_clause.strip():
            wheres.append(where_clause.strip())
        filters = " AND ".join(wheres)
        filters = filters.replace('account_move_line__move_id', 'm').replace('account_move_line', 'l')

        # Get move lines base on sql query and Calculate the total balance of move lines
        sql = ('''SELECT ''' + analytic_clu + '''l.id AS lid, acc.account_type AS user_type_id,l.account_id AS account_id, acc.name AS account_name, l.date AS ldate, l.currency_id, l.amount_currency, l.ref AS lref, l.name AS lname, COALESCE(l.debit,0) AS debit, COALESCE(l.credit,0) AS credit, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit), 0) AS balance,\
            m.name AS move_name, c.symbol AS currency_code, p.name AS partner_name\
            FROM account_move_line l\
            JOIN account_move m ON (l.move_id=m.id)\
            LEFT JOIN res_currency c ON (l.currency_id=c.id)\
            LEFT JOIN res_partner p ON (l.partner_id=p.id)\
            JOIN account_account acc ON (l.account_id = acc.id) \
            JOIN account_journal j ON (l.journal_id=j.id)\
            WHERE l.account_id IN %s ''' + filters + ''' GROUP BY l.id, l.account_id, acc.account_type, l.date, l.currency_id, l.amount_currency, l.ref, acc.name, l.name, m.name, c.symbol, p.name''')
        params = (tuple(accounts.ids),) + tuple(where_params)
        cr.execute(sql, params)

        for row in cr.dictfetchall():
            if not row['user_type_id'] in move_lines:
                continue
            if analytic_account_ids:
                if row['analytic_distribution']:
                    for acc, perc in row['analytic_distribution'].items():
                        if acc in analytic_account_ids:
                            balance = 0
                            for line in move_lines.get(row['user_type_id']):
                                balance += ((line['debit'] * perc) / 100) - ((line['credit'] * perc) / 100)
                            row['debit'] = (row['debit'] * perc) / 100
                            row['credit'] = (row['credit'] * perc) / 100
                            row['balance'] += balance
                            move_lines[row.pop('user_type_id')].append(row)

            else:
                balance = 0
                for line in move_lines.get(row['user_type_id']):
                    balance += line['debit'] - line['credit']
                row['balance'] += balance
                move_lines[row.pop('user_type_id')].append(row)

        # Calculate the debit, credit and balance for Accounts
        account_res = []
        for account,acc_value in accounts_type.items():
            res = dict((fn, 0.0) for fn in ['credit', 'debit', 'balance'])
            res['name'] = acc_value
            res['move_lines'] = move_lines[account]
            for line in res.get('move_lines'):
                res['debit'] += line['debit']
                res['credit'] += line['credit']
                res['balance'] = line['balance']
            if display_account == 'all':
                account_res.append(res)
            if display_account == 'movement' and res.get('move_lines'):
                account_res.append(res)
            if display_account == 'not_zero' and not res['balance'] != 0.0:
                account_res.append(res)
        return account_res

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get('form') or not self.env.context.get('active_model'):
            raise UserError(_("Form content is missing, this report cannot be printed."))
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_ids', []))
        init_balance = data['form'].get('initial_balance', True)
        display_account = data['form']['display_account']
        domain = []
        account_type = {}
        analytics = []
        analytic_account_ids = False
        if data['form'].get('analytic_account_ids', False):
            analytic_account_ids = self.env['account.analytic.account'].search(
                [('id', 'in', data['form']['analytic_account_ids'])])
            for acc in analytic_account_ids:
                analytics.append(str(acc.id))
            analytics = dict.fromkeys(analytics, 100)

        partner_ids = False
        if data['form'].get('partner_ids', False):
            partner_ids = self.env['res.partner'].search(
                [('id', 'in', data['form']['partner_ids'])])

        if data['form']['main_account']:
            domain += [('account_type', '=', data['form']['main_account'])]

        if data['form']['account_ids']:
            domain += [('id', 'in', data['form']['account_ids'])]

        accounts = self.env['account.account'].search(domain)

        if data['form']['group_by'] == 'account':
            accounts_res = self.with_context(
                data['form'].get('used_context', {}))._get_account_move_entry(
                accounts,
                analytics,
                partner_ids,
                init_balance, display_account)

        else:

            account_type = self.env['account.account']._fields['account_type'].selection
            account_type = dict(account_type)
            accounts_res = self.with_context(data['form'].get('used_context', {}))._get_account_type_move_entry(
                account_type, accounts, partner_ids, init_balance, display_account, analytics,
            )

        return {
            'doc_ids': docids,
            'doc_model': model,
            'data': data['form'],
            'docs': docs,
            'time': time,
            'Accounts': accounts_res,
            'accounts': accounts,
            'partner_ids': partner_ids,
            'analytic_account_ids': analytic_account_ids,
        }

    def generate_xlsx_report(self, workbook, data, moves):
        self = self.with_context(lang=self.env.user.lang)
        # Style
        head = workbook.add_format({'font_size': 14, 'font_name': 'Times New Roman',
                                    'bold': True, 'align': 'center', 'color': '#118aa6'
                                    })
        data_head = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                         'align': 'center', 'bold': True, 'border': 1
                                         })
        sub_heading = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                           'align': 'vcenter', 'bold': True, 'border': 1, 'bg_color': '#C6EAE8',
                                           'color': 'black', 'bottom': True
                                           })
        txt = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                   'border': 1, 'border_color': '#11ff64d9', 'align': 'vcenter'
                                   })
        head_txt = workbook.add_format(
            {'font_size': 12, 'font_name': 'Times New Roman', 'bold': True, 'bg_color': '#C6EAE8',
             'border': 1, 'border_color': '#11ff64d9', 'align': 'vcenter'
             })
        head_numbers = workbook.add_format(
            {'font_size': 10, 'border': 1, 'border_color': '#11ff64d9', 'bold': True, 'bg_color': '#C6EAE8',
             'align': 'vcenter', 'num_format': '#,##0.00'
             })
        numbers = workbook.add_format({'font_size': 10, 'border': 1, 'border_color': '#11ff64d9',
                                       'align': 'vcenter', 'num_format': '#,##0.00'
                                       })
        numbers_total = workbook.add_format({'font_size': 10, 'border': 1, 'border_color': '#11ff64d9',
                                             'align': 'vcenter', 'border': 1, 'bold': True, 'bg_color': '#C6EAE8',
                                             'num_format': '#,##0.00'
                                             })
        # Form Data
        init_balance = data['form'].get('initial_balance', True)
        target_move = data['form'].get('target_move')
        display_account = data['form']['display_account']

        domain = []
        account_type = {}
        analytics = {}
        analytic_account_ids = False
        if data['form']['analytic_account_ids']:
            analytic_account_ids = self.env['account.analytic.account'].search(
                [('id', 'in', data['form']['analytic_account_ids'])])
            for acc in analytic_account_ids:
                analytics = {str(acc.id)}
                analytics = dict.fromkeys(analytics, 100)

        partner_ids = False
        if data['form'].get('partner_ids', False):
            partner_ids = self.env['res.partner'].search(
                [('id', 'in', data['form']['partner_ids'])])

        if data['form']['main_account']:
            domain += [('account_type', '=', data['form']['main_account'])]

        if data['form']['account_ids']:
            domain += [('id', 'in', data['form']['account_ids'])]

        accounts = self.env['account.account'].search(domain)

        if data['form']['group_by'] == 'account':
            accounts_res = self.with_context(
                data['form'].get('used_context', {}))._get_account_move_entry(
                accounts,
                analytics,
                partner_ids,
                init_balance, display_account)

        else:
            account_type = self.env['account.account']._fields['account_type'].selection
            account_type = dict(account_type)

            accounts_res = self.with_context(data['form'].get('used_context', {}))._get_account_type_move_entry(
                account_type, accounts, partner_ids, init_balance, display_account, analytics,
            )

        sheet = workbook.add_worksheet(_('General Ledger'))
        sheet.merge_range('D1:G1', _('General Ledger'), head)

        # report filter
        period = str(data['form']['date_from']) + '  -  ' + str(data['form']['date_to'])
        target_move_name = dict(
            self.env['account.common.account.report'].fields_get(allfields=['target_move'])['target_move'][
                'selection'])[target_move]
        display_account_name = dict(
            self.env['account.common.account.report'].fields_get(allfields=['display_account'])['display_account'][
                'selection'])[display_account]

        sheet.write(3, 1, _('Accounts'), data_head)
        sheet.write(4, 1, display_account_name, data_head)
        sheet.write(3, 2, _('Target Moves'), data_head)
        sheet.write(4, 2, target_move_name, data_head)
        sheet.write(3, 3, _('Period'), data_head)
        sheet.write(4, 3, period, data_head)

        # Table
        row = 6
        for account in accounts_res:
            sheet.merge_range(row, 0, row, 7, account['name'], sub_heading)
            index = 0
            row += 1
            sum_debit = 0.0
            sum_credit = 0.0
            sum_balance = 0.0
            col = 0

            # Table head
            sheet.write(row, col, _('Number'), sub_heading)
            sheet.write(row, col + 1, _('Entry'), sub_heading)
            sheet.write(row, col + 2, _('Date'), sub_heading)
            # sheet.write(row, col+3, _('Account'), sub_heading)
            sheet.write(row, 3, _('Label'), sub_heading)
            sheet.write(row, 4, _('Partner'), sub_heading)
            # sheet.write(row, 6, _('Cost Center'), sub_heading)
            sheet.write(row, 5, _('Debit'), sub_heading)
            sheet.write(row, 6, _('Credit'), sub_heading)
            sheet.write(row, 7, _('Balance'), sub_heading)

            row += 1
            for line in account['move_lines']:
                index += 1
                sheet.write(row, 0, index, txt)
                sheet.write(row, 1, line['move_name'], txt)
                sheet.write(row, 2, str(line.get('ldate').strftime('%B %d, %Y')), txt)
                # sheet.write(row, 3, line['account_name'], txt)
                sheet.write(row, 3, line['lname'], txt)
                sheet.write(row, 4, line['partner_name'], txt)
                # sheet.write(row, 6, line['analytic_name'], txt)
                sheet.write(row, 5, line['debit'], numbers)
                sheet.write(row, 6, line['credit'], numbers)
                sheet.write(row, 7, line['balance'], numbers)
                sum_debit += line['debit']
                sum_credit += line['credit']
                sum_balance += line['balance']

                row += 1
                sum_x = row
            sheet.merge_range(row, 0, row, 4, 'Total', sub_heading)
            sheet.write(sum_x, 5, sum_debit, numbers_total)
            sheet.write(sum_x, 6, sum_credit, numbers_total)
            sheet.write(sum_x, 7, sum_balance, numbers_total)
            row += 3

        # set width  of columns:
        sheet.set_column('A:A', 5)
        sheet.set_column('B:B', 20)
        sheet.set_column('C:C', 20)
        sheet.set_column('D:D', 20)
        sheet.set_column('E:E', 20)
        sheet.set_column('F:F', 15)
        sheet.set_column('G:G', 15)
        sheet.set_column('H:H', 15)
        sheet.set_column('I:I', 15)
        sheet.set_column('J:J', 15)
