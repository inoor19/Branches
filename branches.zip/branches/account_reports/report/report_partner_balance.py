# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

import time
from odoo import api, models, _
from odoo.exceptions import UserError


class ReportPartnerBalance(models.AbstractModel):
    _name = 'report.account_reports.report_partner_balance'
    _inherit = 'report.report_xlsx.abstract'
    _description = 'Partner Balance Report'

    def _sum_partner(self, data, partner, field):
        if field not in ['debit', 'credit', 'debit - credit']:
            return
        result = 0.0
        context = dict(self.env.context)
        wizard = self.env['account.common.account.report'].browse(self.env.context.get('active_ids'))
        domain = wizard.with_context(context)._query_get()
        query_get_data = self.env['account.move.line']._where_calc(domain).get_sql()
        reconcile_clause = "" if data['form']['reconciled'] else ' AND "account_move_line".full_reconcile_id IS NULL '

        params = [partner.id, tuple(data['computed']['move_state']), tuple(data['computed']['account_ids'])] + \
                 query_get_data[2]
        query = """SELECT sum(""" + field + """)
                FROM """ + query_get_data[0] + """, account_move AS m
                WHERE "account_move_line".partner_id = %s
                    AND m.id = "account_move_line".move_id
                    AND m.state IN %s
                    AND account_id IN %s
                    AND """ + query_get_data[1] + reconcile_clause
        self.env.cr.execute(query, tuple(params))

        contemp = self.env.cr.fetchone()
        if contemp is not None:
            result = contemp[0] or 0.0
        return result

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get('form'):
            raise UserError(_("Form content is missing, this report cannot be printed."))
        data['computed'] = {}

        obj_partner = self.env['res.partner']
        context = dict(self.env.context)
        wizard = self.env['account.common.account.report'].browse(self.env.context.get('active_ids'))
        domain = wizard.with_context(context)._query_get()
        query_get_data = self.env['account.move.line']._where_calc(domain).get_sql()
        data['computed']['move_state'] = ['draft', 'posted']
        if data['form'].get('target_move', 'all') == 'posted':
            data['computed']['move_state'] = ['posted']
        result_selection = data['form'].get('result_selection', 'customer')
        if result_selection == 'supplier':
            data['computed']['ACCOUNT_TYPE'] = ['liability_payable']
        elif result_selection == 'customer':
            data['computed']['ACCOUNT_TYPE'] = ['asset_receivable']
        else:
            data['computed']['ACCOUNT_TYPE'] = ['asset_receivable', 'liability_payable']

        self.env.cr.execute("""
            SELECT a.id
            FROM account_account a
            WHERE a.account_type IN %s
            AND NOT a.deprecated""", (tuple(data['computed']['ACCOUNT_TYPE']),))
        data['computed']['account_ids'] = [a for (a,) in self.env.cr.fetchall()]
        params = [tuple(data['computed']['move_state']), tuple(data['computed']['account_ids'])] + query_get_data[2]
        reconcile_clause = "" if data['form']['reconciled'] else ' AND "account_move_line".full_reconcile_id IS NULL '
        query = """
            SELECT DISTINCT "account_move_line".partner_id
            FROM """ + query_get_data[0] + """, account_account AS account, account_move AS am
            WHERE "account_move_line".partner_id IS NOT NULL
                AND "account_move_line".account_id = account.id
                AND am.id = "account_move_line".move_id
                AND am.state IN %s
                AND "account_move_line".account_id IN %s
                AND NOT account.deprecated
                AND """ + query_get_data[1] + reconcile_clause
        self.env.cr.execute(query, tuple(params))
        if data['form']['partner_ids']:
            partner_ids = data['form']['partner_ids']
        else:
            partner_ids = [res['partner_id'] for res in
                           self.env.cr.dictfetchall()]
        partners = obj_partner.browse(partner_ids)
        partners = sorted(partners, key=lambda x: (x.ref or '', x.name or ''))

        return {
            'doc_ids': partner_ids,
            'doc_model': self.env['res.partner'],
            'data': data,
            'docs': partners,
            'time': time,
            'sum_partner': self._sum_partner,
        }


    def generate_xlsx_report(self, workbook, data, moves):
        self = self.with_context(lang=self.env.user.lang)
        # Style
        head = workbook.add_format({'font_size': 14, 'font_name': 'Times New Roman',
                                    'bold': True, 'align': 'center', 'color': '#118aa6'
                                    })
        data_head = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                         'align': 'center', 'bold': True, 'border': 1
                                         })
        sub_heading = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                           'align': 'vcenter', 'bold': True, 'border': 1, 'bg_color': '#C6EAE8',
                                           'color': 'black', 'bottom': True
                                           })
        txt = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                   'border': 1, 'border_color': '#11ff64d9', 'align': 'vcenter'
                                   })
        head_txt = workbook.add_format(
            {'font_size': 12, 'font_name': 'Times New Roman', 'bold': True, 'bg_color': '#C6EAE8',
             'border': 1, 'border_color': '#11ff64d9', 'align': 'vcenter'
             })
        head_numbers = workbook.add_format(
            {'font_size': 10, 'border': 1, 'border_color': '#11ff64d9', 'bold': True, 'bg_color': '#C6EAE8',
             'align': 'vcenter', 'num_format': '#,##0.00'
             })
        numbers = workbook.add_format({'font_size': 10, 'border': 1, 'border_color': '#11ff64d9',
                                       'align': 'vcenter', 'num_format': '#,##0.00'
                                       })
        numbers_total = workbook.add_format({'font_size': 10, 'border': 1, 'border_color': '#11ff64d9',
                                             'align': 'vcenter', 'border': 1, 'bold': True, 'bg_color': '#C6EAE8',
                                             'num_format': '#,##0.00'
                                             })
        # Form Data
        if not data.get('form'):
            raise UserError(_("Form content is missing, this report cannot be printed."))
        data['computed'] = {}

        obj_partner = self.env['res.partner']
        context = dict(self.env.context)
        wizard = self.env['account.common.partner.report'].browse(self.env.context.get('active_ids'))
        domain = wizard.with_context(context)._query_get()
        query_get_data = self.env['account.move.line']._where_calc(domain).get_sql()
        data['computed']['move_state'] = ['draft', 'posted']
        if data['form'].get('target_move', 'all') == 'posted':
            data['computed']['move_state'] = ['posted']
        result_selection = data['form'].get('result_selection', 'customer')
        if result_selection == 'supplier':
            data['computed']['ACCOUNT_TYPE'] = ['liability_payable']
        elif result_selection == 'customer':
            data['computed']['ACCOUNT_TYPE'] = ['asset_receivable']
        else:
            data['computed']['ACCOUNT_TYPE'] = ['asset_receivable', 'liability_payable']

        self.env.cr.execute("""
            SELECT a.id
            FROM account_account a
            WHERE a.account_type IN %s
            AND NOT a.deprecated""", (tuple(data['computed']['ACCOUNT_TYPE']),))
        data['computed']['account_ids'] = [a for (a,) in self.env.cr.fetchall()]
        params = [tuple(data['computed']['move_state']), tuple(data['computed']['account_ids'])] + query_get_data[2]
        reconcile_clause = "" if data['form']['reconciled'] else ' AND "account_move_line".full_reconcile_id IS NULL '
        query = """
            SELECT DISTINCT "account_move_line".partner_id
            FROM """ + query_get_data[0] + """, account_account AS account, account_move AS am
            WHERE "account_move_line".partner_id IS NOT NULL
                AND "account_move_line".account_id = account.id
                AND am.id = "account_move_line".move_id
                AND am.state IN %s
                AND "account_move_line".account_id IN %s
                AND NOT account.deprecated
                AND """ + query_get_data[1] + reconcile_clause
        self.env.cr.execute(query, tuple(params))
        if data['form']['partner_ids']:
            partner_ids = data['form']['partner_ids']
        else:
            partner_ids = [res['partner_id'] for res in
                           self.env.cr.dictfetchall()]
        partners = obj_partner.browse(partner_ids)
        partners = sorted(partners, key=lambda x: (x.ref or '', x.name or ''))

        sum_partner =self._sum_partner
        data = data
        # sheet
        sheet = workbook.add_worksheet(_('Partner Balance'))
        sheet.merge_range('B1:D1', _('Partner Balance'), head)

        target_move = data['form'].get('target_move')
        result_selection = data['form'].get('result_selection')

        # report filter
        period = str(data['form']['date_from']) + '  -  ' + str(data['form']['date_to'])
        target_move_name = \
            dict(self.env['account.common.account.report'].fields_get(allfields=['target_move'])['target_move']['selection'])[
                target_move]
        result_selection_name = \
            dict(self.env['account.common.partner.report'].fields_get(allfields=['result_selection'])['result_selection']['selection'])[
                result_selection]


        sheet.write(2, 0, _('Target Moves'), data_head)
        sheet.write(3, 0, target_move_name, data_head)
        sheet.write(2, 1, _('Partner Selection'), data_head)
        sheet.write(3, 1, result_selection_name, data_head)

        # Table head
        sheet.write(7, 0, _('Partner'), sub_heading)
        sheet.write(7, 1, _('Debit'), sub_heading)
        sheet.write(7, 2, _('Credit'), sub_heading)
        sheet.write(7, 3, _('Balance'), sub_heading)
        sheet.write(7, 3, _('Balance'), sub_heading)

        row = 8
        for p in partners:
            sheet.write(row, 0,p.name, txt)
            sheet.write(row, 1,sum_partner(data, p, 'debit'), numbers)
            sheet.write(row, 2,sum_partner(data, p, 'credit'), numbers)
            sheet.write(row, 3,sum_partner(data, p, 'debit - credit'), numbers)

            row += 1


        # # # set width and height of colmns & rows:
        sheet.set_column('A:A', 25)
        sheet.set_column('B:B', 20)
        sheet.set_column('C:C', 20)
        sheet.set_column('D:D', 20)
        sheet.set_column('E:E', 20)
        sheet.set_column('F:F', 15)
        sheet.set_column('G:G', 15)




