# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
import time
from odoo import api, models, _
from odoo.exceptions import UserError


class ReportTrialBalance(models.AbstractModel):
    _name = 'report.account_reports.report_trialbalance'
    _inherit = 'report.report_xlsx.abstract'
    _description = 'Trial Balance Report'

    def _get_accounts(self, accounts, display_account, analytic_account_ids):
        """ compute the balance, debit and credit for the provided accounts
            :Arguments:
                `accounts`: list of accounts record,
                `display_account`: it's used to display either all accounts or those accounts which balance is > 0
            :Returns a list of dictionary of Accounts with following key and value
                `name`: Account name,
                `code`: Account code,
                `credit`: total amount of credit,
                `debit`: total amount of debit,
                `balance`: total amount of balance,
        """

        account_result = {}
        move_lines = {x: [] for x in accounts.ids}

        # Prepare sql query base on selected parameters from wizard
        context = dict(self.env.context)
        wizard = self.env['account.common.account.report'].browse(self.env.context.get('active_ids'))
        domain = wizard.with_context(context)._query_get()
        tables, where_clause, where_params = self.env['account.move.line']._where_calc(domain).get_sql()
        tables = tables.replace('"', '')
        if not tables:
            tables = 'account_move_line'
        wheres = [""]
        if where_clause.strip():
            wheres.append(where_clause.strip())
        GROUP_BY = " GROUP BY account_id"

        analytic_clu = " "
        if analytic_account_ids:
            analytic_clu = " analytic_distribution AS analytic_distribution""" + ','
            GROUP_BY += ", analytic_distribution "

        filters = " AND ".join(wheres)

        # compute the balance, debit and credit for the provided accounts
        request = ("SELECT " + analytic_clu + " account_id AS id, SUM(debit) AS debit, SUM(credit) AS credit, "
                                              "(SUM(debit) - SUM(credit)) AS balance" + \
                   " FROM " + tables + " WHERE account_id IN %s " + filters + GROUP_BY)
        params = (tuple(accounts.ids),) + tuple(where_params)
        self.env.cr.execute(request, params)
        for row in self.env.cr.dictfetchall():
            if analytic_account_ids:
                if row['analytic_distribution']:
                    for acc, perc in row['analytic_distribution'].items():
                        if acc in analytic_account_ids:
                            move_lines[row.pop('id')].append(row)
                            row['debit'] = (row['debit'] * perc) / 100
                            row['credit'] = (row['credit'] * perc) / 100
                            row['balance'] = (row['balance'] * perc) / 100



            else:
                move_lines[row.pop('id')].append(row)

        account_res = []
        for account in accounts:
            res = dict((fn, 0.0) for fn in ['credit', 'debit', 'balance'])
            currency = self.env.user.company_id.currency_id
            res['code'] = account.code
            res['name'] = account.name
            res['move_lines'] = move_lines[account.id]
            for line in res.get('move_lines'):
                res['debit'] += line['debit']
                res['credit'] += line['credit']
                res['balance'] += line['balance']

            if display_account == 'all':
                account_res.append(res)
            if display_account == 'not_zero' and not currency.is_zero(res['balance']):
                account_res.append(res)
            if display_account == 'movement' and (
                    not currency.is_zero(res['debit']) or not currency.is_zero(res['credit'])):
                account_res.append(res)
        return account_res

    def _get_accounts_types(self, accounts_types, accounts, display_account, analytic_account_ids):
        if not accounts:
            raise UserError(_("No Accounts Found For The Accounts Types."))
        cr = self.env.cr
        MoveLine = self.env['account.move.line']
        move_lines = {x: [] for x in accounts_types.keys()}
        context = dict(self.env.context)
        wizard = self.env['account.common.account.report'].browse(self.env.context.get('active_ids'))
        domain = wizard.with_context(context)._query_get()
        tables, where_clause, where_params = self.env['account.move.line']._where_calc(domain).get_sql()
        wheres = [""]
        if where_clause.strip():
            wheres.append(where_clause.strip())
        filters = " AND ".join(wheres)
        filters = filters.replace('account_move_line__move_id', 'm').replace('account_move_line', 'l')
        analytic_clu = " "
        GROUP_BY1 = " GROUP BY acc.account_type,l.account_id,acc.name,acc.code"

        if analytic_account_ids:
            analytic_clu = " l.analytic_distribution AS analytic_distribution""" + ','
            GROUP_BY1 += ", l.analytic_distribution "

        # compute the balance, debit and credit for the provided accounts
        request = (
                "SELECT " + analytic_clu + " acc.account_type AS user_type_id, l.account_id AS account_id,acc.name As name,acc.code As code, SUM(l.debit) AS debit, SUM(l.credit) AS credit, (SUM(l.debit) - SUM(l.credit)) AS balance FROM account_move_line l LEFT JOIN account_move m ON (l.move_id=m.id) LEFT JOIN account_account acc ON (l.account_id = acc.id) WHERE l.account_id IN %s " + filters + GROUP_BY1)
        params = (tuple(accounts.ids),) + tuple(where_params)
        self.env.cr.execute(request, params)
        for row in self.env.cr.dictfetchall():
            if analytic_account_ids:
                if row['analytic_distribution']:
                    for acc, perc in row['analytic_distribution'].items():
                        if acc in analytic_account_ids:
                            move_lines[row.pop('user_type_id')].append(row)
                            row['debit'] = (row['debit'] * perc) / 100
                            row['credit'] = (row['credit'] * perc) / 100
                            row['balance'] = (row['balance'] * perc) / 100



            else:
                move_lines[row.pop('user_type_id')].append(row)

        account_res = []
        for account, acc_value in accounts_types.items():
            res = dict((fn, 0.0) for fn in ['credit', 'debit', 'balance'])
            currency = self.env.user.company_id.currency_id
            res['name'] = acc_value
            res['move_lines'] = move_lines[account]
            for line in res.get('move_lines'):
                res['debit'] += line['debit']
                res['credit'] += line['credit']
                res['balance'] += line['balance']

            if display_account == 'all':
                account_res.append(res)
            if display_account == 'not_zero' and not currency.is_zero(res['balance']):
                account_res.append(res)
            if display_account == 'movement' and (
                    not currency.is_zero(res['debit']) or not currency.is_zero(res['credit'])):
                account_res.append(res)
        return account_res

    def _get_account_type_move_entry(self, accounts_types, accounts, display_account, analytic_account_ids):
        if not accounts:
            raise UserError(_("No Accounts Found For The Accounts Types."))
        cr = self.env.cr
        MoveLine = self.env['account.move.line']
        move_lines = {x: [] for x in accounts_types.keys()}
        move_lines2 = {x: [] for x in accounts_types.keys()}
        context = dict(self.env.context)
        wizard = self.env['account.common.account.report'].browse(self.env.context.get('active_ids'))
        domain = wizard.with_context(context)._query_get()
        tables, where_clause, where_params = self.env['account.move.line']._where_calc(domain).get_sql()
        wheres = [""]
        if where_clause.strip():
            wheres.append(where_clause.strip())
        filters = " AND ".join(wheres)
        filters = filters.replace('account_move_line__move_id', 'm').replace('account_move_line', 'l')
        analytic_clu = " "
        GROUP_BY1 = " GROUP BY acc.account_type,l.account_id,acc.name,acc.code"
        GROUP_BY2 = " GROUP BY acc.account_type,l.partner_id,p.name"

        if analytic_account_ids:
            analytic_clu = " l.analytic_distribution AS analytic_distribution""" + ','
            GROUP_BY1 += ", l.analytic_distribution "
            GROUP_BY2 += ", l.analytic_distribution "

        # compute the balance, debit and credit for the provided accounts
        request = (
                "SELECT " + analytic_clu + " acc.account_type AS user_type_id, l.account_id AS account_id,acc.name As name,acc.code As code, SUM(l.debit) AS debit, SUM(l.credit) AS credit, (SUM(l.debit) - SUM(l.credit)) AS balance FROM account_move_line l LEFT JOIN account_move m ON (l.move_id=m.id) LEFT JOIN account_account acc ON (l.account_id = acc.id) WHERE l.account_id IN %s " + filters + GROUP_BY1)
        params = (tuple(accounts.ids),) + tuple(where_params)
        self.env.cr.execute(request, params)

        for row in self.env.cr.dictfetchall():
            if analytic_account_ids:
                if row['analytic_distribution']:
                    for acc, perc in row['analytic_distribution'].items():
                        if acc in analytic_account_ids:
                            move_lines[row.pop('user_type_id')].append(row)
                            row['debit'] = (row['debit'] * perc) / 100
                            row['credit'] = (row['credit'] * perc) / 100
                            row['balance'] = (row['balance'] * perc) / 100

            else:
                move_lines[row.pop('user_type_id')].append(row)

        request2 = (
                "SELECT " + analytic_clu + "acc.account_type AS user_type_id, l.partner_id AS account_id,p.name As name, SUM(l.debit) AS debit, SUM(l.credit) AS credit, (SUM(l.debit) - SUM(l.credit)) AS balance FROM account_move_line l LEFT JOIN account_move m ON (l.move_id=m.id) LEFT JOIN res_partner p ON (l.partner_id=p.id) LEFT JOIN account_account acc ON (l.account_id = acc.id) WHERE l.account_id IN %s " + filters + GROUP_BY2)
        params = (tuple(accounts.ids),) + tuple(where_params)
        self.env.cr.execute(request2, params)

        for row in self.env.cr.dictfetchall():
            if analytic_account_ids:
                if row['analytic_distribution']:
                    for acc, perc in row['analytic_distribution'].items():
                        if acc in analytic_account_ids:
                            move_lines2[row.pop('user_type_id')].append(row)
                            row['debit'] = (row['debit'] * perc) / 100
                            row['credit'] = (row['credit'] * perc) / 100
                            row['balance'] = (row['balance'] * perc) / 100
            else:
                move_lines2[row.pop('user_type_id')].append(row)

        account_res = []
        for account, acc_value in accounts_types.items():
            res = dict((fn, 0.0) for fn in ['credit', 'debit', 'balance'])
            currency = self.env.user.company_id.currency_id
            # res['code'] = account.code
            res['name'] = acc_value
            res['move_lines'] = move_lines[account]
            for line in res.get('move_lines'):
                res['debit'] += line['debit']
                res['credit'] += line['credit']
                res['balance'] += line['balance']

            if display_account == 'all':
                account_res.append(res)
            if display_account == 'not_zero' and not currency.is_zero(res['balance']):
                account_res.append(res)
            if display_account == 'movement' and (
                    not currency.is_zero(res['debit']) or not currency.is_zero(res['credit'])):
                account_res.append(res)

        return account_res

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get('form') or not self.env.context.get('active_model'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_ids', []))
        display_account = data['form'].get('display_account')
        report_type = data['form'].get('report_type')
        context = data['form'].get('used_context')
        account_type = {}
        analytics = []
        domain = []
        analytic_accounts = []


        if data['form'].get('analytic_account_ids', False):
            analytic_account_ids = self.env['account.analytic.account'].search(
                [('id', 'in', data['form']['analytic_account_ids'])])
            analytic_accounts = [account.name for account in analytic_account_ids]
            for acc in analytic_account_ids:
                analytics.append(str(acc.id))
            analytics = dict.fromkeys(analytics, 100)

        account_res = []
        if data['form']['main_account']:
            domain += [('account_type', '=', data['form']['main_account'])]

        if data['form']['account_ids']:
            domain += [('id', 'in', data['form']['account_ids'])]
        accounts = self.env['account.account'].search(domain)

        account_type = self.env['account.account']._fields['account_type'].selection
        account_type = dict(account_type)
        if not accounts:
            raise UserError(_("No Accounts Found! Please Add One"))
        if report_type == 'account':
            account_res = self.with_context(data['form'].get('used_context'))._get_accounts(accounts, display_account,
                                                                                            analytics)
        elif report_type == 'account_type':
            account_res = self.with_context(data['form'].get('used_context'))._get_accounts_types(
                account_type, accounts, display_account, analytics)

        elif report_type == 'detail':
            account_res = self.with_context(data['form'].get('used_context'))._get_account_type_move_entry(
                account_type, accounts, display_account, analytics)

        debit_total = sum(x['debit'] for x in account_res)
        credit_total = sum(x['credit'] for x in account_res)
        balance_total = sum(x['balance'] for x in account_res)

        return {
            'doc_ids': self.ids,
            'doc_model': model,
            'data': data['form'],
            'docs': docs,
            'analytic_accounts': analytic_accounts,
            'time': time,
            'Accounts': account_res,
            'debit_total': debit_total,
            'credit_total': credit_total,
            'balance_total': balance_total,
        }

    def generate_xlsx_report(self, workbook, data, moves):
        self = self.with_context(lang=self.env.user.lang)
        # Style
        head = workbook.add_format({'font_size': 14, 'font_name': 'Times New Roman',
                                    'bold': True, 'align': 'center', 'color': '#118aa6'
                                    })
        data_head = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                         'align': 'center', 'bold': True, 'border': 1
                                         })
        sub_heading = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                           'align': 'vcenter', 'bold': True, 'border': 1, 'bg_color': '#C6EAE8',
                                           'color': 'black', 'bottom': True
                                           })
        txt = workbook.add_format({'font_size': 12, 'font_name': 'Times New Roman',
                                   'border': 1, 'border_color': '#11ff64d9', 'align': 'vcenter'
                                   })
        head_txt = workbook.add_format(
            {'font_size': 12, 'font_name': 'Times New Roman', 'bold': True, 'bg_color': '#C6EAE8',
             'border': 1, 'border_color': '#11ff64d9', 'align': 'vcenter'
             })
        head_numbers = workbook.add_format(
            {'font_size': 10, 'border': 1, 'border_color': '#11ff64d9', 'bold': True, 'bg_color': '#C6EAE8',
             'align': 'vcenter', 'num_format': '#,##0.00'
             })
        numbers = workbook.add_format({'font_size': 10, 'border': 1, 'border_color': '#11ff64d9',
                                       'align': 'vcenter', 'num_format': '#,##0.00'
                                       })
        numbers_total = workbook.add_format({'font_size': 10, 'border': 1, 'border_color': '#11ff64d9',
                                             'align': 'vcenter', 'border': 1, 'bold': True, 'bg_color': '#C6EAE8',
                                             'num_format': '#,##0.00'
                                             })
        # Form Data
        display_account = data['form'].get('display_account')
        report_type = data['form'].get('report_type')
        target_move = data['form'].get('target_move')
        main_account = data['form'].get('main_account')


        if not self.env.context.get('active_model'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_ids', []))
        accounts_type = {}
        analytics = []
        domain = []


        analytic_accounts = []
        if data['form'].get('analytic_account_ids', False):
            analytic_account_ids = self.env['account.analytic.account'].search(
                [('id', 'in', data['form']['analytic_account_ids'])])
            analytic_accounts = [account.name for account in analytic_account_ids]
            for acc in analytic_account_ids:
                analytics.append(str(acc.id))
            analytics = dict.fromkeys(analytics, 100)

        account_res = []
        if data['form']['main_account']:
            domain += [('account_type', '=', data['form']['main_account'])]

        if data['form']['account_ids']:
            domain += [('id', 'in', data['form']['account_ids'])]
        accounts = self.env['account.account'].search(domain)

        account_type = self.env['account.account']._fields['account_type'].selection
        account_type = dict(account_type)
        if not accounts:
            raise UserError(_("No Accounts Found! Please Add One"))
        if report_type == 'account':
            account_res = self.with_context(data['form'].get('used_context'))._get_accounts(accounts, display_account,
                                                                                            analytics)
        elif report_type == 'account_type':
            account_res = self.with_context(data['form'].get('used_context'))._get_accounts_types(
                account_type, accounts, display_account, analytics)

        elif report_type == 'detail':
            account_res = self.with_context(data['form'].get('used_context'))._get_account_type_move_entry(
                account_type, accounts, display_account, analytics)

        debit_total = sum(x['debit'] for x in account_res)
        credit_total = sum(x['credit'] for x in account_res)
        balance_total = sum(x['balance'] for x in account_res)
        # sheet
        sheet = workbook.add_worksheet(_('Trail Balance'))
        sheet.merge_range('B1:D1', _('Trail Balance'), head)

        # report filter
        period = str(data['form']['date_from']) + '  -  ' + str(data['form']['date_to'])
        target_move_name = \
            dict(self.env['account.common.account.report'].fields_get(allfields=['target_move'])['target_move']['selection'])[
                target_move]
        report_type_name = \
            dict(self.env['account.common.account.report'].fields_get(allfields=['report_type'])['report_type']['selection'])[
                report_type]
        if moves.main_account:
            account_type_name = \
                dict(self.env['account.common.account.report'].fields_get(allfields=['main_account'])['main_account']['selection'])[
                    main_account]


        sheet.write(2, 0, _('Report Type'), data_head)
        sheet.write(3, 0, report_type_name, data_head)
        sheet.write(2, 1, _('Target Moves'), data_head)
        sheet.write(3, 1, target_move_name, data_head)
        sheet.write(2, 2, _('Period'), data_head)
        sheet.write(3, 2, period, data_head)
        if moves.main_account:
            sheet.write(5, 0, _('Account Type'), data_head)
            sheet.write(5, 1,account_type_name, data_head)

        # Table head
        sheet.write(7, 0, _('Account'), sub_heading)
        sheet.write(7, 1, _('Debit'), sub_heading)
        sheet.write(7, 2, _('Credit'), sub_heading)
        sheet.write(7, 3, _('Balance'), sub_heading)
        row = 8
        for line in account_res:
            if report_type != 'detail':

                sheet.write(row, 0, line['name'], txt)
                sheet.write(row, 1, line['debit'], numbers)
                sheet.write(row, 2, line['credit'], numbers)
                sheet.write(row, 3, line['balance'], numbers)
            else:

                sheet.write(row, 0, line['name'], head_txt)
                sheet.write(row, 1, line['debit'], head_numbers)
                sheet.write(row, 2, line['credit'], head_numbers)
                sheet.write(row, 3, line['balance'], head_numbers)

                row_detailed = row + 1
                for rec in line['move_lines']:
                    sheet.write(row_detailed, 0, rec['name'], txt)
                    sheet.write(row_detailed, 1, rec['debit'], numbers)
                    sheet.write(row_detailed, 2, rec['credit'], numbers)
                    sheet.write(row_detailed, 3, rec['balance'], numbers)
                    row_detailed += 1
                    row += 1
                row += 1

            row += 1

        if report_type != 'detail':
            sheet.write(row, 0, 'Total', sub_heading)
            sheet.write(row, 1, debit_total, numbers_total)
            sheet.write(row, 2, credit_total, numbers_total)
            sheet.write(row, 3, balance_total, numbers_total)

        # # # set width and height of colmns & rows:
        sheet.set_column('A:A', 25)
        sheet.set_column('B:B', 20)
        sheet.set_column('C:C', 20)
        sheet.set_column('D:D', 20)
        sheet.set_column('E:E', 20)
        sheet.set_column('F:F', 15)
        sheet.set_column('G:G', 15)
