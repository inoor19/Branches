# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, models, _
from odoo.exceptions import UserError


class ReportJournalEntry(models.AbstractModel):
    _name = 'report.account_reports.report_journal_entries'
    _inherit = 'report.report_xlsx.abstract'
    _description = 'Journal Entry Xlsx Report'

    def get_analytic(self, line_id):
        analytics = []
        items = ""
        if line_id.analytic_distribution:
            for acc in line_id.analytic_distribution:
                analytics.append(acc)
            if analytics:
                for analytic in self.env['account.analytic.account'].search(
                        [('id', 'in', analytics)]):
                    items += str(analytic.name) + "\n"
            return items

    @api.model
    def _get_report_values(self, docids, data=None):
        if not self.env.context.get('active_model'):
            raise UserError(_("Form content is missing, this report cannot be printed."))
        cols = 0
        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_ids', []))
        if self.env.user.has_group('analytic.group_analytic_accounting'):
            cols = 4
        else:
            cols = 3
        return {
            'docs': docs,
            'get_analytic': self.get_analytic,
            'colspan': cols,
        }

    def generate_xlsx_report(self, workbook, data, moves):
        self = self.with_context(lang=self.env.user.lang)
        accounts_res = []
        if not self.env.context.get('active_model'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_ids', []))

        format1 = workbook.add_format(
            {'font_size': 12, 'font_name': 'Times New Roman', 'align': 'vcenter', 'bold': True, 'border': 1,
             'bg_color': '#d2ecfa', 'color': 'black',
             'bottom': True, })
        format_title = workbook.add_format(
            {'font_size': 14, 'font_name': 'Times New Roman', 'align': 'center', 'bold': True, 'color': 'black',
             })
        format2 = workbook.add_format(
            {'font_size': 12, 'font_name': 'Times New Roman', 'align': 'vcenter', 'border': 1, 'bold': True,
             'bg_color': '#d2ecfa', 'color': 'black',
             'num_format': '#,##0.00'})
        format5 = workbook.add_format({'font_size': 11, 'align': 'vcenter', 'border': 1, 'bold': False})
        number_format = workbook.add_format(
            {'font_size': 11, 'align': 'vcenter', 'border': 1, 'bold': False, 'num_format': '#,##0.00'})

        for rec in docs:
            sheet = workbook.add_worksheet(rec.name)
            sheet.merge_range('C1:E1', _('Journal Entry'), format_title)
            sheet.merge_range('A3:B3', rec.name, format_title)

            sheet.write(5, 0, _('Journal'), format1)
            sheet.write(6, 0, rec.journal_id.name, format5)
            sheet.write(5, 1, _('Date'), format1)
            sheet.write(6, 1, rec.date.strftime('%B %d, %Y'), format5)
            sheet.write(5, 2, _('Reference'), format1)
            sheet.write(6, 2, rec.ref, format5)

            row = 8
            sum_debit = 0.0
            sum_credit = 0.0

            sheet.write(row, 0, _('Account'), format1)
            sheet.write(row, 1, _('Date'), format1)
            sheet.write(row, 2, _('Partner'), format1)
            sheet.write(row, 3, _('Label'), format1)
            # sheet.write(row, 4, _('Analytic Account'), format1)
            sheet.write(row, 4, _('Debit'), format1)
            sheet.write(row, 5, _('Credit'), format1)

            row += 1

            for line in rec.line_ids:
                sheet.write(row, 0, line.account_id.name, format5)
                sheet.write(row, 1, line.date.strftime('%B %d, %Y'), format5)
                sheet.write(row, 2, line.partner_id.name, format5)
                sheet.write(row, 3, line.name, format5)
                # sheet.write(row, 4, line.analytic_account_id.name, format5)
                sheet.write(row, 4, line.debit, number_format)
                sheet.write(row, 5, line.credit, number_format)
                sum_debit += line.debit
                sum_credit += line.credit

                row += 1
                sum_x = row

            sheet.write(sum_x, 4, sum_debit, format2)
            sheet.write(sum_x, 5, sum_credit, format2)

            # set width  of columns:
            sheet.set_column('A:A', 15)
            sheet.set_column('B:B', 20)
            sheet.set_column('C:C', 20)
            sheet.set_column('D:D', 20)
            sheet.set_column('E:E', 20)
            sheet.set_column('F:F', 15)
            sheet.set_column('G:G', 15)
            sheet.set_column('H:H', 15)
            sheet.set_column('I:I', 15)
            sheet.set_column('J:J', 15)
