# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import date


class AccountCommonAccountReport(models.TransientModel):
    _name = 'account.common.account.report'
    _inherit = "account.common.report"
    _description = 'Account Common Account Report'

    display_account = fields.Selection([('all', 'All'),
                                        ('movement', 'With movements'),
                                        ('not_zero', 'With balance is not equal to 0'), ],
                                       string='Display Accounts',
                                       required=True, default='movement')
    analytic_account_ids = fields.Many2many('account.analytic.account',
                                            string='Analytic Accounts')
    account_ids = fields.Many2many('account.account', string='Accounts')
    partner_ids = fields.Many2many('res.partner', string='Partners')
    amount_currency = fields.Boolean("With Currency",
                                     help="It adds the currency column on "
                                          "report if the currency differs from "
                                          "the company currency.")
    sortby = fields.Selection([('sort_date', 'Date'),
                               ('sort_journal_partner', 'Journal & Partner')],
                              string='Sort by', default='sort_date')

    landscape = fields.Boolean(string="Landscape")
    date_from = fields.Date(default=lambda self: self.env.user.company_id.account_opening_date)
    date_to = fields.Date(default=lambda self: date(self.env.user.company_id.account_opening_date.year, 12, 31))
    initial_balance = fields.Boolean(string='Include Initial Balances',
                                     help='If you selected date, this field allow'
                                          ' you to add a row to display the amount '
                                          'of debit/credit/balance that precedes'
                                          ' the filter you\'ve set.')

    select_report = fields.Selection(
        selection=[
            ("general", "General ledger"),
            ("trail", "Trail Balance"),
            ("statement", "Account Statement")],
        default='general', required=True,
        string="Select Report")

    # gl filters
    main_account = fields.Selection(
        selection=[
            ("asset_receivable", "Receivable"),
            ("asset_cash", "Bank and Cash"),
            ("asset_current", "Current Assets"),
            ("asset_non_current", "Non-current Assets"),
            ("asset_prepayments", "Prepayments"),
            ("asset_fixed", "Fixed Assets"),
            ("liability_payable", "Payable"),
            ("liability_credit_card", "Credit Card"),
            ("liability_current", "Current Liabilities"),
            ("liability_non_current", "Non-current Liabilities"),
            ("equity", "Equity"),
            ("equity_unaffected", "Current Year Earnings"),
            ("income", "Income"),
            ("income_other", "Other Income"),
            ("expense", "Expenses"),
            ("expense_depreciation", "Depreciation"),
            ("expense_direct_cost", "Cost of Revenue"),
            ("off_balance", "Off-Balance Sheet"),
        ],
        string="Type")
    group_by = fields.Selection([('account', 'Accounts'), ('account_type', 'Main Accounts'), ], 'Group by',
                                required=True, default='account')

    # trail fields
    report_type = fields.Selection([
        ('account', 'Accounts'),
        ('account_type', 'Main Accounts'),
        ('detail', 'Details')

    ], 'Report Type', default='account')


    @api.constrains('date_from', 'date_to')
    def _check_date_validity(self):
        """ verifies if date_from is earlier than date_to. """
        for rec in self:
            if rec.date_from and rec.date_to:
                if rec.date_to < rec.date_from:
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))

    @api.onchange('main_account')
    def onchange_main_account(self):
        self.account_ids = False
        self.analytic_account_ids = False
        if self.main_account:
            self.account_ids = self.env['account.account'].search([('account_type', '=', self.main_account)])

    def pre_print_report(self, data):
        if data['form'].get('initial_balance') and not data['form'].get('date_from'):
            raise UserError(_("You must define a Start Date"))
        data['form'].update(self.read(['display_account'])[0])
        data['form'].update({
            'select_report': self.select_report,
            'analytic_account_ids': self.analytic_account_ids.ids,
            'partner_ids': self.partner_ids.ids,
            'account_ids': self.account_ids.ids,
            'amount_currency': self.amount_currency,
            'sortby': self.sortby,
            'landscape': self.landscape,
            'initial_balance': self.initial_balance,
            'main_account': self.main_account,
            'group_by': self.group_by,
            'report_type': self.report_type,

        })
        records = self.env[data['model']].browse(data.get('ids', []))
        return records, data

    def _print_report(self, data):
        records, data = self.pre_print_report(data)
        if data['form']['select_report'] == 'general':
            return self.env.ref('account_reports.action_report_general_ledger').with_context(
                landscape=self.landscape).report_action(
                records, data=data)

        if data['form']['select_report'] == 'trail':
            return self.env.ref('account_reports.action_report_trial_balance').with_context(
                landscape=self.landscape).report_action(
                records, data=data)

        if data['form']['select_report'] == 'statement':
            return self.env.ref('account_reports.action_report_account_statement').with_context(
                landscape=self.landscape).report_action(
                records, data=data)

    def print_xlsx(self):
        data = {'form': {'used_context': {'journal_ids': False,
                                          'state': self.target_move,
                                          'date_from': self.date_from,
                                          'date_to': self.date_to,
                                          'strict_range': True,
                                          'company_id': self.env.user.company_id.id,
                                          'lang': self.env.user.lang}}}
        data['form'].update(self.read(['initial_balance',
                                       'main_account',
                                       'group_by',
                                       'account_ids',
                                       'analytic_account_ids',
                                       'target_move',
                                       'date_from',
                                       'date_to',
                                       'journal_ids',
                                       'display_account',
                                       'amount_currency',
                                       'report_type',
                                       'select_report',
                                       ])[0])
        if data['form']['select_report'] == 'general':
            return self.env.ref('account_reports.action_report_general_ledger_xlsx').with_context(
                landscape=self.landscape).report_action(
                self, data=data)

        if data['form']['select_report'] == 'trail':
            return self.env.ref('account_reports.action_report_trial_xlsx_balance').with_context(
                landscape=self.landscape).report_action(
                self, data=data)

        if data['form']['select_report'] == 'statement':
            return self.env.ref('account_reports.action_account_statement_xlsx_report').with_context(
                landscape=self.landscape).report_action(
                self, data=data)
