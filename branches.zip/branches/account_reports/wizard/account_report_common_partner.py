# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import fields, models
from datetime import date


class AccountingCommonPartnerReport(models.TransientModel):
    _name = 'account.common.partner.report'
    _inherit = "account.common.report"
    _description = 'Account Common Partner Report'

    result_selection = fields.Selection([('customer', 'Receivable Accounts'),
                                         ('supplier', 'Payable Accounts'),
                                         ('customer_supplier', 'Receivable and Payable Accounts')
                                         ], string="Partner's", required=True, default='customer')
    partner_ids = fields.Many2many('res.partner', string='Partners')
    select_partner_report = fields.Selection(
        selection=[
            ("ledger", "Partner ledger"),
            ("balance", "Partner Balance")],
        default='ledger', required=True,
        string="Select Report")
    landscape = fields.Boolean(string="Landscape")


    # ledger fields
    amount_currency = fields.Boolean("With Currency",
                                     help="It adds the currency column on "
                                          "report if the currency differs from "
                                          "the company currency.")
    reconciled = fields.Boolean('Reconciled Entries')
    date_from = fields.Date(default=lambda self: self.env.user.company_id.account_opening_date)
    date_to = fields.Date(default=lambda self: date(self.env.user.company_id.account_opening_date.year, 12, 31))

    def pre_print_report(self, data):
        data['form'].update(self.read(['result_selection'])[0])
        data['form'].update({'reconciled': self.reconciled,
                             'amount_currency': self.amount_currency,
                             'partner_ids': self.partner_ids.ids,
                             'select_partner_report': self.select_partner_report,

                             })
        return data

    def _print_report(self, data):
        data = self.pre_print_report(data)
        if data['form']['select_partner_report'] == 'ledger':
            return self.env.ref('account_reports.action_report_partnerledger').with_context(
                landscape=self.landscape).report_action(self, data=data)

        if data['form']['select_partner_report'] == 'balance':
            return self.env.ref('account_reports.action_report_partner_balance').with_context(
                landscape=self.landscape).report_action(self, data=data)

    def print_xlsx(self):
        data = {'form': {'used_context': {'journal_ids': False,
                                          'state': self.target_move,
                                          'date_from': self.date_from,
                                          'date_to': self.date_to,
                                          'strict_range': True,
                                          'company_id': self.env.user.company_id.id,
                                          'lang': self.env.user.lang}}}
        data['form'].update(self.read([
            'target_move',
            'date_from',
            'date_to',
            'journal_ids',
            'amount_currency',
            'partner_ids',
            'select_partner_report',
            'reconciled',
            'result_selection',
            'select_partner_report',
            'landscape'

        ])[0])
        if data['form']['select_partner_report'] == 'ledger':
            return self.env.ref('account_reports.action_report_partnerledger_xlsx').with_context(
                landscape=self.landscape).report_action(
                self, data=data)

        if data['form']['select_partner_report'] == 'balance':
            return self.env.ref('account_reports.action_report_partner_balance_xlsx').with_context(
                landscape=self.landscape).report_action(
                self, data=data)
