# -*- coding: utf-8 -*-
from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, exceptions, _
from datetime import datetime
import calendar


class HrMainEmployeeInformation(models.TransientModel):
    _name = 'hr.employee.information'

    job_ids = fields.Many2many('hr.job', string="Jobs")
    department_ids = fields.Many2many('hr.department', string="Departments")
    level_ids = fields.Many2many('hr.payroll.structure', string="Levels",domain=[('type','=','level')])
    degree_ids = fields.Many2many('hr.payroll.structure', string="Degrees",domain=[('type','=','grade')])
    #degr_ids = fields.Many2many('hr.payroll.structure', string="Gradees",domain=[('type','=','degree')])
    service = fields.Selection([('in', 'In Service'), ('out', 'Out of Service')],string="Type")
    with_child = fields.Boolean('With Child')
    view_dates = fields.Boolean('View Dates')

    def print_report(self):
        """
        Call Abstract Model To Generate Report and pass the data
        :return:report
        """
        departes = self.department_ids
        if self.with_child:
           tuple_department_ids = tuple(self.department_ids.mapped('id'))
           departes = self.env['hr.department'].search([('id', 'child_of', tuple_department_ids)])
        datas = {
            'ids': [],
            'model': 'hr.employee',
            'service': self.service,
            'job': self.job_ids.mapped('id'),
            'department': departes.mapped('id'),
            'level': self.level_ids.mapped('id'),
            'degree': self.degree_ids.mapped('id'),
            #'grade': self.degr_ids.mapped('id'),
            'view_dates': self.view_dates,

        }
        return self.env.ref('hr_payroll_custom.hr_report_informatio_action').report_action(self, data=datas)


class HrMainEmployeeInformationReport(models.AbstractModel):
    _name = 'report.hr_payroll_custom.hr_report_informatio_report'

    @api.model
    def get_report_values(self, docids, data):
        
        state_condition = ''
        job_condition = ''
        department_condition = ''
        level_condition = ''
        degree_condition = ''
        if data['service']:
           if data['service'] == 'in' :
              state_condition = ' AND employee.state =\'approved\' '
           elif data['service'] == 'out' :
              state_condition = ' AND employee.state =\'refuse\' '
        if data['job']:
           data['job'] = str(data['job']).replace(']','')
           data['job'] = str(data['job']).replace('[','')
           job_condition = ' AND employee.job_id IN ('+data['job']+')'
        if data['department']:
           data['department'] = str(data['department']).replace(']','')
           data['department'] = str(data['department']).replace('[','')
           department_condition = ' AND employee.department_id IN ('+data['department']+')'
        if data['level']:
           data['level'] = str(data['level']).replace(']','')
           data['level'] = str(data['level']).replace('[','')
           level_condition = ' AND employee.level_id IN ('+data['level']+')'
        if data['degree']:
           data['degree'] = str(data['degree']).replace(']','')
           data['degree'] = str(data['degree']).replace('[','')
           degree_condition = ' AND employee.grade_id IN ('+data['grade']+')'
        if data.get('view_dates',False):
            state_condition = ' AND employee.state !=\'refuse\' '

        self._cr.execute(""" select  employee.id, employee.emp_code,employee.name,employee.birthday,employee.mobile_phone,
                                employee.work_location, employee.marital,
                                employee.job_join_date, employee.first_employement_date, employee.start_date
                                , job.name job, level.name levels ,grade.name grade ,
                                degree.name degree,
                                depart.name department from  hr_employee employee 
                                join hr_job job on job.id = employee.job_id join hr_department depart on 
                                 depart.id = employee.department_id  join hr_payroll_structure level on level.id = employee.level_id 
                                 join hr_payroll_structure grade on grade.id = employee.grade_id 
                                 join hr_contract contract on employee.id = contract.employee_id 
                                 join hr_payroll_structure degree on degree.id = contract.degree_id 
                                where employee.active = True """ + str(state_condition) + str(job_condition) + department_condition + level_condition + degree_condition )

        docs = self._cr.dictfetchall()
        if data.get('view_dates',False):
            for g in docs:
                emp = self.env['hr.employee'].browse(g['id'])
                g['qualify'] = {f.degree_id.sequence:[f.degree_id.name,f.specialt_id.name] for f in emp.qualification_ids}

        if len(docs) == 0:
            raise exceptions.ValidationError(_('There is no Information'))
        date = datetime.strftime(datetime.today(), '%Y-%m-%d')
        docargs = {
            'doc_ids': self.ids,
            'doc_model': 'hr.employee',
            'docs': docs,
            'date': date,
            'view_dates':data.get('view_dates',False),

        }
        return docargs

############################################ Salary Adjisment Report ###################################################



class BankStatement(models.TransientModel):
    _name = "employee.bank.statement"

    year = fields.Selection([(num, str(num)) for num in range(datetime.now().year, datetime.now().year - 10, -1)],
                            string="year", default=datetime.now().year, required=True)
    months = fields.Selection([(num, str(calendar.month_name[num])) for num in range(1, 12 + 1)], string="month",
                              default=datetime.now().month, required=True)

    @api.multi
    def print_report(self):
        """
        print Salary Bank Statement report
        :return:
        """
        datas = {
            'ids': [],
            'model': 'hr.payslip',
            'year': self.year,
            'month': self.months, }

        return self.env.ref('hr_payroll_custom.employee_bank_statement_action').report_action(self, data=datas)


class BankStatementReport(models.AbstractModel):
    _name = 'report.hr_payroll_custom.employee_bank_statement_report'

    @api.model
    def get_report_values(self, docids, data):
        month = data['month']
        year = data['year']

        from_date = datetime.strftime(datetime.now().replace(month=month, year=year), "%Y-%m-01")
        to_date = str(datetime.now().replace(month=month, year=year) + relativedelta(months=+1, day=1, days=-1))[:10]

        self._cr.execute(""" select
         employee.employee_code,employee.name,bank.acc_number ,
         line.total from 
         hr_payslip pay join hr_employee employee on pay.employee_id = employee.id 
         join hr_payslip_line line on pay.id = line.slip_id 
         join res_partner_bank bank on bank.id = employee.bank_account_id 
         where line.code = 'NET' and date_from = '"""+str(from_date)+"""' and date_to = '"""+str(to_date)+""""' 
         """)
        docs = self._cr.dictfetchall()
        if len(docs) == 0:
            raise exceptions.ValidationError(_('There is no Information'))
        date = datetime.strftime(datetime.today(), '%Y-%m-%d')
        docargs = {
            'doc_ids': self.ids,
            'doc_model': 'hr.employee',
            'docs': docs,
            'date': date,

        }
        return docargs


class CertificateSalary(models.TransientModel):
    _name = "certificate.of.salary.temp.wiz"

    year = fields.Selection([(num, str(num)) for num in range(datetime.now().year, datetime.now().year - 10, -1)],
                            string="year", default=datetime.now().year, required=True)
    months = fields.Selection([(num, str(calendar.month_name[num])) for num in range(1, 12 + 1)], string="month",
                              default=datetime.now().month, required=True)

    @api.multi
    def print_report(self):

        datas = {
            'ids': self.id,
            'model': 'hr.payslip',
            'year': self.year,
            'month': self.months,
            'employee_id':self.env.context.get('active_ids', []),
            }
        print(datas,"data<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")

        return self.env.ref('hr_payroll_custom.certificate_of_salary').report_action(self, data=datas)








class CertificateSalaryReport(models.AbstractModel):
    _name = 'report.hr_payroll_custom.certificate_of_salary_temp'

    @api.model
    def get_report_values(self, docids, data):
        month = data['month']
        year = data['year']
        current_date = datetime.now()
        from_date = datetime.strftime(datetime.now().replace(month=month, year=year), "%Y-%m-01")
        to_date = str(datetime.now().replace(month=month, year=year) + relativedelta(months=+1, day=1, days=-1))[:10]

        docs = self.env['hr.payslip'].search(
            [('date_from', '=', from_date), ('date_to', '=', to_date)
                ,('employee_id','=',data['employee_id'][0]),('type', '=', 'salary')])

        print(docs,"Docs>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        date_time = datetime.strftime(datetime.now(), '%Y-%m-%d')
        if month == 1:
            name = "?????"
        elif month == 2:
            name = "??????"
        elif month == 3:
            name = "????"
        elif month == 4:
            name = "?????"
        elif month == 5:
            name = "????"
        elif month == 6:
            name = "?????"
        elif month == 7:
            name = "?????"
        elif month == 8:
            name = "?????"
        elif month == 9:
            name = "??????"
        elif month == 10:
            name = "???????"
        elif month == 11:
            name = "??????"
        elif month == 12:
            name = "??????"

        docargs = {
            'doc_ids': self.ids,
            'doc_model': 'hr.payslip',
            'docs': docs,
            'date_time': date_time,
            'month_name':name,
            'y': data['year'],
            'm': data['month'],

        }

        return docargs





#########################################################Promotion Report#####################################################################3

class HrPromotionEmployeeInformation(models.TransientModel):
    _name = 'hr.promotion.employee.information'

    report_type = fields.Selection([('period','Specific period'),('last_promo','Last promotion')],default='last_promo')
    start_date = fields.Date('Start Date')
    end_date = fields.Date('End Date')

    def print_report(self):
        """
        Call Abstract Model To Generate Report and pass the data
        :return:report
        """
        datas = {
            'ids': [],
            'model': 'hr.promotions',
            'report_type': self.report_type,
            'start_date': self.start_date,
            'end_date': self.end_date,

        }
        return self.env.ref('hr_payroll_custom.hr_report_promotion_informatio_action').report_action(self, data=datas)


class HrPromotionEmployeeInformationReport(models.AbstractModel):
    _name = 'report.hr_payroll_custom.hr_report_promotion_informatio_report'

    @api.model
    def get_report_values(self, docids, data):
        
        domain = [('state','=','approved')]
        promotion_ids = []
        if data['report_type'] == 'period':
            if data['start_date'] and data['end_date']:
                   domain += [('date', '>=', data['start_date']), ('date', '<=', data['end_date'])]
            elif data['start_date'] and not data['end_date'] :
                  domain += [('date', '>=', data['start_date'])]
            elif data['end_date'] and not data['start_date'] :
                  domain += [('date', '<=', data['end_date'])]
        docs = self.env['hr.promotions'].search(domain)
        if data['report_type'] == 'last_promo':
            employee_ids = self.env['hr.employee'].search([('state','!=','refuse')])
            promotion_ids = docs
            docs = employee_ids
        if len(docs) == 0:
            raise exceptions.ValidationError(_('There is no Information'))
        date = datetime.strftime(datetime.today(), '%Y-%m-%d')
        docargs = {
            'doc_ids': self.ids,
            'doc_model': 'hr.promotions',
            'docs': docs,
            'promotion_ids': promotion_ids,
            'date': date,
            'start_date': data['start_date'],
            'end_date' : data['end_date'] ,
            'report_type': data['report_type'],

        }
        return docargs
######################################################################################################################################