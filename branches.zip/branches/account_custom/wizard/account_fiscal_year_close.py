# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError


class account_fiscal_year_close(models.TransientModel):
    """
    Closes Account Fiscalyear and Generate Closing entries for the selected Fiscalyear Profit & loss accounts
    """
    _name = "account.fiscal.year.close"
    _description = "Fiscal Year Closing"

    move_type = fields.Selection([('curency_adjustment', 'Curency Adjustment'),
                                    ('close_year', 'Fiscal Year Closing'),
                                    ], string='Closing Moves', required=True, default='curency_adjustment')
    company_id = fields.Many2one('res.company', 'Company', required=True, default=lambda self: self.env.company)
    journal_id = fields.Many2one('account.journal', string='Journal', required=True, default=lambda self: self.env.company.account_opening_journal_id)
    pl_account_id = fields.Many2one('account.account', string='Profit & Loss Account')
    income_exchange_account_id = fields.Many2one('account.account', string='Gain Account')
    expense_exchange_account_id = fields.Many2one('account.account', string='Loss Account')
    date_from = fields.Date(required=1, default=lambda self: self.env.company.account_opening_date)
    date_to = fields.Date(required=1, default=lambda self: date(datetime.now().year, 12, 31))
    move_name = fields.Char(string='Name of new entries',size=64, required=True, help="Give a Name To The Fiscal Year Closing Entry")
    
    @api.onchange('company_id','move_type')
    def get_data(self):
        if self.company_id :
            if self.move_type and self.move_type == 'curency_adjustment':
                self.journal_id = self.company_id.currency_exchange_journal_id and self.company_id.currency_exchange_journal_id.id or False
                self.income_exchange_account_id = self.company_id.income_currency_exchange_account_id.id and \
                                        self.company_id.income_currency_exchange_account_id.id or False
                self.expense_exchange_account_id = self.company_id.expense_currency_exchange_account_id and \
                                        self.company_id.expense_currency_exchange_account_id or False
            elif self.move_type and self.move_type == 'close_year':
                self.journal_id = self.company_id.account_opening_journal_id and self.company_id.account_opening_journal_id.id or False
            self.date_from = self.company_id.account_opening_date
    
    @api.constrains('date_from', 'date_to')
    def _check_date_validity(self):
        if self.date_from and self.date_to and self.date_to < self.date_from:
            raise ValidationError(_('End Date cannot be earlier than Start Date.'))

    def create_move(self):
        move_data={'company_id':self.company_id,
                        'journal_id':self.journal_id,
                        'date_from':self.date_from,
                        'date_to':self.date_to,
                        'move_name':self.move_name}
        if self.move_type == 'curency_adjustment' :
            move_data.update({'expense_exchange_account':self.expense_exchange_account_id,
                                    'income_exchange_account':self.income_exchange_account_id})
            move_id = self.company_id.create_curency_adjustment_move(move_data)
        elif self.move_type == 'close_year' :
            move_data.update({'prof_loss_account':self.pl_account_id,})
            move_id = self.company_id.create_close_move(move_data)
        return {
            'name' : _("Journal Entry"),
            'view_mode' : 'form',
            'view_id' : False,
            'view_type' : 'form',
            'res_model' : 'account.move',
            'type' : 'ir.actions.act_window',
            'domain' : '[]',
            'res_id' : move_id.id,
            }
        
