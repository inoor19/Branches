# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from datetime import timedelta, datetime, date

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class FinancialYearOpeningWizard(models.TransientModel):
    """
    Closes Account Fiscalyear and Generate Closing entries for the selected Fiscalyear Profit & loss accounts
    """
    _inherit = "account.financial.year.op"
    
    
    def write(self, vals):
        res = super(FinancialYearOpeningWizard, self).write(vals)
        for wiz in self:
            wiz.company_id.write({
            'period_lock_date': fields.Date.from_string(self.opening_date) - timedelta(days=1),
            })
            wiz.company_id.account_opening_move_id.write({
                'date': fields.Date.from_string(vals.get('opening_date') or wiz.company_id.account_opening_date),
                })
        return res

