# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
{
    'name': 'Accounting and Financial Extra Features',
    'version': '1.0',
    'category': 'Accounting/Accounting',
    'description': """
        Customizing Invoicing & Payments To meet Sudanese companies/institutes need.
        By :
            - Adding Current Year filter to Journal Entries & Journal Items.
            - Link Journal Entries with Source Document.
            - Adding Fiscal Year Closing.
            """,
    'author': 'NCTR',
    'website': 'http://www.nctr.sd',
    'depends': ['base_custom', 'account','account_payment'],
    'data': [
        'security/account_security.xml',
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/account_menuitem.xml',
        'views/account_move_view.xml',
        'views/account_payment_view.xml',
        'views/account_account_views.xml',
        'views/account_analytic_views.xml',
        'views/account_journal_views.xml',
        'views/tax_view.xml',
        'views/res_partner_views.xml',
        'views/res_company_views.xml',
        'views/res_config_settings_views.xml',
        'reports/invoice_report.xml',
        'reports/payment_receipt_report.xml',
        'wizard/setup_wizards_view.xml',
        'wizard/account_fiscal_year_close_view.xml',
        'wizard/account_report_common_view.xml',

    ],
    'installable': True,
    'license': 'LGPL-3',
}
