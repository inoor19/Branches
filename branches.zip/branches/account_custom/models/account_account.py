# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, tools, _
from datetime import datetime, timedelta


class AccountAccount(models.Model):
    _inherit = "account.account"

    current_debit = fields.Float(compute="_compute_current_balance" )
    current_credit = fields.Float(compute="_compute_current_balance" )

    @api.depends('account_type')
    def _compute_include_initial_balance(self):
        for account in self:
            account.include_initial_balance = False
    
    def _compute_current_balance(self):
        domain = [('account_id', 'in', self.ids), ('parent_state', '=', 'posted')]
        if self.env.company.account_opening_date :
            domain += [('date', '>=', self.env.company.account_opening_date)]
        balances = {
            read['account_id'][0]: [read['debit'],read['credit'],read['balance']]
            for read in self.env['account.move.line']._read_group(
                domain=domain,
                fields=['debit', 'credit', 'balance', 'account_id'],
                groupby=['account_id'],
            )
        }
        for account in self:
            record = balances.get(account.id, [0,0,0])
            account.current_debit = record[0]
            account.current_credit = record[1]
            account.current_balance = record[2]
