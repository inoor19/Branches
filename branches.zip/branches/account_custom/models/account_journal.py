# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, tools, _
from odoo.exceptions import UserError


class AccountJournal(models.Model):
    _inherit = "account.journal"

    @api.model
    def get_type_selection(self):
        return [('sale', _('Sales')),
                ('purchase', _('Purchase')),
                ('cash', _('Cash')),
                ('bank', _('Bank')),
                ('general', _('Miscellaneous')),
                ('pl_close', _('Profit & Loss Close'))
            ]

    type = fields.Selection(get_type_selection)
    
    