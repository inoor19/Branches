# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from . import account_move
from . import account_payment
from . import account_account
from . import account_journal
from . import res_company
from . import res_config_settings
