# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from datetime import timedelta, datetime, date

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class ResCompany(models.Model):
    _inherit = 'res.company'

    suitable_journal_ids = fields.Many2many('account.journal', related='account_opening_move_id.suitable_journal_ids')
    sequence_per_journal = fields.Boolean(string='Journal Entry Sequence Per Journal')
    
    
    @api.model
    def create_op_move_if_non_existant(self):
        """ Creates an empty opening move in 'draft' state for the current company
        if there wasn't already one defined. For this, the function needs at least
        one journal of type 'general' to exist (required by account.move).
        """
        self.ensure_one()
        if not self.account_opening_move_id:
            default_journal = self.env['account.journal'].search([('type', '=', 'general'), ('company_id', '=', self.id)], limit=1)

            if not default_journal:
                raise UserError(_("Please install a chart of accounts or create a miscellaneous journal before proceeding."))

            opening_date = self.account_opening_date

            self.account_opening_move_id = self.env['account.move'].create({
                'ref': _('Opening Journal Entry'),
                'company_id': self.id,
                'journal_id': default_journal.id,
                'date': opening_date,
            })

    @api.model
    def create_curency_adjustment_move(self,CL_data={}):
        """
            This function close curency of the selected period by create Curency Closing entries 
        """
        self.ensure_one()
        move_pool = self.env['account.move']
        account_pool = self.env['account.account']
        currency_pool = self.env['res.currency']

        cl_company = CL_data.get('company_id') or self
        cl_journal = CL_data.get('journal_id',False)
        cl_expense_exchange_account = CL_data.get('expense_exchange_account',False)
        cl_income_exchange_account = CL_data.get('income_exchange_account',False)
        
        if not cl_journal :
            raise ValidationError(_('No Journal has been selected for Curency Exchange Difference Closing Move.'))
        if not cl_expense_exchange_account or not cl_income_exchange_account:
            raise ValidationError(_('No Gain or Loss Curency Exchange Difference Accounts has been selected for Curency Exchange Difference Closing Move.'))

        date_from = CL_data.get('date_from') or cl_company.account_opening_date
        date_to = CL_data.get('date_to') or datetime.now().date()
        cl_move_date = date_to
        cl_move_name = CL_data.get('move_name') or '/'
        
        move_ids = move_pool.search([('date', '=', cl_move_date),
                                    ('journal_id', '=', cl_journal.id)
                                    ])
        if move_ids:
            move_ids.unlink()
        account_ids = account_pool.search([('currency_id','!=',False)])
        print("    ############## account_ids : ",account_ids)

        # #check there is no journal entries not posted yet
        # account_move_ids = move_pool.search([('company_id', '=', cl_company.id),
        #                                      ('date', '>=', date_from),
        #                                      ('date', '<=', date_to),
        #                                      ('state', '=', 'draft')
        #                                      ])
        # if account_move_ids:
        #     raise ValidationError(_('In order to close a fiscalyear, you must first post related journal entries.'))
        
        move_lines = []

        #create the closing move
        move_vals = {
            'name' : '/',
            'ref' : '',
            'journal_id' : cl_journal.id,
            'date' : cl_move_date,
            'company_id' : cl_company.id,
        }
        self.env.cr.execute("SELECT l.account_id,l.currency_id,SUM(l.amount_currency) amount_currency, SUM(l.balance) balance \
                    FROM account_move_line l INNER JOIN account_move m ON m.id=move_id \
                    WHERE l.currency_id IS NOT NULL AND l.date between %s and %s AND l.account_id IN %s AND m.state='posted'\
                    GROUP BY l.account_id,l.currency_id",(date_from, date_to,tuple(account_ids.ids)))
        result = self.env.cr.dictfetchall()

        context_multi_currency = self._context.copy()
        if cl_move_date: 
            context_multi_currency.update({'company_id': cl_company.id,'date': cl_move_date})
        total_currency_balance = 0
        
        for line in result:
            line_currency = currency_pool.browse(line['currency_id'])
            # currency_balance = currency_pool.with_context(context_multi_currency)._compute(currency_pool.browse(line['currency_id']), cl_company.currency_id, line['amount_currency'])
            currency_balance = line_currency.with_context(context_multi_currency).compute(line['amount_currency'], cl_company.currency_id)
            
            move_lines.append((0,0,{
                    'name' : cl_move_name,
                    'debit' : currency_balance-line['balance'] > 0 and currency_balance-line['balance'] or 0.0,
                    'credit' : currency_balance-line['balance'] < 0 and abs(currency_balance-line['balance']) or 0.0,
                    'date' : cl_move_date,
                    'date_maturity' : cl_move_date,
                    'journal_id' : cl_journal.id,
                    'account_id' : line['account_id'],
                    'currency_id' : line['currency_id'],
                    # 'amount_currency' : 0.0,
                    'company_id' : cl_company.id,
                    'partner_id' : None
                    }))
            total_currency_balance += currency_balance-line['balance']
            
        if result :
            move_lines.append((0,0,{
                    'name' : cl_move_name,
                    'debit' : total_currency_balance < 0 and -total_currency_balance or 0.0,
                    'credit' : total_currency_balance > 0 and total_currency_balance or 0.0,
                    'date' : cl_move_date,
                    'date_maturity' : cl_move_date,
                    'journal_id' : cl_journal.id,
                    'account_id' : cl_expense_exchange_account.id if total_currency_balance < 0 else cl_income_exchange_account.id,
                    'currency_id' : cl_company.currency_id.id,
                    # 'amount_currency' : 0.0,
                    'company_id' : cl_company.id,
                    'partner_id' : None
                    }))

        move_vals.update({'line_ids':move_lines})

        move_id = move_pool.create(move_vals)
        move_amount = 0.0 
        for line in move_id.line_ids:
            move_amount += line.debit
        move_id.write({'amount_total' : move_amount,})
        return move_id

    @api.model
    def create_close_move(self,CL_data={}):
        """
            This function close fiscal period by create closing entries of the selected period
        """
        self.ensure_one()
        move_pool = self.env['account.move']
        account_pool = self.env['account.account']
        partner_pool = self.env['res.partner']

        cl_company = CL_data.get('company_id') or self
        cl_journal = CL_data.get('journal_id',False)
        cl_prof_loss_account = CL_data.get('prof_loss_account',False)
        
        if not cl_journal :
            raise ValidationError(_('No Journal has been selected for Closing Move.'))
        if not cl_prof_loss_account :
            raise ValidationError(_('No Account for profit and loss has been selected for Closing Move.'))

        date_from = CL_data.get('date_from') or cl_company.account_opening_date
        date_to = CL_data.get('date_to') or datetime.now().date()
        new_opening_date = fields.Date.from_string(date_to) + timedelta(days=1)
        cl_move_date = new_opening_date
        cl_move_name = CL_data.get('move_name') or '/'
        
        move_ids = move_pool.search([('date', '=', cl_move_date),
                                    ('journal_id', '=', cl_journal.id)
                                    ])
        if move_ids:
            move_ids.unlink()

        #check there is no journal entries not posted yet
        account_move_ids = move_pool.search([('company_id', '=', cl_company.id),
                                             ('date', '>=', date_from),
                                             ('date', '<=', date_to),
                                             ('state', '=', 'draft')
                                             ])
        if account_move_ids:
            raise ValidationError(_('In order to close a fiscalyear, you must first post related journal entries.'))
        
        total_balance = 0.0
        account_balance = 0.0
        move_lines = []

        #create the closing move
        move_vals = {
            'name' : '/',
            'ref' : '',
            'journal_id' : cl_journal.id,
            'date' : cl_move_date,
            'company_id' : cl_company.id,
        }

        #For profit_loss Account
        request_1 = ("SELECT account_id, (SUM(l.debit) - SUM(l.credit)) AS balance" +\
                   " FROM account_move_line l " +\
                   " LEFT JOIN account_account a ON (l.account_id=a.id)" +\
                   " LEFT JOIN account_move m ON (l.move_id=m.id)" +\
                   " WHERE m.state='posted' AND a.internal_group in ('income','expense')"+\
                   " AND l.date between %s and %s GROUP BY account_id")

        #For balance Account with Type other & liquidity
        request_2 = ("SELECT account_id, (SUM(l.debit) - SUM(l.credit)) AS balance" +\
                   " FROM account_move_line l " +\
                   " LEFT JOIN account_account a ON (l.account_id=a.id)" +\
                   " LEFT JOIN account_move m ON (l.move_id=m.id)" +\
                   " WHERE m.state='posted' AND a.internal_group in ('equity','asset','liability')"+\
                   " AND a.account_type not in ('asset_receivable','asset_prepayments','liability_payable')"+\
                   " AND l.date between %s and %s GROUP BY account_id")

        #For balance Account with Type receivable & payable
        request_3 = ("SELECT account_id, l.partner_id, (SUM(l.debit) - SUM(l.credit)) AS balance" +\
                   " FROM account_move_line l " +\
                   " LEFT JOIN account_account a ON (l.account_id=a.id)" +\
                   " LEFT JOIN account_move m ON (l.move_id=m.id)" +\
                   " LEFT JOIN res_partner p ON (l.partner_id=p.id)" +\
                   " WHERE m.state='posted' AND a.internal_group in ('equity','asset','liability')"+\
                   " AND a.account_type in ('asset_receivable','asset_prepayments','liability_payable')"+\
                   " AND l.date between %s and %s GROUP BY account_id, l.partner_id")

        params = (date_from, date_to)
        
        self.env.cr.execute(request_1, params)

        for row in self.env.cr.dictfetchall():
            account_balance = row.get('balance')
            account_obj = account_pool.browse(row.get('account_id'))
            currency = account_obj.currency_id and account_obj.currency_id or cl_company.currency_id
            # balance_in_currency = 0.0
            # if account_obj.currency_id:
            #     self.env.cr.execute(
            #         'SELECT sum(amount_currency) as balance_in_currency FROM account_move_line ' \
            #        'WHERE account_id = %s  AND date between %s and %s AND currency_id = %s', 
            #        (account_obj.id, date_from, date_to, account_obj.currency_id.id)
            #     ) 
            #     balance_in_currency = self.env.cr.dictfetchone()['balance_in_currency']
            company_currency_id = cl_company.currency_id.id
            if not currency.is_zero(company_currency_id) or not currency.is_zero(abs(account_balance)) :
                total_balance += account_balance

        move_lines.append((0,0,{
                    'name' : cl_move_name,
                    'debit' : total_balance > 0 and total_balance or 0.0,
                    'credit' : total_balance < 0 and -total_balance or 0.0,
                    'date' : cl_move_date,
                    'date_maturity' : cl_move_date,
                    'journal_id' : cl_journal.id,
                    'account_id' : cl_prof_loss_account.id,
                    'currency_id' : cl_company.currency_id.id,
                    # 'amount_currency' : 0.0,
                    'company_id' : cl_company.id,
                    'partner_id' : None
                    }))

        self.env.cr.execute(request_2, params)

        for row in self.env.cr.dictfetchall():
            account_balance = row.get('balance')
            account_obj = account_pool.browse(row.get('account_id'))
            currency = account_obj.currency_id and account_obj.currency_id or cl_company.currency_id
            vals = {
                        'name' : cl_move_name,
                        'debit' : account_balance > 0 and account_balance or 0.0,
                        'credit' : account_balance < 0 and -account_balance or 0.0,
                        'date' : cl_move_date,
                        'date_maturity' : cl_move_date, 
                        'journal_id' : cl_journal.id,
                        'account_id' : account_obj.id,
                        'currency_id' : account_obj.currency_id and account_obj.currency_id.id or cl_company.currency_id.id,
                        # 'amount_currency' : balance_in_currency,
                        'company_id' : cl_company.id,
                        'partner_id' : None
                    }
            if account_obj.currency_id:
                self.env.cr.execute(
                    'SELECT sum(amount_currency) as balance_in_currency FROM account_move_line ' \
                   'WHERE account_id = %s  AND date between %s and %s AND currency_id = %s', 
                   (account_obj.id, date_from, date_to, account_obj.currency_id.id)
                )
                vals.update({'amount_currency' : self.env.cr.dictfetchone()['balance_in_currency']})
            company_currency_id = cl_company.currency_id.id
            if not currency.is_zero(company_currency_id) or not currency.is_zero(abs(account_balance)) :
                move_lines.append((0,0,vals))

        self.env.cr.execute(request_3, params)

        for row in self.env.cr.dictfetchall():
            account_balance = row.get('balance')
            account_obj = account_pool.browse(row.get('account_id'))
            partner_obj = partner_pool.browse(row.get('partner_id'))
            currency = account_obj.currency_id and account_obj.currency_id or cl_company.currency_id
            # balance_in_currency = 0.0
            # if account_obj.currency_id:
            #     self.env.cr.execute(
            #         'SELECT sum(amount_currency) as balance_in_currency FROM account_move_line ' \
            #        'WHERE account_id = %s  AND date between %s and %s AND currency_id = %s', 
            #        (account_obj.id, date_from, date_to, account_obj.currency_id.id)
            #     )
            #     balance_in_currency = self.env.cr.dictfetchone()['balance_in_currency']
            company_currency_id = cl_company.currency_id.id
            if not currency.is_zero(company_currency_id) or not currency.is_zero(abs(account_balance)) :
                move_lines.append((0,0,{
                        'name' : cl_move_name,
                        'debit' : account_balance > 0 and account_balance or 0.0,
                        'credit' : account_balance < 0 and -account_balance or 0.0,
                        'date' : cl_move_date,
                        'date_maturity' : cl_move_date, 
                        'journal_id' : cl_journal.id,
                        'account_id' : account_obj.id,
                        'currency_id' : account_obj.currency_id and account_obj.currency_id.id or cl_company.currency_id.id,
                        # 'amount_currency' : balance_in_currency,
                        'company_id' : cl_company.id,
                        'partner_id' : partner_obj.id or None
                        }))

        move_vals.update({'line_ids':move_lines})

        move_id = move_pool.create(move_vals)

        move_amount = 0.0 
        move_obj = move_pool.browse(move_id.id)
        for line in move_id.line_ids:
            move_amount += line.debit
        move_id.write({'amount_total' : move_amount,})

        cl_company.write({
                        'account_opening_move_id' : move_id.id,
                        'period_lock_date' : date_to,
                        })
        return move_id
