# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from datetime import timedelta, datetime, date

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import re


class AccountMove(models.Model):
    _inherit = "account.move"
    
    @api.model
    def _select_target_model(self):
        models = self.env['ir.model'].search([])
        return [(model.model, model.name) for model in models]

    source_document = fields.Reference(selection='_select_target_model', string="Source Document")
    source_document_state = fields.Char('Source State', readonly=True)
    cus_sequence_number = fields.Char('Sequence Number', readonly=True, copy=False)
    state = fields.Selection(selection_add=[('reversed', 'Reversed')], ondelete={'reversed': 'set default'})

    def _get_move_display_name(self, show_ref=False):
        ''' Helper to get the display name of an invoice depending of its type.
        :param show_ref:    A flag indicating of the display name must include or not the journal entry reference.
        :return:            A string representing the invoice.
        '''
        self.ensure_one()
        if self.move_type == 'entry' :
            name_field = self.name
        else:
            name_field = self.cus_sequence_number
        name = ''
        if self.state == 'draft':
            name += {
                'out_invoice': _('Draft Invoice'),
                'out_refund': _('Draft Credit Note'),
                'in_invoice': _('Draft Bill'),
                'in_refund': _('Draft Vendor Credit Note'),
                'out_receipt': _('Draft Sales Receipt'),
                'in_receipt': _('Draft Purchase Receipt'),
                'entry': _('Draft Entry'),
            }[self.move_type]
            name += ' '
        if not name_field or name_field == '/':
            name += '(* %s)' % str(self.id)
        else:
            name += name_field
            if self.env.context.get('input_full_display_name'):
                if self.partner_id:
                    name += f', {self.partner_id.name}'
                if self.date:
                    name += f', {format_date(self.env, self.date)}'
        return name + (f" ({shorten(self.ref, width=50)})" if show_ref and self.ref else '')

    def name_get(self):
        result = []
        for move in self:
            result.append((move.id, move._get_move_display_name(show_ref=False)))
        return result

    def _get_cus_sequence_number(self):
        for move in self:
            if move.cus_sequence_number :
                continue
            
            if move.move_type == 'out_invoice':
                move.cus_sequence_number = self.env['ir.sequence'].next_by_code('out.invoice.sequence')
                continue
            if move.move_type == 'in_invoice':
                move.cus_sequence_number = self.env['ir.sequence'].next_by_code('in.invoice.sequence')
                continue
            if move.move_type == 'out_refund':
                move.cus_sequence_number = self.env['ir.sequence'].next_by_code('out.refund.sequence')
                continue
            if move.move_type == 'in_refund':
                move.cus_sequence_number = self.env['ir.sequence'].next_by_code('in.refund.sequence')
                continue
            if move.move_type == 'out_receipt':
                move.cus_sequence_number = self.env['ir.sequence'].next_by_code('out.receipt.sequence')
                continue
            if move.move_type == 'in_receipt':
                move.cus_sequence_number = self.env['ir.sequence'].next_by_code('in.receipt.sequence')
                continue
            is_payment = move.payment_id or self._context.get('is_payment')
            if move.move_type == 'entry' and is_payment:
                move.cus_sequence_number = self.env['ir.sequence'].next_by_code('payment.sequence')

    @api.model_create_multi
    def create(self, vals_list):
        moves = super(AccountMove, self).create(vals_list)
        moves._get_cus_sequence_number()
        return moves

    def button_draft(self):
        for rec in self:
            if rec.source_document:
                rec.source_document.state = rec.source_document_state
        return super(AccountMove, self).button_draft()

    def action_post(self):
        if self.company_id.account_opening_move_id.id==self.id :
            company_data = {'fiscalyear_lock_date':self.company_id.period_lock_date}
            if self.company_id.period_lock_date : 
                new_opening_date = fields.Date.from_string(self.company_id.period_lock_date) + timedelta(days=1)
                company_data.update({'account_opening_date' : new_opening_date})
            self.company_id.write(company_data)
        return super(AccountMove, self).action_post()

    # -------------------------------------------------------------------------
    # SEQUENCE MIXIN
    # -------------------------------------------------------------------------

    def _get_last_sequence_domain(self, relaxed=False):
        # EXTENDS account sequence.mixin
        self.ensure_one()
        if self.company_id.sequence_per_journal :
            return super(AccountMove, self)._get_last_sequence_domain(relaxed)
        if not self.date :
            return "WHERE FALSE", {}
        where_string = "WHERE name != '/'"
        param = {}
        is_payment = self.payment_id or self._context.get('is_payment')

        if not relaxed:
            domain = [('id', '!=', self.id or self._origin.id), ('name', 'not in', ('/', '', False))]
            reference_move_name = self.search(domain + [('date', '<=', self.date)], order='date desc', limit=1).name
            if not reference_move_name:
                reference_move_name = self.search(domain, order='date asc', limit=1).name
            sequence_number_reset = self._deduce_sequence_number_reset(reference_move_name)
            if sequence_number_reset == 'year':
                where_string += " AND date_trunc('year', date::timestamp without time zone) = date_trunc('year', %(date)s) "
                param['date'] = self.date
                param['anti_regex'] = re.sub(r"\?P<\w+>", "?:", self._sequence_monthly_regex.split('(?P<seq>')[0]) + '$'
            elif sequence_number_reset == 'month':
                where_string += " AND date_trunc('month', date::timestamp without time zone) = date_trunc('month', %(date)s) "
                param['date'] = self.date
            else:
                param['anti_regex'] = re.sub(r"\?P<\w+>", "?:", self._sequence_yearly_regex.split('(?P<seq>')[0]) + '$'

            if param.get('anti_regex') :
                where_string += " AND sequence_prefix !~ %(anti_regex)s "
        return where_string, param

    def _get_starting_sequence(self):
        # EXTENDS account sequence.mixin
        self.ensure_one()
        if self.company_id.sequence_per_journal :
            return super(AccountMove, self)._get_starting_sequence()
        starting_sequence = "%04d/00000" % (self.date.year)
        return starting_sequence
    
    def _get_name_invoice_report(self):
        self.ensure_one()
        return 'account_custom.report_invoice_document'
        # return super()._get_name_invoice_report()
