# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import models, fields, api, _

class AccountPayment(models.Model):
    _inherit = 'account.payment'

    def name_get(self):
        result = []
        for payment in self :
            name = payment.move_id.cus_sequence_number and payment.move_id.cus_sequence_number or ''
            if not name :
                name = payment.move_id.name != '/' and payment.move_id.name or ''
            if payment.state == 'draft':
                name = _('Draft Payment') + name
            result.append((payment.id, name))
        return result