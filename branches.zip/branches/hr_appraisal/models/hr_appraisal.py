# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError


class HrAppraisal(models.Model):
    _name = "hr.appraisal"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Employee Appraisal"
    _order = 'date'
    _rec_name = 'employee_id'
    
    date = fields.Date(string='Appraisal Deadline', required=True)
    date_close = fields.Date(string='Ending Date',)
    action_plan = fields.Text(string="Action Plan",
                              help="If the evaluation does not meet the expectations, you can propose an action plan")
    note_summary = fields.Text(string="Appraisal Summary")
    active = fields.Boolean(default=True)
    type_id = fields.Many2one('hr.appraisal.type', string='Appraisal Type', required=True)
    plan_id = fields.Many2one('hr.appraisal.plan', string='Appraisal Plan',domain=[('state', '=', 'inprogress')])
    employee_id = fields.Many2one('hr.employee', required=True, string='Employee',
                                  index=True)
    department_id = fields.Many2one('hr.department', related='employee_id.department_id',
                                    string='Department', store=True)
    evaluator_id = fields.Many2one('hr.employee', string='Evaluator')
    job_id = fields.Many2one('hr.job', related='employee_id.job_id', string='Job', store=True)
    parent_id = fields.Many2one('hr.employee', related='employee_id.parent_id', string="Direct Manager", store=True)
    state = fields.Selection([
        ('new', 'New'),
        ('cancel', 'Cancelled'),
        ('wait', 'Appraisal In Progress'),
        ('progress', 'Waiting Appreciation'),
        ('done', 'Done'),
    ], string='Status', tracking=True,
                             required=True, readonly=True, copy=False, default='new', index=True)
    rating = fields.Selection([
            ('0', 'Bad'),
            ('1', 'Significantly bellow expectations'),
            ('2', 'Did not meet expectations'),
            ('3', 'Meet expectations'),
            ('4', 'Exceeds expectations'),
            ('5', 'Significantly exceeds expectations'),
    ], string='Appreciation', compute='_compute_rating', readonly=True, tracking=True)
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')
    appraisal_line_ids = fields.One2many('hr.appraisal.model.line', 'appraisal_id', string="Employee Appraisal", copy=True)
    final_result = fields.Float(string="Final Result", compute='_compute_final_result')
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(related='employee_id.company_id', readonly=True, store=True)

    @api.constrains('date', 'end_date')
    def _check_date_validity(self):
        for rec in self:
            if rec.start_date and rec.end_date :
                if rec.end_date < rec.start_date :
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))
            elif rec.date and rec.end_date:
                if rec.end_date < rec.date:
                    raise ValidationError(_('Appraisal Deadline cannot be after than End Date.'))

    def unlink(self):
        for appraise in self:
            if appraise.state != 'new':
                raise UserError(_('Cannot delete record(s) which are not in draft state.'))
        return super(HrAppraisal, self).unlink()

    def button_send_appraisal(self):
        self.write({'state': 'wait'})

    def button_progress_appraisal(self):
        self.write({'state': 'progress'})

    def button_done_appraisal(self):
        self.write({'state': 'done'})

    def button_cancel_appraisal(self):
        self.write({'state': 'cancel'})

    def button_new_appraisal(self):
        self.write({'state': 'new'})

    @api.depends('appraisal_line_ids.weight', 'appraisal_line_ids.appraise_result')
    def _compute_final_result(self):
        for rec in self:
            total_weight = 0
            total_appraise_result = 0
            rec.final_result = 0
            for line in rec.appraisal_line_ids:
                total_weight += line.weight
                total_appraise_result += line.appraise_result
                if total_weight > 0:
                    rec.final_result = total_appraise_result/total_weight

        return rec.final_result

    @api.depends('final_result')
    def _compute_rating(self):
        for rec in self:
            if rec.final_result < 1:
                rec.rating = '0'
            if 1 <= rec.final_result < 2:
                rec.rating = '1'
            if 2 <= rec.final_result < 3:
                rec.rating = '2'
            if 3 <= rec.final_result < 4:
                rec.rating = '3'
            if 4 <= rec.final_result < 5:
                rec.rating = '4'
            if rec.final_result == 5:
                rec.rating = '5'
        return rec.rating


class HrAppraisalModelLine(models.Model):
    _name = "hr.appraisal.model.line"
    _order = "number"

    performance = fields.Text(string='Performance Indicator')
    objective = fields.Text(string='Objective & Activities')
    weight = fields.Float(string='Weight')
    code = fields.Char(string="Code")
    number = fields.Integer(string="#")
    targeted = fields.Float(string="Target")
    actual = fields.Float(string="Actual")
    appraise = fields.Selection([('1', '1'), ('2', '2'), ('3', '3'), ('4', '4'), ('5', '5')], string="Appraise")
    appraise_result = fields.Float(string="Result", compute='_compute_appraise_result')
    appraisal_id = fields.Many2one('hr.appraisal')

    def _compute_appraise_result(self):
        for rec in self:
            rec.appraise_result = rec.weight * float(rec.appraise)
            return rec.appraise_result





