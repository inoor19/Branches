# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api,fields, models, _
from odoo.exceptions import UserError


    
class AppraisalType(models.Model):
    _name = "hr.appraisal.type"
    _description = "Appraisal Type"
    _inherit = ['mail.thread']

    name = fields.Char(string='Name')
    active = fields.Boolean(default=True)
    periodicity = fields.Integer(string='Periodicity of Appraisal (months)')
    used_type = fields.Selection([
        ('periodic','Periodical'),
        ('emergency','Emergency'),
        ('process','Link To Process')],default='periodic', string="Type")
    process_type = fields.Selection([
        ('trial_period','Appraisal of trial period'),
        ('bonus','Appraisal of annual bonus'),
        ('before_training','Appraisal before training'),
        ('after_training','Appraisal after training'),
        ('promotion','Appraisal for promotion'),
        ], string="")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)
    line_ids = fields.One2many('hr.appraisal.type.standard','type_id', string="Appraisal Type Standard")
    
    
    _sql_constraints = [('name_uniq', 'unique(name)', 'Appraisal Type name must be unique !')]

    def unlink(self):
        appraise_type_ids = self.env['hr.appraisal'].search([('type_id', '=', self.id)])
        if appraise_type_ids:
            raise UserError(_('You cannot delete appraisal type that is used'))
        return super(AppraisalType, self).unlink()

class AppraisalTypeStandard(models.Model):
    _name = "hr.appraisal.type.standard"

    type_id = fields.Many2one('hr.appraisal.type', string="Appraisal Type")
    standard_id = fields.Many2one('hr.appraisal.standard', string="Appraisal Standard")
    weight = fields.Float(string='Weight')

    @api.constrains('type_id')
    def _check_date(self):
        sum_weight = 0.0
        for rec in self.search([('type_id','=',self.type_id.id)]):
            lines = self.search([('type_id','=',self.type_id.id),('standard_id','=',rec.standard_id.id)])
            if len(lines) > 1 :
                raise UserError(_("Appraisal Standard must not dublicat ber Appraisal Type "))
            sum_weight += rec.weight
            if sum_weight > 100.0 :
                raise UserError(_("sum of weights ber Appraisal Type must not Exceed 100"))