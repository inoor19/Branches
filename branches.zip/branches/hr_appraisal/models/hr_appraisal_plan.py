# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _

from odoo.exceptions import ValidationError, UserError


class AppraisalPlan(models.Model):
    _name = "hr.appraisal.plan"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Appraisal Plan"

    def _default_type(self):
        return self.env['hr.appraisal.type'].search([('used_type', '=', self.env.context.get('default_type'))], limit=1)

    name = fields.Char(string='Name')
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')
    type_id = fields.Many2one('hr.appraisal.type', string='Appraisal Type',
                              domain="[('used_type','!=','process'),"
                                     "('used_type','=', (type == 'periodic' and 'periodic' or 'emergency'))]",
                              default=_default_type)
    periodic_ids = fields.One2many('hr.appraisal.periodic', 'appraisal_plan_id', string='Appraisal Periodic')
    employee_ids = fields.Many2many('hr.employee', string='Employees')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('inprogress', 'Inprogress'),
        ('done', 'Done'),
    ], string='Status', tracking=True, default='draft')
    type = fields.Selection([
        ('periodic', 'Periodical'),
        ('emergency', 'Emergency')], default='periodic', string="Type")
    active = fields.Boolean(default=True)
    appraisal_count = fields.Integer(compute="_compute_appraisal_count")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)


    _sql_constraints = [
        ('name_uniq', 'unique (name)', _('The name of the appraisal plan must be unique !'))
    ]

    def copy(self, default=None):
        if default is None:
            default = {}
        new_name = (self.name + ' (copy)') if self.name else ''
        default.update({
            'name': new_name,
        })
        new_sample = super(AppraisalPlan, self).copy(default=default)
        return new_sample


    def unlink(self):
        appraise_plan_ids = self.env['hr.appraisal'].search([('plan_id', '=', self.id)])
        if appraise_plan_ids:
            raise UserError(_('You cannot delete appraisal plan that is used'))
        for plan in self:
            if plan.state != 'draft':
                raise UserError(_('Cannot delete record(s) which are not in draft state.'))
        return super(AppraisalPlan, self).unlink()



    def action_inprogress(self):
        return self.write({'state': 'inprogress'})

    def action_done(self):
        for rec in self:
            domain = [('state', '!=', 'done'), ('plan_id', '=', rec.name)]
            check_emp_appraise = rec.env['hr.appraisal'].search(domain)
            if check_emp_appraise:
                raise UserError(_('cannot close the plan unless you appraise all the employees in this plan'))
            return self.write({'state': 'done'})

    def action_draft(self):
        return self.write({'state': 'draft'})

    @api.constrains('start_date', 'end_date')
    def _check_date_validity(self):
        """ verifies if date_from is earlier than date_to. """
        for rec in self:
            if rec.start_date and rec.end_date:
                if rec.end_date <= rec.start_date:
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))

    def _compute_appraisal_count(self):
        for rec in self:
            appraisal_count = self.env['hr.appraisal'].search_count([('plan_id', '=', rec.id)])
            rec.appraisal_count = appraisal_count

    def action_open_appraisal(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Appraisals',
            'res_model': 'hr.appraisal',
            'domain': [('plan_id', '=', self.id)],
            'view_mode': 'tree,form,search',
        }


class AppraisalPeriodic(models.Model):
    _name = "hr.appraisal.periodic"

    appraisal_plan_id = fields.Many2one('hr.appraisal.plan', string='Plan')
    name = fields.Char(string='Name')
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')
    appraisal_start_date = fields.Date(string='Start Date of appraisal preparation')
    appraisal_end_date = fields.Date(string='End Date of appraisal')
    state = fields.Selection([
        ('new', 'New'),
        ('created', 'Appraisal Created')], string='Status', readonly=True, copy=False, default='new')

    def create_employee_appraisal(self):
        employee_appraisal = self.env['hr.appraisal']
        for emp in self.appraisal_plan_id.employee_ids:
            vals = {'employee_id': emp.id,
                    'plan_id': self.appraisal_plan_id.id,
                    'start_date': self.start_date,
                    'end_date': self.end_date,
                    'type_id': self.appraisal_plan_id.type_id and self.appraisal_plan_id.type_id.id,
                    'date': self.appraisal_end_date,
                    }
            employee_appraisal.create(vals)
        self.write({'state': 'created'})
        return True

    @api.constrains('start_date', 'end_date', 'appraisal_start_date', 'appraisal_end_date')
    def _check_date_validity(self):
        for rec in self:
            if rec.end_date <= rec.start_date:
                raise ValidationError(_('End Date cannot be earlier than Start Date.'))
            if rec.appraisal_start_date < rec.start_date:
                raise ValidationError(_('appraisal start date cannot be earlier than Start Date.'))
            if rec.appraisal_end_date <= rec.appraisal_start_date:
                raise ValidationError(_('appraisal end date cannot be earlier than appraisal start Date.'))
            if rec.end_date < rec.appraisal_end_date:
                raise ValidationError(_('appraisal end date cannot be earlier than end Date.'))
            if rec.start_date < rec.appraisal_plan_id.start_date:
                raise ValidationError(_('period start date cannot be earlier than plan start date.'))
            if rec.appraisal_plan_id.end_date < rec.end_date:
                raise ValidationError(_('plan end date cannot be earlier than period end date.'))
