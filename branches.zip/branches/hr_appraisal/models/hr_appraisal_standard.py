# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import fields, models, _

class AppraisalStandard(models.Model):
    _name = "hr.appraisal.standard"
    _description = "Appraisal Standard"
    _inherit = ['mail.thread']

    name = fields.Char(string='Name')
    standard_type = fields.Selection([
        ('manual','Manual'),
        ('auto','Automatically')],default='manual', string="Standard Type")
    auto_type = fields.Selection([
        ('attendance','Attendance'),
        ('project','Project Management'),
        ('permissions','Permissions'),
        ('violations','Violations')], string="Process Type")
    _sql_constraints = [('name_uniq', 'unique(name)', 'Appraisal Standard name must be unique !')]

    
   
