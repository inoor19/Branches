# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    "name": "Sales Extra Features",
    "version": "1.0",
    "category": "Sales/Sales",
    "summary": """
            Customization of sale views and reports
""",
    "description": """
This module customize the sale order template, quotation/order view and quotation/sale order document report
""",
    "author": "NCTR",
    "website": "http://www.nctr.sd",
    "depends": ['base_custom', 'sale_management'],
    "data": [
        'views/sale_order_views.xml',
        'views/sale_order_template_form_views.xml',
        'views/sale_views.xml',
        'report/sale_report_templates.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
