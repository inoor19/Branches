# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################

{
    'name': 'Training',
    'version': '1.0',
    'category': 'Human Resources/Training',
    'description': """
        Manage Employee Training
        """,
    'author': "NCTR",
    'website': "http://www.nctr.sd",
    'depends': ['hr_custom','hr_payroll','survey',],                                 
    'data': [
        'security/hr_training_security.xml',
        'security/ir.model.access.csv',
        'data/hr_training_seq.xml',
        'views/hr_training_course_views.xml',
        'views/res_partner_views.xml',
        'views/hr_training_plan_views.xml',
        'views/hr_training_views.xml',
        'views/hr_training_employee_views.xml',
        'views/hr_views.xml',
        'views/survey_views.xml',
        'views/res_config_settings_views.xml',

        'views/training_views.xml',

        'wizard/training_need_wizard.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}
