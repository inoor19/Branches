# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _


class TrainingNeedWizard(models.TransientModel):
    _name = "training.need.wizard"

    plan_id = fields.Many2one('hr.training.plan', string="Plan", required=True)
    course_ids = fields.Many2many('hr.training.course', string="Courses", required=True)
    training_need_ids = fields.Many2many('hr.training', string='Training Needs')
    
    @api.onchange('plan_id')
    def onchange_plan_id(self):
        if self.plan_id:
            return {'domain': {'training_need_ids':[('plan_id','=',self.plan_id.id),
                                            ('type','=','need'),
                                            ('state','=','approve')
                                            ]
                                }}

    def create_training(self):
        
        if self.training_need_ids:
            needs=self.training_need_ids
        else:
            needs = self.env['hr.training'].search([
                                        ('plan_id', '=', self.plan_id.id),
                                        ('course_id', 'in', self.course_ids.ids),
                                        ('type', '=', 'need'),
                                        ('state', '=', 'approve')
                                    ])

        if needs:
            courses = []
            for line in needs:
                if line.course_id:
                    courses.append(line.course_id)
            courses = list(set(courses))
            for course in courses:
                dept_ids = []
                lines = []
                for line in needs.filtered(lambda l : l.course_id.id == course.id):
                    if line.department_id:
                        dept_ids.append(line.department_id.id)
                    dept_ids = list(set(dept_ids))
                    
                    for rec in line.employee_ids:
                        lines.append((0,0,{'employee_id':rec.employee_id.id}))
                        # lines.append(rec.id)
                
                employee_training = self.env['hr.training'].create({
                    'course_id': course.id,
                    'plan_id': self.plan_id.id,
                    'type':'training',
                    'state': 'draft',
                    'department_ids':[(6,0,dept_ids)],
                    'employee_ids':lines,
                })
            for line in needs:
                line.write({'state':'convert'})
    
