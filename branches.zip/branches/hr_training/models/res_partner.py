# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from random import randint

from odoo import api, fields, models, _


class ProfessionalCapabilities(models.Model):
    _name = "professional.capabilities" 

    def _get_default_color(self):
        return randint(1, 11)
        
    name = fields.Char('Name',required=True)
    code=fields.Char('Code',required=True)
    color = fields.Integer(string='Color', default=_get_default_color)
    active=fields.Boolean(default=True)

    _sql_constraints = [
       ('code_uniq', 'unique (code)', _('The code of the capabilities must be unique !'))]
    _sql_constraints = [
       ('name_uniq', 'unique (name)', _('The name of the capabilities must be unique !'))]

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'code' not in default:
            default['code'] = _("%s (copy)") % (self.code)
        if 'name' not in default:
            default['name'] = _("%s (copy)") % (self.name)
        return super(ProfessionalCapabilities, self).copy(default=default)


class Partner(models.Model):
    _inherit = "res.partner"
   
    trainer = fields.Boolean(string='Training Entities')
    training_ids = fields.One2many('hr.training', 'partner_id', domain=[('type','=','training')])                                  
    professional_capabilities = fields.Many2many("professional.capabilities" ,string="Professional Capabilities")  
    experience_year = fields.Integer(string="Experience Years" )
    category = fields.Many2many('hr.training.category', string="Category")
    training_count = fields.Integer(compute="_compute_training_count")
    evolution_count = fields.Integer(compute="_compute_evolution_count")
    

    def _compute_training_count(self):
        for partner in self :
            partner.training_count = len(partner.training_ids)

    def _compute_evolution_count(self):
        for partner in self:
            list=[]
            trainings= self.env['hr.training'].search([('type','=','training'),('partner_id','=',partner.id)])
            for training in trainings:
                for line in training.employee_ids:
                    if line.trainer_evaluation:
                        list.append(line.trainer_evaluation.id)
            
            partner.evolution_count=len(set(list))

    def open_trainer_evaluation(self):
        for partner in self:
            list=[]
            trainings= self.env['hr.training'].search([('type','=','training'),('partner_id','=',partner.id)])
            for training in trainings:
                for line in training.employee_ids:
                    if line.trainer_evaluation:
                        list.append(line.trainer_evaluation.id)
                   
        return {
            'name': _('Evaluation'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'survey.user_input',
            'type':'ir.actions.act_window',
            'domain':[('id', 'in',list)],
        } 


    def partner_training(self):
        return {
            'name': _('Trainings'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'hr.training',
            'type':'ir.actions.act_window',
            'domain':[('id', 'in', self.training_ids.ids)],
            'context':{'create':0,'edit':0,'delete':0}
        } 
