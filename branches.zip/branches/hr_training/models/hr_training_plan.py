# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta


class HrTrainingPlan(models.Model):
    _description = 'Training Plan'
    _inherit = ['mail.thread']
    _name = "hr.training.plan"
    _order = "id desc"

    name = fields.Char("Plan Name", size=64, required=True, tracking=True)
    code = fields.Char("Plan Code", size=64, readonly=True, tracking=True)
    percentage = fields.Integer("Percentage", help="The percentage of employees allow to nominate from each department.\nIf it equal 0 it means unlimited.")
    classification = fields.Selection([
            ('yearly', 'Yearly Plan'),
            ('emergency', 'Emergency Plan')], string='Plan Classification', default="yearly", required=True, tracking=True)
    start_date = fields.Date('Plan Start Date', required=True, tracking=True)
    end_date = fields.Date('Plan End Date', required=True, tracking=True)
    active =fields.Boolean('Active',default=True)
    training_need_ids = fields.One2many('hr.training', 'plan_id', string='Training Needs',
                                    domain=[('type','=','need')], readonly=True)
    training_ids = fields.One2many('hr.training', 'plan_id', 'Trainings',
                                    domain=[('type','=','training')], readonly=True)
    plan_cost = fields.Float("Plan Cost", required=True, tracking=True)
    actual_cost = fields.Float("Actual Cost", required=True, tracking=True)
    state = fields.Selection([('draft', 'Draft'),  
                                ('confirmed', 'Confirmed'),
                                ('approved', 'Approved'),
                                ('refusal', 'Refusal'),], string="State", default="draft", readonly=True, tracking=True)
    doc_count = fields.Integer(compute='_compute_attached_docs_count', string="Number of documents attached")
    

    _sql_constraints = [
       ('name_uniq', 'unique (name)', _('The name of the training plan must be unique !'))]

    @api.constrains('start_date', 'end_date')
    def _check_date_validity(self):
        """ verifies if date_from is earlier than date_to. """
        for rec in self:
            if rec.start_date and rec.end_date :
                if rec.end_date < rec.start_date :
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))

                if self.search([
                            ('id','!=',rec.id),('classification','=',rec.classification),
                            '|','&',('start_date','<=',rec.start_date),('end_date','>=',rec.start_date),
                            '&',('start_date','<=',rec.end_date),('end_date','>=',rec.end_date)
                    ]) :
                    raise ValidationError(_('check period; Training Plane Interference.'))
    
    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'name' not in default:
            default['name'] = _("%s (copy)") % (self.name)
        end_date = datetime.strptime(str(self.end_date), "%Y-%m-%d").date() + timedelta(days=1)
        if 'start_date' not in default:
            default['start_date'] = end_date
        if 'end_date' not in default:
            default['end_date'] = end_date
        return super(HrTrainingPlan, self).copy(default=default)

    @api.model
    def create(self, vals):
        vals['code'] = self.env['ir.sequence'].next_by_code('hr.training.plan') or '/'
        return super(HrTrainingPlan, self).create(vals)

    def unlink(self):
        if self.filtered(lambda l: l.state != 'draft') :
            raise UserError(_("you can't delete record wich is not draft!"))
        return super(HrTrainingPlan, self).unlink()

    def action_draft(self):
        return self.write({'state': 'draft'})

    def action_confirm(self):
        return self.write({'state': 'confirmed'})

    def action_approve(self):
        self.write({'state': 'approved'})

    def action_refusal(self):
        return self.write({'state': 'refusal'})

    def attachment_tree_view(self):
        domain = ['&', ('res_model', '=', self._name), ('res_id', 'in', self.ids)]
        res_id = self.ids and self.ids[0] or False
        return {
            'name': _('Attachments'),
            'domain': domain,
            'res_model': 'ir.attachment',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'kanban,tree,form',
            'view_type': 'form',
            'help': _('''<p class="oe_view_nocontent_create">
                
                                          Attach
      documents of %s .</p>'''% (self._description)),
            'limit': 80,
            'context': "{'default_res_model': '%s','default_res_id': %d}"
                       % (self._name, res_id)
        }
    def _compute_attached_docs_count(self):
        for line in self:
            line.doc_count = self.env['ir.attachment'].search_count([('res_model','=',self._name),('res_id','=',line.id)])


