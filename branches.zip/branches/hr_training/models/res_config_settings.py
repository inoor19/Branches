# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    training_journal_id = fields.Many2one('account.journal', related="company_id.training_journal_id", 
        string="Training Journal", readonly=False)
    training_account_id = fields.Many2one('account.account', related="company_id.training_account_id",
        string='Training Account', readonly=False)


class ResCompany(models.Model):
    
    _inherit = 'res.company'

    training_journal_id = fields.Many2one('account.journal', string="Training Journal")
    training_account_id = fields.Many2one('account.account', string='Training Account')

