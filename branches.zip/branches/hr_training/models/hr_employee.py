# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _


class Employee(models.Model):
    _inherit = "hr.employee"

    training_count=fields.Integer(compute="_compute_training_count")
    training_ids = fields.One2many('hr.training.employee', 'employee_id', domain=[('type','=','training')])
    
    def _compute_training_count(self):
        for emp in self :
            emp.training_count = len(emp.training_ids)
            
    def employee_training(self):
        return {
            'name': _('Trainings'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'hr.training.employee',
            'type':'ir.actions.act_window',
            'domain':[('id', '=', self.training_ids.ids)],
            'context':{'create':0,'edit':0,'delete':0}
        } 

