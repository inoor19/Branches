# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class TrainingCategory(models.Model):
    _name = "hr.training.category"
    _description = "Course Category"

    name = fields.Char(string="Name" ,required=True)
    active = fields.Boolean(string="Active" ,default=True)
    code = fields.Char(string="Code")

    _sql_constraints = [
       ('name_uniq', 'unique (name)', _('The name of the Category must be unique !'))
    ]

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'name' not in default:
            default['name'] = _("%s (copy)") % (self.name)
        return super(TrainingCategory, self).copy(default=default)


class TrainingCourse(models.Model):
    _name = "hr.training.course"
    _inherit = ['image.mixin','mail.thread']
    _description = 'Training Course'

    name = fields.Char(string="Course Name" ,required=True, tracking=True)
    code = fields.Char(string="Code" ,required=True)
    training_category_id = fields.Many2one("hr.training.category", string="Category", required=True, ondelete='restrict', tracking=True)
    objective = fields.Html(string="Objective" ,sanitize=False,help="Course Objectives...")
    content = fields.Html("Content" , sanitize=True, help="Course Contents...")
    active =fields.Boolean('Active',default=True)
    job_ids = fields.Many2many("hr.job" ,string="Dedicated Jobs")
    prev_course_ids = fields.Many2many("hr.training.course" ,'hr_prev_course_rel', 'course_id', 'prev_id', string="Previous Courses Required")
    response_ids = fields.One2many('survey.user_input', 'training_course_id', string="Response", ondelete="set null")
    survey_id = fields.Many2one('survey.survey', string='Survey')
    respone_count=fields.Integer(compute="_compute_respone_count")
    employee_count=fields.Integer(compute="_compute_employee_count")
    entities_count=fields.Integer(compute="_compute_entities_count")
    approved_user_id = fields.Many2one('res.users', string='approver Name', tracking=True)
    approved_date = fields.Date('Approved Date')
    certificate_ids =fields.Many2many('hr.course.certificate', string="Global Certificate")
   
    
    _sql_constraints = [
        ('name_unique', 'unique(name)', _('The name of the training course should be unique!')),
    ]

    @api.constrains('prev_course_ids')
    def _check_recursion(self):
        if self.prev_course_ids:
            if self.prev_course_ids.filtered(lambda l: l.id == self.id):
                raise ValidationError(_('Error ! You cannot create recursive Name %s.'%(self.name)))
            
    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'name' not in default:
            default['name'] = _("%s (copy)") % (self.name)
        return super(HrTrainingCourse, self).copy(default=default)

    def _compute_respone_count(self):
        for course in self :
            course.respone_count =len(course.response_ids)

    def _compute_employee_count(self):
        for course in self :
            course.employee_count= self.env['hr.training.employee'].search_count([('course_id', '=', course.id)])

    def _compute_entities_count(self):
        for course in self:
            list=[]
            entities= self.env['res.partner'].search([('trainer', '=', True)])
            for entity in entities:
                if entity.training_ids:
                    for line in entity.training_ids:
                        if line.course_id.id==self.id:
                            list.append(entity.id)
            course.entities_count=len(set(list))

    def course_employee(self):
        return {
            'name': _('Employee'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'hr.training.employee',
            'type':'ir.actions.act_window',
            'domain':[('course_id', '=', self.id)],
        } 

    def course_entities(self):
        res= self.env['hr.training'].search([('course_id', '=', self.id)])

        return {
            'name': _('Entities'),
            'view_id':self.env.ref('hr_training.view_partner_tree_inherit_training').id,
            'view_type': 'form',
            'view_mode': 'tree',
            'res_model': 'res.partner',
            'type':'ir.actions.act_window',
            'domain':[('id', 'in', res)],
        } 

    def course_respones(self):
        return {
            'name': _('Respones'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'survey.user_input',
            'type':'ir.actions.act_window',
            'domain':[('training_course_id', '=', self.id)],
        }


class Certificates(models.Model):
    _name = "hr.course.certificate" 
    _description = 'Certificates'
   
    name = fields.Char('Name',required=True)
    code=fields.Char('Code',required=True)
    active=fields.Boolean(default=True)

    _sql_constraints = [
       ('name', 'unique(name)','The name of the Certificates must be unique !')]

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        if 'name' not in default:
            default['name'] = _("%s (copy)") % (self.name)
        return super(Certificates, self).copy(default=default)

