# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class HrTrainingEmployee(models.Model):
    _description = 'HR Employee Training'
    _inherit = ['mail.thread']
    _name = "hr.training.employee"
    _order = "id desc"

    employee_id = fields.Many2one('hr.employee', "Employee", required=True, ondelete='restrict', tracking=True)
    department_id = fields.Many2one('hr.department')
    job_id = fields.Many2one('hr.job', "Job", tracking=True)
    training_id = fields.Many2one('hr.training', 'Training Course', copy=False)
    course_id = fields.Many2one('hr.training.course', 'Course', tracking=True)
    partner_id = fields.Many2one('res.partner', 'Training Entity', ondelete='restrict', tracking=True)
    start_date = fields.Date('Start Date', tracking=True)
    end_date = fields.Date('End Date', tracking=True)
    start_time = fields.Float('Start Time', tracking=True)
    end_time = fields.Float('End Time', tracking=True)
    days = fields.Integer('Days', tracking=True)
    need=fields.Boolean('Need',default=False)
    type = fields.Selection([('training','Training'),('need','Need')], string='Type',
                            related="training_id.type", store=True)
    # survey
    training_survey_id = fields.Many2one('survey.survey', string='Training Survey', related='course_id.survey_id')
    training_evaluation = fields.Many2one('survey.user_input', 
       string="Training Evaluation")
    trainer_survey_id = fields.Many2one('survey.survey', string='Trainer Survey')
    trainer_evaluation = fields.Many2one('survey.user_input', 
       string="Trainer Evaluation")
    trainee_survey_id = fields.Many2one('survey.survey', string='Trainee Survey')
    trainee_evaluation = fields.Many2one('survey.user_input', 
       string="Trainee Evaluation")
    # End survey
    enrich_amount = fields.Float("Enrich Amount", readonly=True)
    score= fields.Integer('Score', tracking=True)
    present_state = fields.Selection([('present', 'Present'), ('absent', 'Absent'),], string='Present')
    completion_state = fields.Selection([('completion', 'Completion'), ('notcompletion', 'Not Completion'),], readonly=True)
    state = fields.Selection([('draft', 'Draft'),  
                                ('confirmed', 'Confirmed'),
                                ('approved', 'Approved'),
                                ('rejected', 'Rejected'),], default="draft", readonly=True, tracking=True)
    doc_count = fields.Integer(compute='_compute_attached_docs_count', string="Number of documents attached")


    @api.constrains('start_date', 'end_date')
    def _check_date_validity(self):
        """ verifies if date_from is earlier than date_to. """
        for rec in self:
            if rec.start_date and rec.end_date :
                if rec.end_date < rec.start_date :
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))
                if rec.training_id and rec.training_id.plan_id and \
                    (rec.start_date < rec.training_id.plan_id.start_date or rec.end_date > rec.training_id.plan_id.end_date) :
                    raise ValidationError(_('Start Date and End Date must be whithin date of plan'))
    
    @api.constrains('course_id','employee_id','state')
    def check_need_validity(self):
     for rec in self:
        domain = [('id','!=',rec.id),('type','=',rec.type),('state','!=','rejected')]
        if rec.course_id:
            domain += [('course_id', '=', rec.course_id.id)]
        if rec.employee_id:
            domain += [('employee_id', '=', rec.employee_id.id)]
        check_course = rec.env['hr.training.employee'].search(domain)
        if check_course:
            raise UserError(_('This course has been taken by this employee'))
    
    @api.onchange('employee_id')
    def onchange_employee(self):
        if self.employee_id :
            self.department_id = self.employee_id.department_id.id
            self.job_id = self.employee_id.job_id.id

    def name_get(self):
        result = []
        for record in self:
            name = '[' + str(record.course_id.name) + ']' + ' ' + record.employee_id.name
            result.append((record.id, name))
        return result

    @api.model
    def create(self, vals):
        if vals.get('employee_id'):
            employee = self.env['hr.employee'].browse(vals['employee_id'])
            if not vals.get('department_id') :
                vals['department_id'] = employee.department_id.id
            if not vals.get('job_id') :
                vals['job_id'] = employee.job_id.id
            
        return super(HrTrainingEmployee, self).create(vals)

    def unlink(self):
        if self.filtered(lambda l: l.state != 'draft') :
            raise UserError(_("you can't delete record wich is not draft!"))
        return super(HrTrainingEmployee, self).unlink()

    def action_draft(self):
        return self.write({'state': 'draft'})

    def action_confirm(self):
        return self.write({'state': 'confirmed'})

    def action_approve(self):
        self.write({'state': 'approved'})

    def action_rejected(self):
        return self.write({'state': 'rejected'})

    def compute_enrich_amount(self):
        for line in self:
            if line.training_id:
                amount=0
                if line.training_id.has_enrich and line.training_id.enrich_id.allowance_ids:
                    for allow in line.training_id.enrich_id.allowance_ids:
                        amount+=allow.compute_allowed_deduct_amount(line.employee_id.contract_id)
                        
                line.enrich_amount=amount

    def check_completion(self):
        if self.course_id.prev_course_ids :
            emp_courses = [line.course_id.id for line in self.env['hr.training.employee'].search([('employee_id','=',self.employee_id.id),('state','=','approved')])]
            for course in self.course_id.prev_course_ids :
                if course.id not in emp_courses:
                    return False
        return True

    def open_employee_evaluation(self):
        return {
            'name': _('Evaluation'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'survey.user_input',
            'type':'ir.actions.act_window',
            'domain':[('id', '=', self.trainee_evaluation.id)],
        } 

    def action_start_trainer_evaluation(self):
        self.ensure_one()
 
        if self.trainer_survey_id:

            response = self.env['survey.user_input'].create({'survey_id':self.trainer_survey_id.id})
            self.write({'trainer_evaluation':response.id})
            # grab the token of the response and start surveying
            url='/survey/%s/%s' % (self.trainer_survey_id.access_token, response.access_token)
            return {
            'type': 'ir.actions.act_url',
            'url': url,
            'target': 'self',
             }
        else:
            raise ValidationError(_("Please Enter Evaluation model"))

    def action_start_training_evaluation(self):
        self.ensure_one()

        if self.training_survey_id:
            response = self.env['survey.user_input'].create({'survey_id': self.training_survey_id.id})
            self.write({'training_evaluation':response.id})
            # grab the token of the response and start surveying
            url='/survey/%s/%s' % (self.training_survey_id.access_token, response.access_token)
            return {
            'type': 'ir.actions.act_url',
            'url': url,
            'target': 'self',
             }
        else:
            raise ValidationError(_("Please Enter Evaluation model"))

    def action_start_trainee_evaluation(self):
        self.ensure_one()
  
        if self.trainee_survey_id:

            response = self.env['survey.user_input'].create({'survey_id': self.trainee_survey_id.id})
            self.write({'trainee_evaluation':response.id})
            # grab the token of the response and start surveying
            url='/survey/%s/%s' % (self.trainee_survey_id.access_token, response.access_token)
            return {
            'type': 'ir.actions.act_url',
            'url': url,
            'target': 'self',
             }
        else:
            raise ValidationError(_("Please Enter Evaluation model"))
    
    def attachment_tree_view(self):
        domain = ['&', ('res_model', '=', self._name), ('res_id', 'in', self.ids)]
        res_id = self.ids and self.ids[0] or False
        return {
            'name': _('Attachments'),
            'domain': domain,
            'res_model': 'ir.attachment',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'kanban,tree,form',
            'view_type': 'form',
            'help': _('''<p class="oe_view_nocontent_create">
                
                                          Attach
      documents of %s .</p>'''% (self._description)),
            'limit': 80,
            'context': "{'default_res_model': '%s','default_res_id': %d}"
                       % (self._name, res_id)
        }
    def _compute_attached_docs_count(self):
        for line in self:
            line.doc_count = self.env['ir.attachment'].search_count([('res_model','=',self._name),('res_id','=',line.id)])


