# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from . import hr_training_course
from . import res_partner
from . import hr_training_plan
from . import hr_training
from . import hr_training_employee
from . import hr_employee
from . import hr_job
from . import survey
from . import res_config_settings



