# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class Training(models.Model):
    _name = "hr.training"
    _inherit = ['mail.thread']
    _description = 'Training'
    _order = "id desc"
    
    @api.model
    def _default_department_id(self):
        return self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1).department_id
   
    @api.model
    def _default_plan_id(self):
        today = fields.Date.today()
        if self._context.get('default_type') :
            if self._context['default_type'] == 'training' :
                return self.env['hr.training.plan'].search([
                	('classification','=','yearly'),
                    ('start_date','<=',today),
                    ('end_date','>=',today),
                    ('state','=','approved') ],limit=1)
            if self._context['default_type'] == 'need' :
                return self.env['hr.training.plan'].search([
                	('classification','=','yearly'),
                    ('start_date','<=',today),
                    ('end_date','>=',today),
                    ('state','=','confirmed')],limit=1)

    name = fields.Char('Number',readonly=True , tracking=True, copy=False)
    request_date = fields.Date('Request Date',default=fields.Date.context_today,readonly=True)
    company_id= fields.Many2one('res.company', 'Company', ondelete='restrict')
    plan_id = fields.Many2one('hr.training.plan', 'Plan', required=True, default=_default_plan_id, ondelete='restrict', tracking=True)
    course_id = fields.Many2one('hr.training.course', 'Course', required=False, ondelete='restrict', tracking=True)
    partner_id = fields.Many2one('res.partner', 'Training Entity', ondelete='restrict', tracking=True)
    start_date = fields.Date('Start Date', tracking=True)
    end_date = fields.Date('End Date', tracking=True)
    training_place = fields.Selection([
    	('inside', 'Inside'), 
        ('outside', 'Outside'), 
        ('outcountry', 'Outcountry'), 
        ('online', 'Online')], 'Place', tracking=True)
    employee_ids = fields.One2many('hr.training.employee', 'training_id', 'Employees')
    notes = fields.Text("Comments")
    type = fields.Selection([('training','Training'),('need','Need')], 'Type')
    # Training Type
    department_ids = fields.Many2many('hr.department')
    start_time = fields.Float('Start Time', tracking=True)
    end_time = fields.Float('End Time', tracking=True)
    analytic_id = fields.Many2one('account.analytic.account', string='Project')
    currency_id = fields.Many2one('res.currency', 'Trainer Currency')
    actual_cost = fields.Float("Actual Cost", tracking=True)
    allowance_ids=fields.Many2many('hr.salary.rule', string='Allowances')
    trainer_payment_no = fields.Many2one('account.move','Trainer Payment Number',readonly=True, copy=False)
    trainee_payment_no = fields.Many2one('account.move','Trainee Payment Number',readonly=True, copy=False)
    trainer_survey_id = fields.Many2one('survey.survey', string='Trainer Evaluation')
    trainee_survey_id = fields.Many2one('survey.survey', string='Trainee Evaluation')
    evaluation_count=fields.Integer(compute="_compute_evaluation_count")
    # Need Type
    department_id = fields.Many2one('hr.department', default=_default_department_id)
    completion_percentage=fields.Float(string="Completion Percentage", required=True, default=100.00)
    plan_cost = fields.Float("Plan Cost", tracking=True)
    rejection_Reasons = fields.Text("Reasons for rejection")
    training_time= fields.Selection([('evening','Evening'),('morning','Morning')], 'Training Time', tracking=True)
    training_need_type = fields.Selection([('new','New Need'), ('exist','Existing Course')] , "Training Need Type", default="exist", required=True)
    course_name = fields.Char(string="Course Name" ,required=False)
    course_code = fields.Char(string="Code" ,required=False)
    course_objective = fields.Html(string="Objective" ,sanitize=False,help="Course Objectives...")
    course_content = fields.Html("Content" , sanitize=True, help="Course Contents...")
    candidate_no = fields.Integer('Candidates Number')
    state = fields.Selection([
    	('draft', 'Draft'),('confirmed', 'Confirmed'),('execute', 'Executing'),('approve', 'Approved'),
    	('convert', 'Convert To Training'), ('done', 'Done'), ('rejected', 'Rejected'),
        ], 'State',default='draft', readonly=True, tracking=True)
    doc_count = fields.Integer(compute='_compute_attached_docs_count', string="Number of documents attached")
    

    @api.constrains('start_date', 'end_date')
    def _check_date_validity(self):
        """ verifies if date_from is earlier than date_to. """
        for rec in self:
            if rec.start_date and rec.end_date :
                if rec.end_date < rec.start_date :
                    raise ValidationError(_('End Date cannot be earlier than Start Date.'))
                if rec.plan_id and \
                    (rec.start_date < rec.plan_id.start_date or rec.end_date > rec.plan_id.end_date) :
                    raise ValidationError(_('Start Date and End Date must be whithin date of plan'))

    @api.onchange('course_id')
    def _onchange_course_id(self):
        return {'domain': {'partner_id': [('category', '=', self.course_id.training_category_id.id)]}}

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            if vals['type']=='need':
                vals['name'] = self.env['ir.sequence'].next_by_code('hr.training.need') or '/'
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('hr.training') or '/'
        return super(Training, self).create(vals)
        
    def unlink(self):
        if self.filtered(lambda l: l.state != 'draft') :
            raise UserError(_("you can't delete record wich is not draft!"))
        return super(Training, self).unlink()

    def action_draft(self):
        for rec in self :
            rec.employee_ids.filtered(lambda l:l.state == 'confirmed').action_draft()
        return self.write({'state': 'draft'})

    def action_confirm(self):
        if self.type=='training':
            attachment=self.env['ir.attachment'].search([('res_model', '=', 'hr.training'), ('res_id', '=', self.id)])
            if not attachment:
                raise ValidationError(_("Please Attach Document."))
        for rec in self :
            rec.employee_ids.filtered(lambda l:l.state == 'draft').action_confirm()
        return self.write({'state': 'confirmed'})

    def action_approve(self):
        for rec in self.filtered(lambda l:l.type == 'need') :
            rec.employee_ids.filtered(lambda l:l.state == 'confirmed').action_approve()
        self.write({'state': 'approve'})
        
        context={
                'default_course_id':self.course_id.id,
                'default_plan_id':self.plan_id.id,
                'default_training_place': self.training_place,
                'default_employee_ids': [(0,0,{'employee_id':l.employee_id.id}) for l in self.employee_ids],
                'default_partner_id': self.partner_id.id,
                'default_type':'training',
            }
        
        return {
            'name': _('Course'),
            'view_id':self.env.ref('hr_training.view_hr_training_form').id,
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'hr.training',
            'type':'ir.actions.act_window',
            'context':context,
        }

    def action_rejected(self):
        for rec in self :
            rec.employee_ids.filtered(lambda l:l.state == 'confirmed').action_rejected()
        return self.write({'state': 'rejected'})

    def action_execute(self):
        return self.write({'state': 'execute'})

    def action_done(self):
        for rec in self.filtered(lambda l:l.type == 'training') :
            rec.employee_ids.filtered(lambda l:l.state == 'confirmed').action_approve()
        return self.write({'state': 'done'})

    def compute_completion(self):
        if self.type == 'need' :
            for line in self.employee_ids:
                if line.check_completion():
                    line.completion_state="completion"
                else:
                    line.completion_state="notcompletion"

            self.completion_percentage = (len(self.employee_ids.filtered(lambda l:l.completion_state=='completion'))/len(self.employee_ids) )*100.0

    def _compute_evaluation_count(self):
        self.ensure_one()
        list=[]
        for line in self.employee_ids:
            if line.training_evaluation and line.training_evaluation.survey_id.id==self.course_id.survey_id.id:
                list.append(line.training_evaluation.id)
        self.evaluation_count=len(list)

    def open_training_evaluation(self):
        self.ensure_one()
        list=[]
        for line in self.employee_ids:
            if line.training_evaluation and line.training_evaluation.survey_id.id==self.course_id.survey_id.id:
                list.append(line.training_evaluation.id)
        return {
            'name': _('Evaluation'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'survey.user_input',
            'type':'ir.actions.act_window',
            'domain':[('id', 'in', list)],
        } 

    def open_partner_evaluation(self):
        self.ensure_one()
        list=[]
        for line in self.employee_ids:
            if line.trainer_evaluation.id:
                list.append(line.trainer_evaluation.id)
        return {
            'name': _('Evaluation'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'survey.user_input',
            'type':'ir.actions.act_window',
            'domain':[('id', 'in', list)],
        }

    def compute_enrich_amount(self):
        for line in self:
            line.employee_ids.compute_enrich_amount()
    
    def transfer_entity_cost(self):
        for rec in self:
            if not rec.trainer_payment_no :
                voucher_date = {
                    'move_type': 'in_receipt',
                    'source_document': self._name + ',' + str(rec.id),
                    'source_document_state': rec.state,
                    'journal_id': self.env.user.company_id.training_journal_id.id or False,
                    'date': fields.Date.context_today(self),
                    'invoice_line_ids': [(0, 0, {'name': rec.name, 
                                                'partner_id': rec.partner_id.id,
                                                'analytic_account_id': rec.analytic_id.id,
                                                'account_id': self.env.user.company_id.training_account_id.id or False,
                                                'quantity': 1,
                                                'price_unit': rec.actual_cost,
                                                }
                                        )],
                            }
                if rec.currency_id :
                    voucher_date.update({'currency_id' : rec.currency_id.id})
                
                voucher_id = self.env['account.move'].sudo().create(voucher_date)
                rec.trainer_payment_no=voucher_id
            else :
                rec.trainer_payment_no.invoice_line_ids.unlink()
                rec.trainer_payment_no.write({'invoice_line_ids': [(0, 0, {'name': rec.name, 
                                                'partner_id': rec.partner_id.id,
                                                'analytic_account_id': rec.analytic_id.id,
                                                'account_id': self.env.user.company_id.training_account_id.id or False,
                                                'quantity': 1,
                                                'price_unit': rec.actual_cost,
                                                }
                                        )],})

    def transfer_enrich(self):
        for rec in self:
            lines =[]  
            for line in rec.employee_ids:
                if line.enrich_amount <= 0:
                    continue
                line = {
                    'name': line.employee_id.name,
                    'partner_id': line.employee_id.address_home_id and line.employee_id.address_home_id.id or False,
                    'analytic_account_id': rec.analytic_id.id,
                    'account_id': self.env.user.company_id.training_account_id.id or False,
                    'quantity': 1,
                    'price_unit': line.enrich_amount,
                }
                lines.append(line)
            if not rec.trainee_payment_no :
                voucher_id = self.env['account.move'].sudo().create({
                    'move_type': 'in_receipt',
                    'source_document': self._name + ',' + str(rec.id),
                    'source_document_state': rec.state,
                    'journal_id': self.env.user.company_id.training_journal_id.id or False,
                    'date': fields.Date.context_today(self),
                    'invoice_line_ids': [(0, 0, x) for x in lines],
                })
                rec.trainee_payment_no=voucher_id
            else :
                rec.trainee_payment_no.invoice_line_ids.unlink()
                rec.trainee_payment_no.write({'invoice_line_ids': [(0, 0, x) for x in lines]})

    def attachment_tree_view(self):
        domain = ['&', ('res_model', '=', self._name), ('res_id', 'in', self.ids)]
        res_id = self.ids and self.ids[0] or False
        return {
            'name': _('Attachments'),
            'domain': domain,
            'res_model': 'ir.attachment',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'kanban,tree,form',
            'view_type': 'form',
            'help': _('''<p class="oe_view_nocontent_create">
                
                                          Attach
      documents of %s .</p>'''% (self._description)),
            'limit': 80,
            'context': "{'default_res_model': '%s','default_res_id': %d}"
                       % (self._name, res_id)
        }
    def _compute_attached_docs_count(self):
        for line in self:
            line.doc_count = self.env['ir.attachment'].search_count([('res_model','=',self._name),('res_id','=',line.id)])

