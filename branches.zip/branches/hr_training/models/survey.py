# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2018-2019 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _


class surveyinput(models.Model):
    _inherit = 'survey.user_input'

    training_course_id = fields.Many2one('hr.training.course')


class surveysurvey(models.Model):
    _inherit = 'survey.survey'

    training = fields.Boolean('Training')

