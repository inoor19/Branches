# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
from odoo import api, fields, models, _


class Job(models.Model):
    _inherit = 'hr.job'

    course_count=fields.Integer(compute="_compute_course_count")

    def _compute_course_count(self):
        for jo in self:
            list=[]
            courses= self.env['hr.training.course'].search([('job_ids', '!=', [])])
            for course in courses:
                if course.job_ids:
                    for job in course.job_ids:
                        if job.id==self.id:
                            list.append(course.id)
            list=set(list)
            jo.course_count=len(list)

    def job_course(self):
        list=[]
        courses= self.env['hr.training.course'].search([('job_ids', '!=', [])])
        for course in courses:
            if course.job_ids:
                for job in course.job_ids:

                    if job.id==self.id:
                        list.append(course.id)

        return {
            'name': _('Courses'),
            'view_id':False,
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'hr.training.course',
            'type':'ir.actions.act_window',
            'domain':[('id', 'in', list)],
        } 

