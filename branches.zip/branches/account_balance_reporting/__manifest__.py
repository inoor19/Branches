# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################
{
    'name': 'Account Balance Reporting',
    'version': '1.0',
    'category': 'Accounting/Accounting',
    'description': """
        View and create Balance Reporting.
            """,
    'author': 'NCTR',
    'website': 'http://www.nctr.sd',
    'depends': ['account','account_custom'],
    'data': [
        'security/ir.model.access.csv',
        'data/accounting_report_data.xml',
        'views/account_financial_report.xml',
        'wizard/account_report_view.xml',
        'report/report_financial.xml',
        'report/report.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
