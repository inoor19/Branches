# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2022-2023 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, fields, models, _
from datetime import date


class AccountingReport(models.TransientModel):
    _name = "accounting.report"
    _inherit = "account.common.report"
    _description = "Accounting Report"

    @api.model
    def _get_account_report(self):
        reports = self.env['account.financial.report'].search([])
        return reports and reports[0] or False

    target_move = fields.Selection([('posted', 'All Posted Entries'),
                                    ('all', 'All Entries'),
                                    ], string='Target Moves', required=True, default='posted')
    date_from = fields.Date(string='Start Date', default=lambda self: self.env.user.company_id.account_opening_date)
    date_to = fields.Date(string='End Date', default=lambda self: date(date.today().year, 12, 31))
    account_report_id = fields.Many2one('account.financial.report', string='Report',
                                        required=True, default=_get_account_report)
    report_title = fields.Char(string='Report Title')
    enable_filter = fields.Boolean(string='Enable Comparison')
    label_filter = fields.Char(string='Column Label', help="This label will be displayed on report to "
                                                           "show the balance computed for the given comparison filter.")
    filter_cmp = fields.Selection([('filter_no', 'No Filters'), ('filter_date', 'Date')],
                                  string='Filter by', required=True, default='filter_date')
    date_from_cmp = fields.Date(string='Start Date')
    date_to_cmp = fields.Date(string='End Date')
    debit_credit = fields.Boolean(string='Display Debit/Credit Columns',
                                  help="This option allows you to get more details about "
                                       "the way your balances are computed."
                                       " Because it is space consuming, we do not allow to"
                                       " use it while doing a comparison.")
    details = fields.Selection([('no_details', 'No Details'),
                                ('details', 'With Details'),
                                ('details_details', 'With Details Details'),
                                ], string='Details', required=True, default='no_details')
    dpi_size = fields.Integer(string='DPI Size', default=90, help="The larger DPI is, the smaller the font size becomes")
    

    @api.onchange('account_report_id', 'date_to')
    def onchange_account_report(self):
        if self.account_report_id:
            report_title = self.account_report_id.name or ''
            if self.date_to :
                report_title += _(' As in ') + self.date_to.strftime('%Y/%m/%d')
                
            self.report_title = report_title


    @api.onchange('enable_filter')
    def onchange_enable_filter(self):
        if self.enable_filter:
            self.debit_credit = False

    def _build_comparison_context(self, data):
        result = {}
        result['journal_ids'] = 'journal_ids' in data['form'] and data['form']['journal_ids'] or False
        result['state'] = 'target_move' in data['form'] and data['form']['target_move'] or ''
        if data['form']['filter_cmp'] == 'filter_date':
            result['date_from'] = data['form']['date_from_cmp']
            result['date_to'] = data['form']['date_to_cmp']
            result['strict_range'] = True
        return result

    def check_report(self):
        res = super(AccountingReport, self).check_report()
        data = {}
        data['form'] = self.read(['account_report_id', 'date_from_cmp', 'date_to_cmp', 'journal_ids', 'filter_cmp', 'target_move'])[0]
        for field in ['account_report_id']:
            if isinstance(data['form'][field], tuple):
                data['form'][field] = data['form'][field][0]
        comparison_context = self._build_comparison_context(data)
        res['data']['form']['comparison_context'] = comparison_context
        return res

    def _print_report(self, data):
        data['form'].update(self.read(['account_report_id', 'report_title', 'filter_cmp', 'label_filter', 
            'target_move', 'enable_filter', 'date_from_cmp', 'date_to_cmp', 
            'debit_credit', 'details', 'dpi_size'])[0])
        return self.env.ref('account_balance_reporting.action_report_financial').report_action(self, data=data, config=False)
