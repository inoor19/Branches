# -*- coding: utf-8 -*-
##############################################################################
#
#    NCTR, Nile Center for Technology Research
#    Copyright (C) 2021-2022 NCTR (<http://www.nctr.sd>).
#
##############################################################################

from odoo import api, models, fields


class AccountFinancialReport(models.Model):
    _name = "account.financial.report"
    _description = "Account Report"

    @api.depends('parent_id', 'parent_id.level')
    def _get_level(self):
        '''Returns a dictionary with key=the ID of a record and value = the level of this
           record in the tree structure.'''
        for report in self:
            level = 0
            if report.parent_id:
                level = report.parent_id.level + 1
            report.level = level

    def _get_children_by_order(self):
        '''returns a recordset of all the children computed recursively, and sorted by sequence. Ready for the printing'''
        res = self
        children = self.search([('parent_id', 'in', self.ids)], order='sequence ASC')
        if children:
            for child in children:
                res += child._get_children_by_order()
        return res

    name = fields.Char('Report Name', required=True, translate=True)
    parent_id = fields.Many2one('account.financial.report', 'Parent')
    children_ids = fields.One2many('account.financial.report', 'parent_id', 'Account Report')
    sequence = fields.Integer('Sequence')
    level = fields.Integer(compute='_get_level', string='Level', store=True, recursive=True)
    type = fields.Selection([
        ('sum', 'View'),
        ('accounts', 'Accounts'),
        ('account_domain', 'Account Domain'),
        ('account_report', 'Report Value'),
        ], 'Type', default='sum')
    account_ids = fields.Many2many('account.account', 'account_account_financial_report',
                                   'report_line_id', 'account_id', 'Accounts')
    account_report_id = fields.Many2one('account.financial.report', 'Report Value')
    report_domain = fields.Char(string="Report Domain")
    sign = fields.Selection([('-1', 'Reverse balance sign'), ('1', 'Preserve balance sign'), 
                            ('()', 'Between brackets'), ('bold', 'Bold')
                            ], 'Sign on Reports',
                            required=True, default='1',
                            help='For accounts that are typically more debited than credited and that you would'
                                 ' like to print as negative amounts in your reports, you should reverse the sign'
                                 ' of the balance; e.g.: Expense account. The same applies for accounts that are '
                                 'typically more credited than debited and that you would like to print as positive '
                                 'amounts in your reports; e.g.: Income account.')
    display_detail = fields.Selection([
        ('no_detail', 'No detail'),
        ('detail_flat', 'Display children flat'),
        ('detail_with_hierarchy', 'Display children with hierarchy')
        ], 'Display details', default='detail_flat')
    style_overwrite = fields.Selection([
        ('0', 'Automatic formatting'),
        ('1', 'Main Title 1 (bold, underlined)'),
        ('2', 'Title 2 (bold)'),
        ('3', 'Title 3 (bold, smaller)'),
        ('4', 'Normal Text'),
        ('5', 'Italic Text (smaller)'),
        ('6', 'Smallest Text'),
        ], 'Report Style', default='0',
        help="You can set up here the format you want this record to be displayed. "
             "If you leave the automatic formatting, it will be computed based on the "
             "financial reports hierarchy (auto-computed field 'level').")
    active = fields.Boolean(default=True)

    domain = fields.Char('Domain')
    percentage = fields.Float('Percentage(%)')
    display_amount = fields.Boolean(default=True)
    amount_type = fields.Selection([('balance', 'Balance'),('initial_balance', 'Initial Balance'),
                                    ('debit', 'Debit'),('credit', 'Credit')
                                    ], 
                                string='Amount Type', required=True, default='balance')
    detail_number = fields.Integer('Detail Number')
    detail1_groupby = fields.Selection([
        ('account_id', 'Accounts'),
        ('partner_id', 'Partners')], string='Details', default='account_id')
    detail2_groupby = fields.Selection([
        ('id', 'Move'),
        ('partner_id', 'Partners')], string='Details Details')

    note = fields.Text("Note", translate=True)
    signature_ids = fields.One2many('report.signature', 'financial_report_id', string='Signatures')
    
    

class ReportSignature(models.Model):
    _name = "report.signature"

    financial_report_id = fields.Many2one('account.financial.report', 'Financial Report')
    name = fields.Char('Name', translate=True)
    label = fields.Char('Label', translate=True)
    tag = fields.Char('Tag', translate=True)
