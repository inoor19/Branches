# -*- coding: utf-8 -*-

import time
from odoo import api, models, _
from odoo.exceptions import UserError


class ReportFinancial(models.AbstractModel):
    _name = 'report.account_balance_reporting.report_financial'
    _description = 'Financial Statement Report'

    def _compute_balance(self, data, accounts, groupby1='account_id', groupby2=False):
        """ compute the balance, debit and credit for the provided accounts
        """
        mapping = {
            'balance': "COALESCE(SUM(debit),0) - COALESCE(SUM(credit), 0) as balance",
            'debit': "COALESCE(SUM(debit), 0) as debit",
            'credit': "COALESCE(SUM(credit), 0) as credit",
        }
        wizard = self.env['accounting.report'].browse(self.env.context.get('active_ids'))
        res = {}
        # for account in accounts:
        #     res[account.id] = dict.fromkeys(mapping, 0.0)
        if accounts:
            domain = wizard._query_get()
            domain += [('display_type', 'not in', ('line_section', 'line_note')),('parent_state', '!=', 'cancel')]
            query = self.env['account.move.line']._where_calc(domain)
            tables, where_clause, where_params = query.get_sql()
            tables = tables.replace('"', '') if tables else "account_move_line"
            wheres = [""]
            if where_clause.strip():
                wheres.append(where_clause.strip())
            filters = " AND ".join(wheres)
            if not groupby2 or data['details'] != 'details_details':
                request = "SELECT "+ groupby1 +" as id, " + ', '.join(mapping.values()) + \
                           " FROM " + tables + \
                           " WHERE account_id IN %s " \
                                + filters + \
                           " GROUP BY "+ groupby1
                params = (tuple(accounts._ids),) + tuple(where_params)
                self.env.cr.execute(request, params)
                for row in self.env.cr.dictfetchall():
                    # res.update({row['id']:row + {'move_lines' : {} }})
                    res.update({row['id']:row })
            else :
                for account in accounts:
                    res[account.id] = dict.fromkeys(mapping, 0.0)
                    res[account.id].update({'move_lines':{}})
                if groupby2 == 'partner_id' :
                    request = "SELECT account_id, "+ groupby2 +" as id, " + ', '.join(mapping.values()) + \
                               " FROM " + tables + \
                               " WHERE account_id IN %s " \
                                    + filters + \
                               " GROUP BY account_id, "+ groupby2
                    params = (tuple(accounts._ids),) + tuple(where_params)
                    self.env.cr.execute(request, params)
                    for row in self.env.cr.dictfetchall():
                        res[row['account_id']]['balance'] += row['balance']
                        res[row['account_id']]['credit'] += row['credit']
                        res[row['account_id']]['debit'] += row['debit']
                        res[row['account_id']]['move_lines'].update({row['id']: row})
                else :
                    request = "SELECT account_id, id, debit, credit, balance " + \
                               " FROM " + tables + \
                               " WHERE account_id IN %s " + \
                                filters
                    params = (tuple(accounts._ids),) + tuple(where_params)
                    self.env.cr.execute(request, params)
                    for row in self.env.cr.dictfetchall():
                        res[row['account_id']]['balance'] += row['balance']
                        res[row['account_id']]['credit'] += row['credit']
                        res[row['account_id']]['debit'] += row['debit']
                        res[row['account_id']]['move_lines'].update({row['id']: row})
        return res

    def _compute_report_balance(self, data, reports):
        '''returns a dictionary with key=the ID of a record and value=the credit, debit and balance amount
           computed for this record. If the record is of type :
               'accounts' : it's the sum of the linked accounts
               'account_domain' : it's the sum of leaf accoutns with such an domain
               'account_report' : it's the amount of the related report
               'sum' : it's the sum of the children of this record (aka a 'view' record)'''
        res = {}
        fields = ['credit', 'debit', 'balance']
        gl_context = self._context.copy()
        for report in reports:
            if report.id in res:
                continue
            
            report_context = gl_context
            if report.amount_type=='initial_balance':
                report_context.update({'initial_bal':True})
            res[report.id] = dict((fn, 0.0) for fn in fields)

            groupby1 = report.detail1_groupby and report.detail1_groupby or 'account_id'
            groupby2 = report.detail2_groupby and report.detail2_groupby or False
            
            if report.type == 'accounts':
                # it's the sum of the linked accounts
                res[report.id]['report_lines'] = self.with_context(report_context)._compute_balance(data, report.account_ids, groupby1, groupby2)
                for value in res[report.id]['report_lines'].values():
                    for field in fields:
                        res[report.id][field] += value.get(field)
            elif report.type == 'account_domain':
                # it's the sum the leaf accounts with such an account type
                account_domain = eval(report.domain)
                accounts = self.env['account.account'].search(account_domain)
                res[report.id]['report_lines'] = self.with_context(report_context)._compute_balance(data, accounts, groupby1, groupby2)
                for value in res[report.id]['report_lines'].values():
                    for field in fields:
                        res[report.id][field] += value.get(field)
            elif report.type == 'account_report' and report.account_report_id:
                # it's the amount of the linked report
                res2 = self._compute_report_balance(data, report.account_report_id)
                for key, value in res2.items():
                    for field in fields:
                        res[report.id][field] += value[field]
            elif report.type == 'sum':
                # it's the sum of the children of this account.report
                res2 = self._compute_report_balance(data, report.children_ids)
                for key, value in res2.items():
                    sub_report = self.env['account.financial.report'].search([('id', '=', key)])
                    if not sub_report.display_amount:
                        continue
                    for field in fields:
                        if sub_report.amount_type not in ['balance','initial_balance'] and field == 'balance':
                            res[report.id][field] += value[sub_report.amount_type]
                        else :
                            res[report.id][field] += value[field]

        return res

    def get_dic(self, data):
        lines = []
        account_report = self.env['account.financial.report'].search([('id', '=', data['account_report_id'][0])])
        child_reports = account_report._get_children_by_order()
        res = self.with_context(data.get('used_context'))._compute_report_balance(data, child_reports)
        
        if data['enable_filter']:
            comparison_res = self.with_context(data.get('comparison_context'))._compute_report_balance(data, child_reports)
            for report_id, value in comparison_res.items():
                report = self.env['account.financial.report'].browse(report_id)
                res[report_id]['comp_bal'] = value['balance']
                res[report_id]['comp_debit'] = value['debit']
                res[report_id]['comp_credit'] = value['credit']
                report_lines = res[report_id].get('report_lines')
                if report_lines:
                    for line_id, val in res[report_id].get('report_lines').items():
                        report_lines[line_id]['comp_bal'] = 0.0
                        report_lines[line_id]['comp_debit'] = 0.0
                        report_lines[line_id]['comp_credit'] = 0.0

                        if report.detail2_groupby and report.detail2_groupby != 'move':
                            move_lines = report_lines[line_id].get('move_lines')
                            if move_lines:
                                for move_id, move_val in report_lines[line_id].get('move_lines').items():
                                    move_lines[move_id]['comp_bal'] = 0.0
                                    move_lines[move_id]['comp_debit'] = 0.0
                                    move_lines[move_id]['comp_credit'] = 0.0

                    for line_id, val in comparison_res[report_id].get('report_lines').items():
                        if not line_id in report_lines :
                            report_lines.update({line_id:val})
                            report_lines[line_id]['balance'] = 0.0
                            report_lines[line_id]['debit'] = 0.0
                            report_lines[line_id]['credit'] = 0.0

                        report_lines[line_id]['comp_bal'] = val['balance']
                        report_lines[line_id]['comp_debit'] = val['debit']
                        report_lines[line_id]['comp_credit'] = val['credit']

                        if report.detail2_groupby and report.detail2_groupby != 'move':
                            move_lines = report_lines[line_id].get('move_lines')
                            if move_lines:
                                for move_id, move_val in val.get('move_lines').items():
                                    if not move_id in move_lines :
                                        move_lines.update({move_id:val})
                                        move_lines[move_id]['balance'] = 0.0
                                        move_lines[move_id]['debit'] = 0.0
                                        move_lines[move_id]['credit'] = 0.0
                                    move_lines[move_id]['comp_bal'] = move_val['balance']
                                    move_lines[move_id]['comp_debit'] = move_val['debit']
                                    move_lines[move_id]['comp_credit'] = move_val['credit']
        return res

    def get_report_lines(self, data, res):
        lines = []
        company = self.env.company
        if data['company_id'] :
            company = self.env['res.company'].browse(data['company_id'][0])
        account_report = self.env['account.financial.report'].search([('id', '=', data['account_report_id'][0])])
        child_reports = account_report._get_children_by_order()
        # res = self.with_context(data.get('used_context'))._compute_report_balance(child_reports)
        # if data['enable_filter']:
        #     comparison_res = self.with_context(data.get('comparison_context'))._compute_report_balance(child_reports)
        #     for report_id, value in comparison_res.items():
        #         res[report_id]['comp_bal'] = value['balance']
        #         report_acc = res[report_id].get('account')
        #         if report_acc:
        #             for account_id, val in comparison_res[report_id].get('account').items():
        #                 report_acc[account_id]['comp_bal'] = val['balance']
        
        # if data['enable_filter']:
        #     comparison_res = self.with_context(data.get('comparison_context'))._compute_report_balance(child_reports)
        #     for report_id, value in comparison_res.items():
        #         report = self.env['account.financial.report'].browse(report_id)
        #         res[report_id]['comp_bal'] = value['balance']
        #         res[report_id]['comp_debit'] = value['debit']
        #         res[report_id]['comp_credit'] = value['credit']
        #         report_lines = res[report_id].get('report_lines')
        #         if report_lines:
        #             for line_id, val in comparison_res[report_id].get('report_lines').items():
        #                 report_lines[line_id]['comp_bal'] = val['balance']
        #                 report_lines[line_id]['comp_debit'] = val['debit']
        #                 report_lines[line_id]['comp_credit'] = val['credit']

        for report in child_reports:
            # balance = res[report.id]['balance'] * float(report.sign)
            balance = res[report.id]['balance']
            if report.amount_type not in ['balance','initial_balance'] :
                balance = res[report.id][report.amount_type]
            if  report.percentage and report.percentage > 0:
                balance =  balance*report.percentage/100
            vals = {
                'name': report.name,
                'balance': balance,
                'debit' : res[report.id]['debit'],
                'credit' : res[report.id]['credit'],
                'sign' : report.sign,
                'type': 'report',
                'level': bool(report.style_overwrite) and report.style_overwrite or report.level,
                'display_amount' : report.display_amount,
                'amount_type' : report.amount_type,
            }

            if data['enable_filter']:
                # vals['balance_cmp'] = res[report.id]['comp_bal'] * float(report.sign)
                comp_bal = res[report.id]['comp_bal']
                if report.amount_type not in ['balance','initial_balance'] :
                    if report.amount_type == 'debit':
                        comp_bal = res[report.id]['comp_debit']
                    if report.amount_type == 'credit' :
                        comp_bal = res[report.id]['comp_credit']
                vals['balance_cmp'] = comp_bal
                vals['debit_cmp'] = res[report.id]['comp_debit']
                vals['credit_cmp'] = res[report.id]['comp_credit']

            if data['details'] != 'no_details' and report.detail_number and report.detail1_groupby:
                vals['detail_number'] = report.detail_number

            lines.append(vals)
            if report.display_detail == 'no_detail':
                #the rest of the loop is used to display the details of the financial report, so it's not needed here.
                continue
            if res[report.id].get('report_lines'):
                line_obj = self.env['account.account']
                if report.detail1_groupby and report.detail1_groupby == 'partner_id':
                    line_obj = self.env['res.partner']
                sub_lines = []
                for obj_id, value in res[report.id]['report_lines'].items():
                    #if there are accounts to display, we add them to the lines with a level equals to their level in
                    #the COA + 1 (to avoid having them with a too low level that would conflicts with the level of data
                    #financial reports for Assets, liabilities...)
                    flag = False
                    obj_rec = line_obj.browse(obj_id)
                    if report.detail1_groupby and report.detail1_groupby == 'partner_id':
                        name = obj_rec.name
                    else :
                        name = obj_rec.code + ' ' + obj_rec.name
                    balance = value['balance']
                    if report.amount_type not in ['balance','initial_balance'] :
                        balance = value[report.amount_type]
                    vals = {
                        'name': name,
                        # 'balance': value['balance'] * float(report.sign) or 0.0,
                        'balance': balance,
                        'debit' : value['debit'] or 0.0,
                        'credit' : value['credit'] or 0.0,
                        'sign' : report.sign,
                        'type': 'account',
                        'level': report.display_detail == 'detail_with_hierarchy' and 4,
                        'display_amount' : report.display_amount,
                        'amount_type' : report.amount_type,
                    }

                    if (report.amount_type in ['balance','initial_balance'] and not company.currency_id.is_zero(vals['balance']) )or \
                        (report.amount_type == 'debit' and not company.currency_id.is_zero(vals['debit'])) or \
                        (report.amount_type == 'credit' and not company.currency_id.is_zero(vals['credit'])) or \
                        (data['debit_credit'] and (not company.currency_id.is_zero(vals['debit']) or \
                                not company.currency_id.is_zero(vals['credit']))):
                        flag = True
                    
                    if data['enable_filter']:
                        comp_bal = value['comp_bal']
                        if report.amount_type not in ['balance','initial_balance'] :
                            if report.amount_type == 'debit':
                                comp_bal = value['comp_debit']
                            if report.amount_type == 'credit' :
                                comp_bal = value['comp_credit']
                        vals['balance_cmp'] = comp_bal
                        vals['debit_cmp'] = value['comp_debit']
                        vals['credit_cmp'] = value['comp_credit']
                        if (report.amount_type in ['balance','initial_balance'] and not company.currency_id.is_zero(vals['balance_cmp']) )or \
                            (report.amount_type == 'debit' and not company.currency_id.is_zero(vals['debit_cmp'])) or \
                            (report.amount_type == 'credit' and not company.currency_id.is_zero(vals['credit_cmp'])) or \
                            (data['debit_credit'] and (not company.currency_id.is_zero(vals['comp_debit']) or \
                                    not company.currency_id.is_zero(vals['comp_credit']))):
                            flag = True
                    if flag:
                        sub_lines.append(vals)
                lines += sorted(sub_lines, key=lambda sub_line: sub_line['name'])
        return lines

    def get_details1_lines(self, data, res):
        lines = []
        company = self.env.company
        if data['company_id'] :
            company = self.env['res.company'].browse(data['company_id'][0])
        account_report = self.env['account.financial.report'].search([('id', '=', data['account_report_id'][0])])
        child_reports = account_report._get_children_by_order()
        child_reports = child_reports.filtered(lambda l: l.detail_number).sorted(key=lambda l: l.detail_number)
        for report in child_reports:
            if not report.detail1_groupby :
                continue
            groupby = report.detail1_groupby and report.detail1_groupby

            details =[]
            for obj_id, value in res[report.id]['report_lines'].items():
                flag = False
                line_obj = self.env['account.account']
                if groupby == 'partner_id':
                    line_obj = self.env['res.partner']
                obj_rec = line_obj.browse(obj_id)
                
                if groupby == 'partner_id':
                    detail_name = obj_rec.name
                else :
                    detail_name = obj_rec.code + ' ' + obj_rec.name
                
                balance = value['balance']
                if report.amount_type not in ['balance','initial_balance'] :
                    balance = value[report.amount_type]
                vals = {
                    'name': report.name,
                    'balance': res[report.id]['balance'],
                    'sign' : report.sign,
                    'type': 'report',
                    'detail_name': detail_name,
                    'detail_balance': balance,
                    'detail_debit' : value['debit'],
                    'detail_credit' : value['credit'],
                    'detail_number' :report.detail_number,
                    'amount_type' : report.amount_type,
                }

                if (report.amount_type in ['balance','initial_balance'] and not company.currency_id.is_zero(vals['detail_balance']) )or \
                    (report.amount_type == 'debit' and not company.currency_id.is_zero(vals['detail_debit'])) or \
                    (report.amount_type == 'credit' and not company.currency_id.is_zero(vals['detail_credit'])) or \
                    (data['debit_credit'] and (not company.currency_id.is_zero(vals['detail_debit']) or \
                            not company.currency_id.is_zero(vals['detail_credit']))):
                    flag = True
                if data['enable_filter']:
                    comp_bal = value['comp_bal']
                    if report.amount_type not in ['balance','initial_balance'] :
                        if report.amount_type == 'debit':
                            comp_bal = value['comp_debit']
                        if report.amount_type == 'credit' :
                            comp_bal = value['comp_credit']
                    vals['detail_balance_second'] = comp_bal
                    vals['detail_debit_second'] = value['comp_debit']
                    vals['detail_credit_second'] = value['comp_credit']
                    if (report.amount_type in ['balance','initial_balance'] and not company.currency_id.is_zero(vals['detail_balance_second']) )or \
                        (report.amount_type == 'debit' and not company.currency_id.is_zero(vals['detail_debit_second'])) or \
                        (report.amount_type == 'credit' and not company.currency_id.is_zero(vals['detail_credit_second'])) or \
                        (data['debit_credit'] and (not company.currency_id.is_zero(vals['detail_debit_second']) or \
                                not company.currency_id.is_zero(vals['detail_credit_second']))):
                        flag = True
                if flag :
                    details.append(vals)
            if len(details) > 0 :
                lines.append(details)

        return lines

    def get_details2_lines(self, data, res):
        lines = []
        company = self.env.company
        if data['company_id'] :
            company = self.env['res.company'].browse(data['company_id'][0])
        account_report = self.env['account.financial.report'].search([('id', '=', data['account_report_id'][0])])
        child_reports = account_report._get_children_by_order()
        child_reports = child_reports.filtered(lambda l: l.detail_number).sorted(key=lambda l: l.detail_number)
        for report in child_reports:
            next_number = 1
            if (report.detail1_groupby and report.detail1_groupby != 'account_id') or not report.detail2_groupby :
                continue
            for obj_id, value in res[report.id]['report_lines'].items():
                account = self.env['account.account'].browse(obj_id)
                details = []
                detail_number = str(report.detail_number) +" - "+ str(next_number)
                if report.detail2_groupby == 'partner_id':
                    for line_id, line in value['move_lines'].items() :
                        flag = False
                        obj_rec = self.env['res.partner'].browse(line_id)
                        balance = line['balance']
                        if report.amount_type not in ['balance','initial_balance'] :
                            balance = line[report.amount_type]
                        vals = {
                            'name': account.name,
                            'sign' : report.sign,
                            'detail2_groupby' : report.detail2_groupby,
                            'detail_name': obj_rec.name,
                            'detail_balance': balance,
                            'detail_debit' : line['debit'],
                            'detail_credit' : line['credit'],
                            'detail_number' : detail_number,
                            'amount_type' : report.amount_type,
                        }

                        if (report.amount_type in ['balance','initial_balance'] and not company.currency_id.is_zero(vals['detail_balance']) )or \
                            (report.amount_type == 'debit' and not company.currency_id.is_zero(vals['detail_debit'])) or \
                            (report.amount_type == 'credit' and not company.currency_id.is_zero(vals['detail_credit'])) or \
                            (data['debit_credit'] and (not company.currency_id.is_zero(vals['detail_debit']) or \
                                    not company.currency_id.is_zero(vals['detail_credit']))):
                            flag = True
                        if data['enable_filter']:
                            comp_bal = line['comp_bal']
                            if report.amount_type not in ['balance','initial_balance'] :
                                if report.amount_type == 'debit':
                                    comp_bal = line['comp_debit']
                                if report.amount_type == 'credit' :
                                    comp_bal = line['comp_credit']
                            vals['detail_balance_second'] = comp_bal
                            vals['detail_debit_second'] = line['comp_debit']
                            vals['detail_credit_second'] = line['comp_credit']
                            if (report.amount_type in ['balance','initial_balance'] and not company.currency_id.is_zero(vals['detail_balance_second']) )or \
                                (report.amount_type == 'debit' and not company.currency_id.is_zero(vals['detail_debit_second'])) or \
                                (report.amount_type == 'credit' and not company.currency_id.is_zero(vals['detail_credit_second'])) or \
                                (data['debit_credit'] and (not company.currency_id.is_zero(vals['detail_debit_second']) or \
                                        not company.currency_id.is_zero(vals['detail_credit_second']))):
                                flag = True
                        if flag :
                            details.append(vals)
                else :
                    if not report.amount_type in ['balance','initial_balance'] :
                        continue
                    for line_id, line in value['move_lines'].items() :
                        obj_rec = self.env['account.move.line'].browse(line_id)
                        vals = {
                            'name': account.name,
                            'sign' : report.sign,
                            'detail2_groupby' : report.detail2_groupby,
                            'detail_date': obj_rec.date,
                            'detail_move_name': obj_rec.move_id.name,
                            'detail_name': obj_rec.name,
                            'detail_balance': line['balance'],
                            'detail_debit' : line['debit'],
                            'detail_credit' : line['credit'],
                            'detail_number' : detail_number,
                        }

                        details.append(vals)
                
                if len(details) > 0:
                    next_number += 1
                    lines.append(details)
        return lines

    def balance_sign(self, balance, sign):
        style = ''
        if sign in ['-1','1'] :
            balance = balance * float(sign)
        elif balance < 0:
            balance = balance * -1
        balance = '{:,.2f}'.format(round(balance,2))
        if sign == '()' :
            balance = '(' + str(balance) + ')'
        if sign == 'bold' :
            style = 'font-weight: bold;color: black;'
        return {'style': style, 'balance' : balance}

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get('form') or not self.env.context.get('active_model') or not self.env.context.get('active_id'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        model = self.env.context.get('active_model')
        docs = self.env[model].browse(self.env.context.get('active_id'))
        report = self.env['account.financial.report'].search([('id', '=', data['form']['account_report_id'][0])])
        res = self.get_dic(data.get('form'))
        report_lines = self.get_report_lines(data.get('form'), res)
        # report_detail_lines =self.get_account_details_lines(data.get('form'))
        return {
            'doc_ids': self.ids,
            'doc_model': model,
            'data': data['form'],
            'docs': docs,
            'time': time,
            'res': res,
            'report': report,
            'report_lines': report_lines,
            'get_details1_lines' : self.get_details1_lines,
            'get_details2_lines' : self.get_details2_lines,
            'balance_sign':self.balance_sign
        }
